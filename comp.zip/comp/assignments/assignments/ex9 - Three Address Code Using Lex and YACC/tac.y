%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
int yyerror(const char *s);
int tempCount = 1;

char *newTemp(void)
{
    char buffer[20];
    sprintf(buffer, "t%d", tempCount++);
    return strdup(buffer);
}
%}

%union { char *id; }
%token <id> ID
%type <id> E
%left '+'
%left '*'

%%
input:
      E '\n' { printf("Generated Three-Address Code successfully.\n"); free($1); }
    | E     { printf("Generated Three-Address Code successfully.\n"); free($1); }
    ;

E:
      ID { $$ = strdup($1); free($1); }
    | E '+' E { char *t = newTemp(); printf("%s = %s + %s\n", t, $1, $3); $$ = strdup(t); free(t); free($1); free($3); }
    | E '*' E { char *t = newTemp(); printf("%s = %s * %s\n", t, $1, $3); $$ = strdup(t); free(t); free($1); free($3); }
    | '(' E ')' { $$ = $2; }
    ;
%%

int main(void)
{
    printf("Enter an arithmetic expression:\n");
    return yyparse();
}

int yyerror(const char *s)
{
    fprintf(stderr, "Error: %s\n", s);
    return 0;
}
