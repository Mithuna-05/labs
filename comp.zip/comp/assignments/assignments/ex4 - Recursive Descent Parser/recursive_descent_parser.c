#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct Node {
    char label[10];
    struct Node *child[4];
    int n;
} Node;

char tokens[100][10];
int pos = 0, ntokens = 0;
char stack[100][10];
int top = -1, error = 0;

Node *node(char *label)
{
    Node *p = malloc(sizeof(Node));
    strcpy(p->label, label);
    p->n = 0;
    return p;
}

void add(Node *p, Node *c)
{
    p->child[p->n++] = c;
}

void push(char *s)
{

    strcpy(stack[++top], s);
    printf("PUSH %s\n", s);
}

void pop()
{
    if (top >= 0)
        printf("POP   %s\n", stack[top--]);
}

int match(char *s)
{
    if (pos < ntokens && strcmp(tokens[pos], s) == 0) {
        printf("MATCH %s\n", s);
        pos++;
        return 1;
    }

    error = 1;
    return 0;
}

Node *E();
Node *Ep();
Node *T();
Node *Tp();
Node *F();

Node *E()
{
    push("E");
    Node *p = node("E");
    add(p, T());
    if (!error)
        add(p, Ep());
    pop();
    return p;
}

Node *Ep()
{
    push("E'");
    Node *p = node("E'");

    if (pos < ntokens && strcmp(tokens[pos], "+") == 0) {
        add(p, node("+"));
        match("+");
        add(p, T());
        if (!error)
             add(p, Ep());
    } else {
        add(p, node("epsilon"));
    }

    pop();
    return p;

 }

 Node *T()
 {
     push("T");
     Node *p = node("T");
     add(p, F());
     if (!error)
         add(p, Tp());
     pop();
     return p;
 }

Node *Tp()
{
    push("T'");
    Node *p = node("T'");

    if (pos < ntokens && strcmp(tokens[pos], "*") == 0) {
        add(p, node("*"));
        match("*");
        add(p, F());
        if (!error)
             add(p, Tp());
    } else {
        add(p, node("epsilon"));
    }

    pop();
    return p;
}

Node *F()
{
    push("F");
    Node *p = node("F");

    if (pos < ntokens && strcmp(tokens[pos], "id") == 0) {
        add(p, node("id"));
        match("id");
    } else if (pos < ntokens &&
               strcmp(tokens[pos], "(") == 0) {
        add(p, node("("));
        match("(");
        if (!error)
            add(p, E());

        if (!error) {
             add(p, node(")"));
             match(")");
        }
    } else {
        error = 1;
    }

    pop();

    return p;
}

void printTree(Node *p, int level)
{
    if (p == NULL)
        return;

    for (int i = 0; i < level; i++)
        printf(" ");

    printf("%s\n", p->label);

    for (int i = 0; i < p->n; i++)
        printTree(p->child[i], level + 1);
}

void tokenize(char *s)
{
    int i = 0;

    while (s[i] != '\0') {
        if (isspace((unsigned char)s[i])) {
            i++;
        } else if (strncmp(&s[i], "id", 2) == 0) {
            strcpy(tokens[ntokens++], "id");
            i += 2;
        } else if (strchr("+*()", s[i])) {
            tokens[ntokens][0] = s[i++];
            tokens[ntokens++][1] = '\0';
        } else {
            printf("Invalid symbol: %c\n", s[i]);
            error = 1;
            return;
        }
    }
}

int main()
{
    char input[200];

    printf("Enter input string: ");
    if (fgets(input, sizeof(input), stdin) == NULL)
        return 1;

    tokenize(input);

    if (error)
        return 1;

    printf("\nOperational Stack:\n");
    Node *root = E();

    if (!error && pos == ntokens) {
        printf("\nString accepted.\n");

        printf("\nParse Tree:\n");
        printTree(root, 0);
    } else {
        printf("\nString rejected.\n");
    }

    return 0;
}
