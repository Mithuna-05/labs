COMPILER LAB ASSIGNMENTS (Exercises 1–10)

Each exercise folder is named `exN - Exercise Name` and contains the source files transcribed from the corresponding uploaded assignment PDF, plus `compilation_steps.txt` with build/run commands and notes on adapting the code when the grammar changes.

Important fidelity note: the PDFs' embedded text layer has OCR/spacing artifacts in some listings (especially Lex/Yacc listings). Those files have been reconstructed into readable source while preserving the program's intended structure and logic. Exercise 10 includes the complete source-file listings present in the PDF appendix, arranged in their listed directory structure.

See each folder's `compilation_steps.txt` for commands and grammar-change guidance.
