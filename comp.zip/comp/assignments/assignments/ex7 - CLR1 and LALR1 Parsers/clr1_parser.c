#include <stdio.h>
#include <string.h>

#define MAX 100

int action[7][3] = {
    {0, 4, 0},
    {0, 0, 999},
    {0, 0, 0},
    {0, 0, -3},
    {0, 0, 0},
    {0, 0, -1},
    {0, 0, -2}
};

/* GOTO columns: S=0, A=1 */
int go[7][2] = {
    {1, 2},
    {-1, -1},
    {-1, 5},
    {-1, 6},
    {-1, -1},
    {-1, -1},
    {-1, -1}
};

int main(void) {
    char input[MAX];
    int stack[MAX], top = 0, ip = 0;

    printf("Enter input ending with $: ");
    scanf("%99s", input);


if (input[strlen(input) - 1] != '$') {
    printf("Input must end with $\n");
    return 0;
}

stack[0] = 0;
printf("\nStack\tInput\tAction\n");

while (1) {
    for (int i = 0; i <= top; i++)
        printf("%d ", stack[i]);

    printf("\t%s\t", input + ip);

    char c = input[ip];
    int col = c == 'a' ? 0 :
              c == 'b' ? 1 :
              c == '$' ? 2 : -1;

    if (col < 0) {
        printf("Invalid symbol\n");
        break;
    }

    int a = action[stack[top]][col];

    if (a == 999) {
        printf("Accept\nString accepted.\n");
        break;
    }

    if (a == 0) {
        printf("Error\nString rejected.\n");
        break;
    }

    if (a > 0) {
        printf("Shift %d\n", a - 1);
        stack[++top] = a - 1;
        ip++;
    } else {
        int r = -a;
        int length = (r == 3) ? 1 : 2;
        char lhs = 'S';

        printf("Reduce by R%d\n", r);
        top -= length;

        int next = go[stack[top]][lhs == 'S' ? 0 : 1];

        if (next < 0) {
            printf("Invalid GOTO\n");
            break;
        }

            stack[++top] = next;
        }

        if (top >= MAX - 1) {
            printf("Stack overflow\n");
            break;
        }
    }

    return 0;
}
