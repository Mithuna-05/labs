/* tac.c - Intermediate code generation: Three Address Code (quadruples). */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "common.h"
static TAC *T;
static int ntemp = 0, nlabel = 0;
int is_const(const char *s) {
    if (!s || !*s) return 0;
    if (*s == '-') s++;
    return isdigit((unsigned char)*s);
}
int is_binary(QOp op) { return op >= Q_ADD && op <= Q_OR; }
int eval_op(QOp op, int a, int b, int *out) {
    unsigned ua = (unsigned)a, ub = (unsigned)b;
    switch (op) {
    case Q_ADD: *out = (int)(ua + ub); return 1;
    case Q_SUB: *out = (int)(ua - ub); return 1;
    case Q_MUL: *out = (int)(ua * ub); return 1;
    case Q_DIV: if (b == 0 || (a == (-2147483647 - 1) && b == -1)) return 0; *out = a / b; return 1;
    case Q_MOD: if (b == 0 || (a == (-2147483647 - 1) && b == -1)) return 0; *out = a % b; return 1;
    case Q_LT: *out = a < b; return 1;
    case Q_GT: *out = a > b; return 1;
    case Q_LE: *out = a <= b; return 1;
    case Q_GE: *out = a >= b; return 1;
    case Q_EQ: *out = a == b; return 1;
    case Q_NE: *out = a != b; return 1;
    case Q_AND: *out = (a != 0) && (b != 0); return 1;
    case Q_OR: *out = (a != 0) || (b != 0); return 1;
    default: return 0;
    }
}
static void emit(QOp op, const char *a1, const char *a2, const char *res) {
    if (T->n >= MAXQ) { report("ERROR", "codegen", 0, "program too large (TAC limit)"); return; }







    Quad *q = &T->q[T->n++];
    q->op = op;
    snprintf(q->a1, sizeof q->a1, "%s", a1 ? a1 : "");
    snprintf(q->a2, sizeof q->a2, "%s", a2 ? a2 : "");
    snprintf(q->res, sizeof q->res, "%s", res ? res : "");
}
static void new_temp(char *buf) { snprintf(buf, 96, "_t%d", ++ntemp); }
static void new_label(char *buf) { snprintf(buf, 96, "L%d", ++nlabel); }
static QOp binop_of(const char *s) {
    static const struct { const char *s; QOp op; } tab[] = {
        {"+",Q_ADD},{"-",Q_SUB},{"*",Q_MUL},{"/",Q_DIV},{"%",Q_MOD},
        {"<",Q_LT},{">",Q_GT},{"<=",Q_LE},{">=",Q_GE},{"==",Q_EQ},{"!=",Q_NE},
        {"&&",Q_AND},{"||",Q_OR}};
    for (size_t i = 0; i < sizeof tab / sizeof *tab; i++) if (!strcmp(tab[i].s, s)) return tab[i].op;
    return Q_ADD;
}
/* returns the operand (constant, variable or temporary) holding the value */
static void gen_expr(Node *n, char *out) {
    switch (n->kind) {
    case N_NUM: snprintf(out, 96, "%d", n->ival); return;
    case N_ID: snprintf(out, 96, "%s", n->uname); return;
    case N_UNOP: {
        char a[96], t[96]; gen_expr(n->a, a); new_temp(t);
        emit(n->op[0] == '-' ? Q_NEG : Q_NOT, a, "", t);
        strcpy(out, t); return;
    }
    case N_BINOP: {
        char a[96], b[96], t[96];
        gen_expr(n->a, a); gen_expr(n->b, b); new_temp(t);
        emit(binop_of(n->op), a, b, t);
        strcpy(out, t); return;
    }
    default: out[0] = 0; return;
    }
}
static void gen_stmt(Node *n) {
    char a[96], l1[96], l2[96];
    if (!n) return;
    switch (n->kind) {
    case N_DECL:
        if (n->a) { gen_expr(n->a, a); emit(Q_ASSIGN, a, "", n->uname); }
        else emit(Q_ASSIGN, "0", "", n->uname);       /* variables default to 0 */
        break;
    case N_ASSIGN: gen_expr(n->a, a); emit(Q_ASSIGN, a, "", n->uname); break;
    case N_PRINT: gen_expr(n->a, a); emit(Q_PRINT, a, "", ""); break;
    case N_BLOCK: for (Node *s = n->a; s; s = s->next) gen_stmt(s); break;
    case N_IF:
        gen_expr(n->a, a); new_label(l1);
        if (n->c) {
            new_label(l2);
            emit(Q_IFFALSE, a, "", l1); gen_stmt(n->b);
            emit(Q_GOTO, "", "", l2);
            emit(Q_LABEL, "", "", l1); gen_stmt(n->c);
            emit(Q_LABEL, "", "", l2);
        } else {
            emit(Q_IFFALSE, a, "", l1); gen_stmt(n->b);
            emit(Q_LABEL, "", "", l1);
        }
        break;
    case N_WHILE:
        new_label(l1); new_label(l2);
        emit(Q_LABEL, "", "", l1);
        gen_expr(n->a, a);
        emit(Q_IFFALSE, a, "", l2);
        gen_stmt(n->b);
        emit(Q_GOTO, "", "", l1);
        emit(Q_LABEL, "", "", l2);
        break;
    default: break;
    }
}







void tac_generate(Node *root, TAC *t) {
    T = t; t->n = 0; ntemp = 0; nlabel = 0;
    for (Node *s = root->a; s; s = s->next) gen_stmt(s);
}
static const char *opstr(QOp op) {
    static const char *s[] = {"", "+","-","*","/","%","<",">","<=",">=","==","!=","&&","||"};
    return s[op];
}
void tac_format(Quad *q, char *buf, size_t n) {
    switch (q->op) {
    case Q_ASSIGN: snprintf(buf, n, "%s = %s", q->res, q->a1); break;
    case Q_NEG:      snprintf(buf, n, "%s = - %s", q->res, q->a1); break;
    case Q_NOT:      snprintf(buf, n, "%s = ! %s", q->res, q->a1); break;
    case Q_LABEL:    snprintf(buf, n, "%s:", q->res); break;
    case Q_GOTO:     snprintf(buf, n, "goto %s", q->res); break;
    case Q_IFFALSE: snprintf(buf, n, "ifFalse %s goto %s", q->a1, q->res); break;
    case Q_PRINT:    snprintf(buf, n, "print %s", q->a1); break;
    default:        snprintf(buf, n, "%s = %s %s %s", q->res, q->a1, opstr(q->op), q->a2); break;
    }
}
void tac_print(FILE *f, TAC *t) {
    char buf[400];
    for (int i = 0; i < t->n; i++) {
        tac_format(&t->q[i], buf, sizeof buf);
        if (t->q[i].op == Q_LABEL) fprintf(f, "%s\n", buf);
        else fprintf(f, "    %s\n", buf);
    }
}
