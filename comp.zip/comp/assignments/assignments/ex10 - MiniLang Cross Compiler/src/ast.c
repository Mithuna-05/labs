/* ast.c - AST construction, pretty printing and diagnostics */
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "common.h"
FILE *g_err;
int g_lex_errors, g_syn_errors, g_sem_errors, g_warnings;
void report(const char *level, const char *phase, int line, const char *fmt, ...) {
    char buf[512];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    if (g_err) fprintf(g_err, "%s|%s|%d|%s\n", level, phase, line, buf);
    if (!strcmp(level, "ERROR")) {
        if (!strcmp(phase, "lexical")) g_lex_errors++;
        else if (!strcmp(phase, "syntax")) g_syn_errors++;
        else g_sem_errors++;
    } else g_warnings++;
}
Node *mk(NodeKind k, int line) {
    Node *n = calloc(1, sizeof *n); n->kind = k; n->line = line; return n;
}
Node *mk_binop(const char *op, Node *l, Node *r, int line) {
    Node *n = mk(N_BINOP, line); n->op = strdup(op); n->a = l; n->b = r; return n;
}
Node *mk_unop(const char *op, Node *e, int line) {
    Node *n = mk(N_UNOP, line); n->op = strdup(op); n->a = e; return n;
}
Node *mk_num(int v, int line) { Node *n = mk(N_NUM, line); n->ival = v; return n; }
Node *mk_id(const char *name, int line) {
    Node *n = mk(N_ID, line); n->name = strdup(name); return n;
}
Node *list_append(Node *head, Node *n) {
    if (!n) return head;
    if (!head) return n;
    Node *p = head; while (p->next) p = p->next;
    p->next = n; return head;
}
static void label(Node *n, char *buf, size_t sz) {
    switch (n->kind) {
    case N_PROGRAM: snprintf(buf, sz, "Program"); break;
    case N_BLOCK:   snprintf(buf, sz, n->a ? "Block" : "Block (empty)"); break;
    case N_DECL:    snprintf(buf, sz, "Declare int %s%s", n->name, n->a ? " =" : ""); break;
    case N_ASSIGN: snprintf(buf, sz, "Assign %s =", n->name); break;
    case N_IF:      snprintf(buf, sz, "If"); break;
    case N_WHILE:   snprintf(buf, sz, "While"); break;
    case N_PRINT:   snprintf(buf, sz, "Print"); break;
    case N_BINOP:   snprintf(buf, sz, "BinOp '%s'", n->op); break;
    case N_UNOP:    snprintf(buf, sz, "UnOp '%s'", n->op); break;
    case N_NUM:     snprintf(buf, sz, "Num %d", n->ival); break;







    case N_ID:      snprintf(buf, sz, "Id %s", n->name); break;
    }
}
static void pr(FILE *f, Node *n, const char *prefix, int last, const char *role, int root) {
    char lab[200]; label(n, lab, sizeof lab);
    if (root) fprintf(f, "%s\n", lab);
    else fprintf(f, "%s%s%s%s\n", prefix, last ? "`-- " : "|-- ", role, lab);
    char np[1024];
    snprintf(np, sizeof np, "%s%s", root ? "" : prefix, root ? "" : (last ? "    " : "|   "));
    if (n->kind == N_PROGRAM || n->kind == N_BLOCK) {
        int cnt = 0; for (Node *s = n->a; s; s = s->next) cnt++;
        int i = 0;
        for (Node *s = n->a; s; s = s->next, i++) pr(f, s, np, i == cnt - 1, "", 0);
        return;
    }
    Node *kids[3] = {0}; const char *roles[3] = {"", "", ""}; int k = 0;
    switch (n->kind) {
    case N_DECL: case N_ASSIGN: case N_PRINT: case N_UNOP:
        if (n->a) kids[k++] = n->a;
        break;
    case N_IF:
        kids[k] = n->a; roles[k++] = "cond: ";
        kids[k] = n->b; roles[k++] = "then: ";
        if (n->c) { kids[k] = n->c; roles[k++] = "else: "; }
        break;
    case N_WHILE:
        kids[k] = n->a; roles[k++] = "cond: ";
        kids[k] = n->b; roles[k++] = "body: ";
        break;
    case N_BINOP:
        kids[k] = n->a; roles[k++] = "left: ";
        kids[k] = n->b; roles[k++] = "right: ";
        break;
    default: break;
    }
    for (int i = 0; i < k; i++) pr(f, kids[i], np, i == k - 1, roles[i], 0);
}
void print_ast(FILE *f, Node *root) { if (root) pr(f, root, "", 1, "", 1); }
