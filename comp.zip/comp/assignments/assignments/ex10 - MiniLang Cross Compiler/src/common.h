/* common.h - shared declarations for the MiniLang cross compiler */
#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>
/* ---------- diagnostics ---------- */
extern FILE *g_err;                 /* errors.txt: LEVEL|PHASE|LINE|message */
extern int g_lex_errors, g_syn_errors, g_sem_errors, g_warnings;
void report(const char *level, const char *phase, int line, const char *fmt, ...);
/* ---------- AST ---------- */
typedef enum {
    N_PROGRAM, N_BLOCK, N_DECL, N_ASSIGN, N_IF, N_WHILE, N_PRINT,
    N_BINOP, N_UNOP, N_NUM, N_ID
} NodeKind;
typedef struct Node {
    NodeKind kind;
    int line;
    char *op;            /* operator text for BINOP/UNOP */
    char *name;          /* identifier name (as written) */
    char *uname;         /* unique name after semantic analysis */
    int ival;            /* NUM value */
    struct Node *a, *b, *c;   /* children (meaning depends on kind) */
    struct Node *next;   /* sibling in a statement list */
} Node;
Node *mk(NodeKind k, int line);
Node *mk_binop(const char *op, Node *l, Node *r, int line);
Node *mk_unop(const char *op, Node *e, int line);
Node *mk_num(int v, int line);
Node *mk_id(const char *name, int line);
Node *list_append(Node *head, Node *n);
void print_ast(FILE *f, Node *root);
/* ---------- lexer / parser ---------- */
extern FILE *yyin;
extern int lex_pass;                 /* 1 = token dump pass, 2 = parse pass */
extern FILE *g_tok;                  /* tokens.txt */
extern Node *g_root;
int yylex(void);
int yyparse(void);
void yyrestart(FILE *);
extern int yylineno;
void lexer_reset(void);







/* ---------- semantic analysis ---------- */
#define MAXSYM 2000
typedef struct {
    char name[64], uname[80];
    int scope, line, initialized, used;
    int active;
} Symbol;
extern Symbol g_syms[];
extern int g_nsyms;
void semantic_analyze(Node *root);
void print_symtab(FILE *f);
/* ---------- three address code ---------- */
typedef enum {
    Q_ASSIGN, Q_ADD, Q_SUB, Q_MUL, Q_DIV, Q_MOD,
    Q_LT, Q_GT, Q_LE, Q_GE, Q_EQ, Q_NE, Q_AND, Q_OR,
    Q_NEG, Q_NOT,
    Q_LABEL, Q_GOTO, Q_IFFALSE, Q_PRINT
} QOp;
typedef struct { QOp op; char a1[96], a2[96], res[96]; } Quad;
#define MAXQ 20000
typedef struct { Quad q[MAXQ]; int n; } TAC;
void tac_generate(Node *root, TAC *t);
void tac_print(FILE *f, TAC *t);
void tac_format(Quad *q, char *buf, size_t n);
int is_const(const char *s);
int eval_op(QOp op, int a, int b, int *out);     /* 0 on div-by-zero */
int is_binary(QOp op);
/* ---------- optimizer ---------- */
typedef struct {
    int folded, propagated, algebraic, strength, dead, unreachable, jumps, labels, coalesced;
    int before, after;
} OptStats;
void optimize(TAC *t, OptStats *s);
void print_opt_report(FILE *f, OptStats *s);
/* ---------- back ends ---------- */
void gen_c(FILE *f, TAC *t);
void gen_x86_64(FILE *f, TAC *t);
void gen_aarch64(FILE *f, TAC *t);
void gen_riscv64(FILE *f, TAC *t);
/* ---------- reference interpreter (executes TAC) ---------- */
int run_tac(FILE *out, TAC *t);
#endif
