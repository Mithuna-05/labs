/* interp.c - Reference interpreter that executes the optimised TAC directly.
* It gives the "expected output" of the program on any machine, even when no
* native/cross toolchain or emulator is installed, and is used to cross-check
* the output of the generated C / x86-64 / ARM64 / RISC-V programs.              */
#include <stdlib.h>
#include <string.h>
#include "common.h"
#define MAXVARS 4096
static char vname[MAXVARS][96];
static int vval[MAXVARS];
static int nvars;
static int var_index(const char *n) {
    for (int i = 0; i < nvars; i++) if (!strcmp(vname[i], n)) return i;
    if (nvars >= MAXVARS) return 0;
    snprintf(vname[nvars], 96, "%s", n); vval[nvars] = 0; return nvars++;
}
static int value(const char *op) { return is_const(op) ? atoi(op) : vval[var_index(op)]; }
static int find_label(TAC *t, const char *l) {
    for (int i = 0; i < t->n; i++) if (t->q[i].op == Q_LABEL && !strcmp(t->q[i].res, l)) return i;
    return -1;
}
int run_tac(FILE *out, TAC *t) {
    nvars = 0;
    long steps = 0;
    const long LIMIT = 5000000;
    for (int pc = 0; pc < t->n; pc++) {
        if (++steps > LIMIT) { fprintf(out, "[stopped: step limit of %ld instructions reached - possible
           infinite loop]\n", LIMIT); return 2; }
        Quad *q = &t->q[pc];
        int r;
        switch (q->op) {
        case Q_ASSIGN: vval[var_index(q->res)] = value(q->a1); break;
        case Q_NEG:    vval[var_index(q->res)] = (int)(0u - (unsigned)value(q->a1)); break;
        case Q_NOT:    vval[var_index(q->res)] = !value(q->a1); break;
        case Q_LABEL: break;
        case Q_GOTO:   { int l = find_label(t, q->res); if (l >= 0) pc = l; break; }
        case Q_IFFALSE: if (value(q->a1) == 0) { int l = find_label(t, q->res); if (l >= 0) pc = l; } break;







        case Q_PRINT: fprintf(out, "%d\n", value(q->a1)); break;
        default:
            if (!eval_op(q->op, value(q->a1), value(q->a2), &r)) {
                 fprintf(out, "[runtime error: division by zero]\n"); return 1;
            }
            vval[var_index(q->res)] = r;
        }
    }
    return 0;
}
