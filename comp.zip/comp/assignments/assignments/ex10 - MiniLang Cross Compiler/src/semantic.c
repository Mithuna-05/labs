/* semantic.c - Semantic analysis using a scoped symbol table.
 *
 * Checks performed:
 *   - use of an undeclared variable                       (error)
 *   - redeclaration of a variable in the same scope       (error)
 *   - constant division / modulo by zero                  (error)
 *   - variable read before any assignment                 (warning)
 *   - variable declared but never used                    (warning)
 * Every declaration receives a unique name (uname) so that variables with the
 * same name in different scopes never clash in the generated target code.     */
#include <stdlib.h>
#include <string.h>
#include "common.h"
Symbol g_syms[MAXSYM];
int g_nsyms = 0;
static int cur_scope = 0;
static int lookup(const char *name) {
    for (int i = g_nsyms - 1; i >= 0; i--)
        if (g_syms[i].active && !strcmp(g_syms[i].name, name)) return i;
    return -1;
}
static void push_scope(void) { cur_scope++; }







static void pop_scope(void) {
    for (int i = 0; i < g_nsyms; i++)
        if (g_syms[i].active && g_syms[i].scope == cur_scope) g_syms[i].active = 0;
    cur_scope--;
}
static int declare(const char *name, int line, int initialized) {
    for (int i = 0; i < g_nsyms; i++)
         if (g_syms[i].active && g_syms[i].scope == cur_scope && !strcmp(g_syms[i].name, name)) {
             report("ERROR", "semantic", line,
                    "variable '%s' is already declared in this scope (line %d)", name, g_syms[i].line);
             return i;
         }
    if (g_nsyms >= MAXSYM) { report("ERROR", "semantic", line, "too many variables"); return 0; }
    Symbol *s = &g_syms[g_nsyms];
    memset(s, 0, sizeof *s);
    snprintf(s->name, sizeof s->name, "%s", name);
    int dup = 0;                                    /* how many earlier symbols share the name */
    for (int i = 0; i < g_nsyms; i++) if (!strcmp(g_syms[i].name, name)) dup++;
    if (dup == 0) snprintf(s->uname, sizeof s->uname, "%s", name);
    else           snprintf(s->uname, sizeof s->uname, "%s__%d", name, dup + 1);
    s->scope = cur_scope; s->line = line; s->initialized = initialized; s->active = 1;
    return g_nsyms++;
}
static void expr(Node *n) {
    if (!n) return;
    switch (n->kind) {
    case N_NUM: break;
    case N_ID: {
        int i = lookup(n->name);
        if (i < 0) {
            report("ERROR", "semantic", n->line, "undeclared variable '%s'", n->name);
            n->uname = strdup(n->name);
        } else {
            g_syms[i].used = 1;
            n->uname = strdup(g_syms[i].uname);
            if (!g_syms[i].initialized) {
                 report("WARNING", "semantic", n->line,
                        "variable '%s' is read before any assignment (defaults to 0)", n->name);
                 g_syms[i].initialized = 1;          /* warn only once */
            }
        }
        break;
    }
    case N_UNOP: expr(n->a); break;
    case N_BINOP:
        expr(n->a); expr(n->b);
        if ((!strcmp(n->op, "/") || !strcmp(n->op, "%")) && n->b->kind == N_NUM && n->b->ival == 0)
            report("ERROR", "semantic", n->line, "division by constant zero");
        break;
    default: break;
    }
}
static void stmt(Node *n);
static void stmts(Node *list) { for (Node *s = list; s; s = s->next) stmt(s); }
static void stmt(Node *n) {
    if (!n) return;
    switch (n->kind) {
    case N_DECL: {
        expr(n->a);                                 /* initialiser sees the OUTER scope */
        int i = declare(n->name, n->line, n->a != NULL);
        n->uname = strdup(g_syms[i].uname);
        break;
    }
    case N_ASSIGN: {
        int i = lookup(n->name);
        expr(n->a);
        if (i < 0) {
            report("ERROR", "semantic", n->line, "assignment to undeclared variable '%s'", n->name);
            n->uname = strdup(n->name);
        } else {
            g_syms[i].initialized = 1;







            n->uname = strdup(g_syms[i].uname);
        }
        break;
    }
    case N_PRINT: expr(n->a); break;
    case N_IF:    expr(n->a); stmt(n->b); stmt(n->c); break;
    case N_WHILE: expr(n->a); stmt(n->b); break;
    case N_BLOCK: push_scope(); stmts(n->a); pop_scope(); break;
    default: break;
    }
}
void semantic_analyze(Node *root) {
    g_nsyms = 0; cur_scope = 0;
    stmts(root->a);                                  /* program = global scope 0 */
    for (int i = 0; i < g_nsyms; i++)
        if (!g_syms[i].used)
            report("WARNING", "semantic", g_syms[i].line,
                    "variable '%s' is declared but never used", g_syms[i].name);
}
void print_symtab(FILE *f) {
    /* name|unique name|type|scope|line|initialised|used */
    for (int i = 0; i < g_nsyms; i++)
        fprintf(f, "%s|%s|int|%d|%d|%s|%s\n", g_syms[i].name, g_syms[i].uname,
                g_syms[i].scope, g_syms[i].line,
                g_syms[i].initialized ? "yes" : "no", g_syms[i].used ? "yes" : "no");
}
