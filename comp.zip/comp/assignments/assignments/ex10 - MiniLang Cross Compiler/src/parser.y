%{
/* parser.y - Syntax analyser for MiniLang (Bison). Builds the AST. */
#include <stdlib.h>
#include <string.h>
#include "common.h"







Node *g_root = NULL;
void yyerror(const char *msg);
%}
%define parse.error verbose
%union { Node *node; int ival; char *str; }
%token INT "int" IF "if" ELSE "else" WHILE "while" PRINT "print"
%token <str> ID "identifier"
%token <ival> NUM "number"
%token LE "<=" GE ">=" EQ "==" NE "!=" AND "&&" OR "||"
%type <node> program item_list item stmt block decl expr
%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE
%left OR
%left AND
%left EQ NE
%left '<' '>' LE GE
%left '+' '-'
%left '*' '/' '%'
%right '!' UMINUS
%%
program
    : item_list                         { g_root = mk(N_PROGRAM, 1); g_root->a = $1; }
    ;
item_list
    : /* empty */                       { $$ = NULL; }
    | item_list item                    { $$ = list_append($1, $2); }
    ;
item
       : decl                           { $$ = $1; }
       | stmt                           { $$ = $1; }
       ;
decl
       : INT ID ';'                     { $$ = mk(N_DECL, yylineno); $$->name = $2; }
       | INT ID '=' expr ';'            { $$ = mk(N_DECL, yylineno); $$->name = $2; $$->a = $4; }
       ;
block
    : '{' item_list '}'                 { $$ = mk(N_BLOCK, yylineno); $$->a = $2; }
    ;
stmt
       : ID '=' expr ';'                 { $$ = mk(N_ASSIGN, yylineno); $$->name = $1; $$->a = $3; }
       | PRINT '(' expr ')' ';'          { $$ = mk(N_PRINT, yylineno); $$->a = $3; }
       | IF '(' expr ')' stmt %prec LOWER_THAN_ELSE
                                         { $$ = mk(N_IF, yylineno); $$->a = $3; $$->b = $5; }
       | IF '(' expr ')' stmt ELSE stmt { $$ = mk(N_IF, yylineno); $$->a = $3; $$->b = $5; $$->c = $7; }
       | WHILE '(' expr ')' stmt         { $$ = mk(N_WHILE, yylineno); $$->a = $3; $$->b = $5; }
       | block                           { $$ = $1; }
       | ';'                             { $$ = mk(N_BLOCK, yylineno); }
       | error ';'                       { $$ = mk(N_BLOCK, yylineno); yyerrok; }
       ;
expr
       : expr '+' expr                  { $$ = mk_binop("+", $1, $3, yylineno); }
       | expr '-' expr                  { $$ = mk_binop("-", $1, $3, yylineno); }
       | expr '*' expr                  { $$ = mk_binop("*", $1, $3, yylineno); }
       | expr '/' expr                  { $$ = mk_binop("/", $1, $3, yylineno); }
       | expr '%' expr                  { $$ = mk_binop("%", $1, $3, yylineno); }
       | expr '<' expr                  { $$ = mk_binop("<", $1, $3, yylineno); }
       | expr '>' expr                  { $$ = mk_binop(">", $1, $3, yylineno); }
       | expr LE expr                   { $$ = mk_binop("<=", $1, $3, yylineno); }
       | expr GE expr                   { $$ = mk_binop(">=", $1, $3, yylineno); }
       | expr EQ expr                   { $$ = mk_binop("==", $1, $3, yylineno); }
       | expr NE expr                   { $$ = mk_binop("!=", $1, $3, yylineno); }







     | expr AND expr                  { $$ = mk_binop("&&", $1, $3, yylineno); }
     | expr OR expr                   { $$ = mk_binop("||", $1, $3, yylineno); }
     | '-' expr %prec UMINUS          { $$ = mk_unop("-", $2, yylineno); }
     | '!' expr                       { $$ = mk_unop("!", $2, yylineno); }
     | '(' expr ')'                   { $$ = $2; }
     | NUM                            { $$ = mk_num($1, yylineno); }
     | ID                             { $$ = mk_id($1, yylineno); free($1); }
     ;
%%
void yyerror(const char *msg) {
    report("ERROR", "syntax", yylineno, "%s", msg);
}
