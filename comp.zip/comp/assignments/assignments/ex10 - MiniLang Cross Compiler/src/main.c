/* main.c - Compiler driver.
 *   usage: minicc <source-file> <output-dir>
 * Runs every phase and writes one file per phase into <output-dir>:
 *   tokens.txt errors.txt ast.txt symtab.txt tac.txt tac_opt.txt
 *   opt_report.txt out.c out_x86_64.s out_aarch64.s out_riscv64.s        run_output.txt
 * Exit code: 0 = success, 1 = compile errors, 2 = usage / I/O error.              */
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "common.h"
static char outdir[512];
static FILE *openout(const char *name) {
    char path[1100]; snprintf(path, sizeof path, "%s/%s", outdir, name);
    FILE *f = fopen(path, "w");
    if (!f) { fprintf(stderr, "cannot write %s\n", path); exit(2); }
    return f;
}
static TAC tac_raw, tac_opt;
int main(int argc, char **argv) {
    if (argc != 3) { fprintf(stderr, "usage: %s <source> <outdir>\n", argv[0]); return 2; }
    snprintf(outdir, sizeof outdir, "%s", argv[2]);
    mkdir(outdir, 0755);                       /* ignore error if it already exists */
    FILE *src = fopen(argv[1], "r");
    if (!src) { perror(argv[1]); return 2; }
    g_err = openout("errors.txt");
    g_tok = openout("tokens.txt");
    FILE *f;
    /* ---- Phase 1: lexical analysis (token dump) ---- */
    yyin = src; lex_pass = 1; lexer_reset();
    while (yylex() != 0) { }
    fclose(g_tok);
    /* ---- Phase 2: syntax analysis (parse + build AST) ---- */
    rewind(src); yyrestart(src); lexer_reset(); lex_pass = 2;
    yyparse();
    fclose(src);
    f = openout("ast.txt");
    if (g_root && !g_lex_errors && !g_syn_errors) print_ast(f, g_root);
    fclose(f);
    /* create (possibly empty) files so the UI can always read them */
    FILE *e1 = openout("symtab.txt"), *e2 = openout("tac.txt"), *e3 = openout("tac_opt.txt"),
         *e4 = openout("opt_report.txt"), *e5 = openout("out.c"), *e6 = openout("out_x86_64.s"),
         *e7 = openout("out_aarch64.s"), *e8 = openout("out_riscv64.s"), *e9 = openout("run_output.txt");
    if (g_lex_errors || g_syn_errors || !g_root) goto done;
    /* ---- Phase 3: semantic analysis ---- */
    semantic_analyze(g_root);
    print_symtab(e1);







    if (g_sem_errors) goto done;
    /* ---- Phase 4: intermediate code (TAC) ---- */
    tac_generate(g_root, &tac_raw);
    tac_print(e2, &tac_raw);
    /* ---- Phase 5: optimisation ---- */
    OptStats st;
    tac_opt = tac_raw;
    optimize(&tac_opt, &st);
    tac_print(e3, &tac_opt);
    print_opt_report(e4, &st);
    /* ---- Phase 6: code generation for four targets ---- */
    gen_c(e5, &tac_opt);
    gen_x86_64(e6, &tac_opt);
    gen_aarch64(e7, &tac_opt);
    gen_riscv64(e8, &tac_opt);
    /* ---- Phase 7: reference execution ---- */
    run_tac(e9, &tac_opt);
done:
    fclose(e1); fclose(e2); fclose(e3); fclose(e4); fclose(e5);
    fclose(e6); fclose(e7); fclose(e8); fclose(e9);
    fclose(g_err);
    return (g_lex_errors || g_syn_errors || g_sem_errors) ? 1 : 0;
}
