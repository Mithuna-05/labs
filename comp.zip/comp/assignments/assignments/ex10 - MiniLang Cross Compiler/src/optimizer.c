/* optimizer.c - Machine independent optimisations on the TAC.
*
* 1. Constant folding             _t1 = 2 * 3          -> _t1 = 6
* 2. Constant & copy propagation (per basic block)     x = 5; y = x + 1 -> y = 5 + 1
* 3. Algebraic simplification     x + 0, x * 1, x * 0, x - x, x / 1 ...
* 4. Strength reduction           x * 2                -> x + x
* 5. Dead code elimination        assignments to never-read variables / temporaries
* 6. Unreachable code removal     code after goto, ifFalse with constant condition
* 7. Jump clean-up                goto next-label, unused labels
 * 8. Copy coalescing (peephole) _t1 = a + b; x = _t1     -> x = a + b
 * The passes are repeated until nothing changes (fix-point).                       */
#include <stdlib.h>
#include <string.h>
#include "common.h"
static int del[MAXQ];
static void compact(TAC *t) {
    int j = 0;
    for (int i = 0; i < t->n; i++) if (!del[i]) t->q[j++] = t->q[i];
    t->n = j;
    memset(del, 0, sizeof del);
}
static int defines(QOp op) { return op == Q_ASSIGN || is_binary(op) || op == Q_NEG || op == Q_NOT; }
static int reads_a1(QOp op) { return op != Q_LABEL && op != Q_GOTO; }
static int reads_a2(QOp op) { return is_binary(op); }
/* ---------- constant folding + constant/copy propagation ---------- */
typedef struct { char k[96], v[96]; } Pair;
static Pair map[2048];
static int nmap;
static const char *map_get(const char *k) {
    for (int i = 0; i < nmap; i++) if (!strcmp(map[i].k, k)) return map[i].v;







    return NULL;
}
static void map_kill(const char *name) {
    for (int i = 0; i < nmap; ) {
        if (!strcmp(map[i].k, name) || !strcmp(map[i].v, name)) map[i] = map[--nmap];
        else i++;
    }
}
static void map_put(const char *k, const char *v) {
    if (nmap < 2048) { snprintf(map[nmap].k, 96, "%s", k); snprintf(map[nmap].v, 96, "%s", v); nmap++; }
}
static int subst(char *operand, OptStats *s) {
    if (!*operand || is_const(operand)) return 0;
    const char *v = map_get(operand);
    if (v) { snprintf(operand, 96, "%s", v); s->propagated++; return 1; }
    return 0;
}
static int pass_fold_propagate(TAC *t, OptStats *s) {
    int changes = 0; nmap = 0;
    for (int i = 0; i < t->n; i++) {
        Quad *q = &t->q[i];
        if (q->op == Q_LABEL) { nmap = 0; continue; }      /* new basic block */
        if (reads_a1(q->op)) changes += subst(q->a1, s);
        if (reads_a2(q->op)) changes += subst(q->a2, s);
        if (is_binary(q->op) && is_const(q->a1) && is_const(q->a2)) {
            int r;
            if (eval_op(q->op, atoi(q->a1), atoi(q->a2), &r)) {
                snprintf(q->a1, 96, "%d", r); q->a2[0] = 0; q->op = Q_ASSIGN;
                s->folded++; changes++;
            }
        } else if ((q->op == Q_NEG || q->op == Q_NOT) && is_const(q->a1)) {
            int v = atoi(q->a1);
            snprintf(q->a1, 96, "%d", q->op == Q_NEG ? (int)(0u - (unsigned)v) : !v);
            q->op = Q_ASSIGN; s->folded++; changes++;
        } else if (q->op == Q_IFFALSE && is_const(q->a1)) {
            if (atoi(q->a1) != 0) del[i] = 1;               /* never jumps */
            else { q->op = Q_GOTO; q->a1[0] = 0; }          /* always jumps */
            s->folded++; changes++;
        }
        if (del[i]) continue;
        if (defines(q->op)) {
            map_kill(q->res);
            if (q->op == Q_ASSIGN && strcmp(q->a1, q->res)) map_put(q->res, q->a1);
        }
    }
    compact(t);
    return changes;
}
/* ---------- algebraic simplification & strength reduction ---------- */
static void to_assign(Quad *q, const char *v) {
    char tmp[96]; snprintf(tmp, sizeof tmp, "%s", v);
    q->op = Q_ASSIGN; snprintf(q->a1, 96, "%s", tmp); q->a2[0] = 0;
}
static int pass_algebraic(TAC *t, OptStats *s) {
    int ch = 0;
    for (int i = 0; i < t->n; i++) {
        Quad *q = &t->q[i];
        if (!is_binary(q->op)) continue;
        int z1 = !strcmp(q->a1, "0"), z2 = !strcmp(q->a2, "0");
        int o1 = !strcmp(q->a1, "1"), o2 = !strcmp(q->a2, "1");
        int t1 = !strcmp(q->a1, "2"), t2 = !strcmp(q->a2, "2");
        char a1[96], a2[96];
        snprintf(a1, 96, "%s", q->a1); snprintf(a2, 96, "%s", q->a2);
        switch (q->op) {
        case Q_ADD:
            if (z2) { to_assign(q, a1); s->algebraic++; ch++; }
            else if (z1) { to_assign(q, a2); s->algebraic++; ch++; }
            break;
        case Q_SUB:
            if (z2) { to_assign(q, a1); s->algebraic++; ch++; }
            else if (!is_const(a1) && !strcmp(a1, a2)) { to_assign(q, "0"); s->algebraic++; ch++; }







            break;
        case Q_MUL:
            if (z1 || z2) { to_assign(q, "0"); s->algebraic++; ch++; }
            else if (o2) { to_assign(q, a1); s->algebraic++; ch++; }
            else if (o1) { to_assign(q, a2); s->algebraic++; ch++; }
            else if (t2) { q->op = Q_ADD; snprintf(q->a2, 96, "%s", a1); s->strength++; ch++; }
            else if (t1) { q->op = Q_ADD; snprintf(q->a1, 96, "%s", a2); s->strength++; ch++; }
            break;
        case Q_DIV:
            if (o2) { to_assign(q, a1); s->algebraic++; ch++; }
            break;
        case Q_MOD:
            if (o2) { to_assign(q, "0"); s->algebraic++; ch++; }
            break;
        default: break;
        }
    }
    return ch;
}
/* ---------- unreachable code / redundant jumps ---------- */
static int pass_unreachable(TAC *t, OptStats *s) {
    int ch = 0, dead = 0;
    for (int i = 0; i < t->n; i++) {
        Quad *q = &t->q[i];
        if (q->op == Q_LABEL) { dead = 0; continue; }
        if (dead) { del[i] = 1; s->unreachable++; ch++; continue; }
        if (q->op == Q_GOTO) dead = 1;
    }
    /* goto L / ifFalse x goto L immediately followed by L: -> remove the jump */
    for (int i = 0; i < t->n; i++) {
        if (del[i]) continue;
        Quad *q = &t->q[i];
        if (q->op != Q_GOTO && q->op != Q_IFFALSE) continue;
        for (int j = i + 1; j < t->n; j++) {
            if (del[j]) continue;
            if (t->q[j].op != Q_LABEL) break;
            if (!strcmp(t->q[j].res, q->res)) { del[i] = 1; s->jumps++; ch++; break; }
        }
    }
    compact(t);
    return ch;
}
static int pass_labels(TAC *t, OptStats *s) {
    int ch = 0;
    for (int i = 0; i < t->n; i++) {
        if (t->q[i].op != Q_LABEL) continue;
        int refs = 0;
        for (int j = 0; j < t->n; j++)
            if ((t->q[j].op == Q_GOTO || t->q[j].op == Q_IFFALSE) && !strcmp(t->q[j].res, t->q[i].res)) refs++;
        if (!refs) { del[i] = 1; s->labels++; ch++; }
    }
    compact(t);
    return ch;
}
/* ---------- dead code elimination ---------- */
static int uses_of(TAC *t, const char *name) {
    int u = 0;
    for (int i = 0; i < t->n; i++) {
        Quad *q = &t->q[i];
        if (reads_a1(q->op) && !strcmp(q->a1, name)) u++;
        if (reads_a2(q->op) && !strcmp(q->a2, name)) u++;
    }
    return u;
}
static int pass_dead(TAC *t, OptStats *s) {
    int ch = 0;
    for (int i = 0; i < t->n; i++) {
        Quad *q = &t->q[i];
        if (!defines(q->op)) continue;
        int self_copy = (q->op == Q_ASSIGN && !strcmp(q->a1, q->res));
        if (self_copy || uses_of(t, q->res) == 0) { del[i] = 1; s->dead++; ch++; }
    }







    compact(t);
    return ch;
}
/* ---------- copy coalescing (peephole) ---------- */
static int pass_coalesce(TAC *t, OptStats *s) {
    int ch = 0;
    for (int i = 0; i + 1 < t->n; i++) {
        Quad *q = &t->q[i], *n = &t->q[i + 1];
        if (del[i] || del[i + 1]) continue;
        if (!defines(q->op) || q->res[0] != '_' ) continue;          /* only compiler temporaries */
        if (n->op != Q_ASSIGN || strcmp(n->a1, q->res)) continue;
        if (uses_of(t, q->res) != 1) continue;                       /* the temp is used only by the copy */
        snprintf(q->res, 96, "%s", n->res);
        del[i + 1] = 1; s->coalesced++; ch++;
    }
    compact(t);
    return ch;
}
void optimize(TAC *t, OptStats *s) {
    memset(s, 0, sizeof *s);
    memset(del, 0, sizeof del);
    s->before = t->n;
    for (int iter = 0; iter < 30; iter++) {
        int ch = 0;
        ch += pass_fold_propagate(t, s);
        ch += pass_algebraic(t, s);
        ch += pass_unreachable(t, s);
        ch += pass_labels(t, s);
        ch += pass_dead(t, s);
        ch += pass_coalesce(t, s);
        if (!ch) break;
    }
    s->after = t->n;
}
void print_opt_report(FILE *f, OptStats *s) {
    fprintf(f, "Constant folding            : %d\n", s->folded);
    fprintf(f, "Constant/copy propagation   : %d\n", s->propagated);
    fprintf(f, "Algebraic simplification    : %d\n", s->algebraic);
    fprintf(f, "Strength reduction (x*2->x+x): %d\n", s->strength);
    fprintf(f, "Dead code eliminated        : %d\n", s->dead);
    fprintf(f, "Unreachable code removed    : %d\n", s->unreachable);
    fprintf(f, "Redundant jumps removed     : %d\n", s->jumps);
    fprintf(f, "Unused labels removed       : %d\n", s->labels);
    fprintf(f, "Copies coalesced (peephole) : %d\n", s->coalesced);
    fprintf(f, "TAC instructions            : %d -> %d (%d removed)\n",
            s->before, s->after, s->before - s->after);
}
