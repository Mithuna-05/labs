#!/usr/bin/env bash
# Command-line demo: compile a MiniLang file and show every phase.
#   ./run_cli.sh examples/02_factorial.mc [output-dir]
set -u







cd "$(dirname "$0")"
[ $# -ge 1 ] || { echo "usage: $0 <program.mc> [outdir]"; exit 2; }
src=$1; out=${2:-output/$(basename "$src" .mc)}
make -s || exit 1
rm -rf "$out"; mkdir -p "$out"
./build/minicc "$src" "$out"; rc=$?
[ $rc -eq 2 ] && { echo "compiler could not run (I/O error)"; exit 2; }
hr() { printf '\n==================== %s ====================\n' "$1"; }
hr "SOURCE";                  cat -n "$src"
hr "1. TOKENS (line|col|type|lexeme)"; cat "$out/tokens.txt"
hr "DIAGNOSTICS";             [ -s "$out/errors.txt" ] && cat "$out/errors.txt" || echo "none"
if [ $rc -ne 0 ]; then echo; echo "Compilation failed (see diagnostics above)."; exit 1; fi
hr "3. AST";                  cat "$out/ast.txt"
hr "4. SYMBOL TABLE (name|unique|type|scope|line|assigned|read)"; cat "$out/symtab.txt"
hr "5. THREE ADDRESS CODE"; cat "$out/tac.txt"
hr "6. OPTIMISED TAC";        cat "$out/tac_opt.txt"; echo; cat "$out/opt_report.txt"
hr "7. TARGET: C";            cat "$out/out.c"
hr "7. TARGET: x86-64";       cat "$out/out_x86_64.s"
hr "7. TARGET: ARM64";        cat "$out/out_aarch64.s"
hr "7. TARGET: RISC-V";       cat "$out/out_riscv64.s"
hr "8. EXECUTION"
echo "[reference interpreter]"; cat "$out/run_output.txt"
have() { command -v "$1" >/dev/null 2>&1; }
if have gcc; then
   gcc -fwrapv -o "$out/c.bin" "$out/out.c" && { echo "[C, native]"; "$out/c.bin"; }
   if [ "$(uname -m)" = x86_64 ]; then
      gcc -o "$out/x86.bin" "$out/out_x86_64.s" && { echo "[x86-64 assembly, native]"; "$out/x86.bin"; }
   fi
fi
if have aarch64-linux-gnu-gcc && have qemu-aarch64; then
   aarch64-linux-gnu-gcc -o "$out/arm.bin" "$out/out_aarch64.s" && { echo "[ARM64 assembly, cross-built, run under QEMU]"; file -b "$out/arm.bin" 2>/dev/null; qemu-aarch64 -L /usr/aarch64-linux-gnu "$out/arm.bin"; }
else echo "[ARM64: install gcc-aarch64-linux-gnu qemu-user to execute]"; fi
if have riscv64-linux-gnu-gcc && have qemu-riscv64; then
   riscv64-linux-gnu-gcc -o "$out/rv.bin" "$out/out_riscv64.s" && { echo "[RISC-V assembly, cross-built, run under QEMU]"; file -b "$out/rv.bin" 2>/dev/null; qemu-riscv64 -L /usr/riscv64-linux-gnu "$out/rv.bin"; }
else echo "[RISC-V: install gcc-riscv64-linux-gnu qemu-user to execute]"; fi
