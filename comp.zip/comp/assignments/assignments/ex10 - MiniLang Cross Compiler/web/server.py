#!/usr/bin/env python3
"""
server.py - Web platform for the MiniLang cross compiler (Python standard library only).
python3 web/server.py [--port 8000] [--host 127.0.0.1]
Endpoints
GET /                 -> the user interface (index.html)
GET /api/examples     -> list of bundled example programs
GET /api/toolchain    -> which targets can be executed on this machine
POST /api/compile     -> {"source": "..."} runs the compiler and the generated programs
"""
import argparse, json, os, platform, shutil, subprocess, tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMPILER = os.path.join(ROOT, "build", "minicc")
EXAMPLES = os.path.join(ROOT, "examples")
INDEX = os.path.join(ROOT, "web", "index.html")
MACHINE = platform.machine().lower()
MAX_SOURCE = 100_000
RUN_TIMEOUT = 5
# How each assembly target is built and executed on this host.
ARCHS = {
    "x86_64": dict(label="x86-64", native={"x86_64", "amd64"}, gcc="x86_64-linux-gnu-gcc",
                    qemu="qemu-x86_64", sysroot="/usr/x86_64-linux-gnu"),
    "aarch64": dict(label="ARM64",   native={"aarch64", "arm64"}, gcc="aarch64-linux-gnu-gcc",
                    qemu="qemu-aarch64", sysroot="/usr/aarch64-linux-gnu"),







    "riscv64": dict(label="RISC-V", native={"riscv64"},           gcc="riscv64-linux-gnu-gcc",
                    qemu="qemu-riscv64", sysroot="/usr/riscv64-linux-gnu"),
}
def plan(arch):
    """Return (build_cmd_prefix, run_prefix, mode) or (None, None, reason)."""
    a = ARCHS[arch]
    if MACHINE in a["native"] and shutil.which("gcc"):
        return ["gcc"], [], "native"
    if shutil.which(a["gcc"]) and shutil.which(a["qemu"]):
        run = [a["qemu"]]
        if os.path.isdir(a["sysroot"]):
            run += ["-L", a["sysroot"]]
        return [a["gcc"]], run, "cross + QEMU emulation"
    need = f'{a["gcc"]} and {a["qemu"]}'
    return None, None, f"not executed - install {need} (Ubuntu: gcc-{a['gcc'].split('-gcc')[0]} qemu-user)"
def sh(cmd, timeout=RUN_TIMEOUT, cwd=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return p.returncode, (p.stdout + p.stderr)[:20000]
    except subprocess.TimeoutExpired:
        return 124, f"[timed out after {timeout}s]"
    except OSError as e:
        return 127, str(e)
def build_and_run(arch, asm, workdir):
    """arch: 'c' or a key of ARCHS. Returns a dict describing build + execution."""
    res = {"status": "skipped", "output": "", "mode": "", "command": "", "binary": ""}
    exe = os.path.join(workdir, f"prog_{arch}")
    if arch == "c":
        prefix, runp, mode = ["gcc", "-fwrapv"], [], "native"
        if not shutil.which("gcc"):
            res["mode"] = "gcc not found"; return res
    else:
        prefix, runp, mode = plan(arch)
        if prefix is None:
            res["mode"] = mode; return res
    cmd = prefix + ["-o", exe, asm]
    res["command"] = " ".join(os.path.basename(c) if c.startswith("/") else c for c in cmd[:1]) + \
        f" {os.path.basename(asm)} -o prog" + (f"   |   run: {' '.join(runp)} ./prog" if runp else "   |   run: ./prog")
    rc, out = sh(cmd, timeout=20, cwd=workdir)
    if rc != 0:
        res.update(status="error", output=out, mode=mode); return res
    if shutil.which("file"):
        res["binary"] = sh(["file", "-b", exe])[1].strip()
    rc, out = sh(runp + [exe])
    res.update(status="ok" if rc == 0 else "error", output=out, mode=mode)
    return res
def read(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""
def compile_source(source):
    if not os.path.exists(COMPILER):
        return {"fatal": "Compiler binary not found. Run `make` in the project folder first."}
    work = tempfile.mkdtemp(prefix="minicc_")
    try:
        src = os.path.join(work, "input.mc")
        out = os.path.join(work, "out")
        with open(src, "w", encoding="utf-8") as f:
            f.write(source)
        rc, log = sh([COMPILER, src, out], timeout=15)
        if rc not in (0, 1):
            return {"fatal": f"Compiler crashed or failed (exit {rc}): {log}"}







        def table(name, n):
            rows = []
            for line in read(os.path.join(out, name)).splitlines():
                parts = line.split("|", n - 1)
                if len(parts) == n:
                    rows.append(parts)
            return rows
        tokens = [dict(line=int(a), col=int(b), type=c, lexeme=d) for a, b, c, d in table("tokens.txt", 4)]
        diags = [dict(level=a, phase=b, line=int(c), message=d) for a, b, c, d in table("errors.txt", 4)]
        symtab = [dict(name=a, unique=b, type=c, scope=int(d), line=int(e), init=f, used=g)
                for a, b, c, d, e, f, g in table("symtab.txt", 7)]
        has_err = any(d["level"] == "ERROR" for d in diags)
        phases_err = {d["phase"] for d in diags if d["level"] == "ERROR"}
        result = dict(
            success=(rc == 0), tokens=tokens, diagnostics=diags, symtab=symtab,
            ast=read(os.path.join(out, "ast.txt")),
            tac=read(os.path.join(out, "tac.txt")),
            tac_opt=read(os.path.join(out, "tac_opt.txt")),
            opt_report=read(os.path.join(out, "opt_report.txt")),
            reference_output=read(os.path.join(out, "run_output.txt")),
            phases={},
            targets={},
            host=dict(machine=MACHINE, system=platform.system()),
        )
        front = bool(phases_err & {"lexical", "syntax"})
        later = "skipped" if has_err else "ok"
        result["phases"] = dict(
            lexical="fail" if "lexical" in phases_err else "ok",
            syntax="fail" if "syntax" in phases_err else "ok",
            ast="skipped" if front else "ok",
            semantic="fail" if "semantic" in phases_err else ("skipped" if front else "ok"),
            tac=later, optimize=later, codegen=later)
        if has_err:
            return result
        specs = [("c", "C", "out.c"), ("x86_64", "x86-64 Assembly", "out_x86_64.s"),
                ("aarch64", "ARM64 Assembly", "out_aarch64.s"), ("riscv64", "RISC-V Assembly", "out_riscv64.s"
        )]
        for key, label, fname in specs:
            path = os.path.join(out, fname)
            r = build_and_run(key, path, out)
            r["label"] = label
            r["filename"] = fname
            r["code"] = read(path)
            r["matches"] = (r["status"] == "ok" and r["output"] == result["reference_output"])
            result["targets"][key] = r
        return result
    finally:
        shutil.rmtree(work, ignore_errors=True)
class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send(200, read(INDEX), "text/html")
        elif self.path == "/api/examples":
            items = []
            if os.path.isdir(EXAMPLES):
                for n in sorted(os.listdir(EXAMPLES)):
                    if n.endswith(".mc"):
                        items.append(dict(name=n[:-3], source=read(os.path.join(EXAMPLES, n))))
            self._send(200, json.dumps(items))
        elif self.path == "/api/toolchain":







            info = {"c": {"label": "C", "available": bool(shutil.which("gcc")), "mode": "native gcc"}}
            for k, a in ARCHS.items():
                p, _, mode = plan(k)
                info[k] = {"label": a["label"], "available": p is not None, "mode": mode}
            self._send(200, json.dumps(dict(host=MACHINE, targets=info)))
        else:
            self._send(404, json.dumps({"error": "not found"}))
    def do_POST(self):
        if self.path != "/api/compile":
            return self._send(404, json.dumps({"error": "not found"}))
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n > MAX_SOURCE * 2:
                return self._send(413, json.dumps({"fatal": "source too large"}))
            payload = json.loads(self.rfile.read(n) or b"{}")
            source = str(payload.get("source", ""))
            if len(source) > MAX_SOURCE:
                return self._send(413, json.dumps({"fatal": "source too large"}))
            self._send(200, json.dumps(compile_source(source)))
        except Exception as e: # keep the server alive whatever happens
            self._send(500, json.dumps({"fatal": f"server error: {e}"}))
    def log_message(self, fmt, *args):
        pass
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    if not os.path.exists(COMPILER):
        print("!! build/minicc not found - run `make` first")
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    print(f"MiniLang cross compiler platform running at http://{a.host}:{a.port}   (Ctrl+C to stop)")
    print(f"Host architecture: {MACHINE}")
    for k in ARCHS:
        p, _, mode = plan(k)
        print(f" {ARCHS[k]['label']:8s}: {'can execute (' + mode + ')' if p else mode}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")
if __name__ == "__main__":
    main()
