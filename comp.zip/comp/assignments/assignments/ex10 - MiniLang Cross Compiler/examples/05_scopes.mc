// Block scoping: inner x shadows outer x
int x = 10;
{
    int x = 20;
    print(x);
    x = x + 1;
    print(x);
}
print(x);
if (x > 5 && !(x == 7)) { print(1); } else { print(0); }




     B.6 GCD example
