int a = 5
int b = ;
print(a + );
if (a > 2 { print(a); }




     B.10 Semantic-error example
