// Constant folding, propagation, strength reduction demo
int a = 2 + 3 * 4;      // folds to 14
int b = a * 2;          // propagates, strength reduction
int c = b - b + 7;      // algebraic simplification
int unused = 99;        // dead code
print(a);
print(b);
print(c);
print(-a + 20);
print(17 % 5);




     B.2 Factorial example
