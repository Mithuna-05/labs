// Loop keeps values unknown at compile time, so these optimisations survive:
//   i * 2 -> i + i (strength reduction), i + 0, i * 1 (algebraic), dead store
int i = 0;
int total = 0;
int junk = 0;
while (i < 5) {
    int d = i * 2;          // strength reduction
    int e = d + 0;          // algebraic simplification
    int f = e * 1;          // algebraic simplification
    junk = f * 3;           // dead store (junk is never read)
    total = total + f;
    i = i + 1;
}
print(total);
if (3 > 5) { print(111); } // unreachable: condition folds to false
else { print(222); }




     B.8 Lexical-error example
