// First 10 Fibonacci numbers
int a = 0;







int b = 1;
int count = 0;
while (count < 10) {
    print(a);
    int next = a + b;
    a = b;
    b = next;
    count = count + 1;
}




     B.4 Prime-number example
