int a = 5;
int a = 6;
b = a + 1;
print(c);
int z = a / 0;




     C Representative Compiler Output Logs

     C.1 Factorial run


     ==================== SOURCE ====================
// Factorial of 6 using a while loop
int n = 6;
int fact = 1;
int i = 1;
while (i <= n) {
  fact = fact * i;
  i = i + 1;






}
print(fact);






















     int n = 0, fact = 0, i = 0, _t1 = 0;
     n = 6;
     fact = 1;
     i = 1;
     _t1 = i <= n;
     if (!(_t1)) goto L2;
     fact = fact * i;
     i = i + 1;
     goto L1;
     printf("%d\n", fact);
     return 0;



























// Loop keeps values unknown at compile time, so these optimisations survive:
//    i * 2 -> i + i (strength reduction), i + 0, i * 1 (algebraic), dead store
int i = 0;
int total = 0;
int junk = 0;
while (i < 5) {
  int d = i * 2;          // strength reduction
  int e = d + 0;          // algebraic simplification
  int f = e * 1;          // algebraic simplification
   junk = f * 3;           // dead store (junk is never read)
   total = total + f;
   i = i + 1;
}
print(total);
if (3 > 5) { print(111); } // unreachable: condition folds to false






else { print(222); }















        `-- Print
            `-- Num 222








      print 222




     int i = 0, total = 0, _t1 = 0, _t3 = 0;
     i = 0;
     total = 0;
     _t1 = i < 5;
     if (!(_t1)) goto L2;
     _t3 = i + i;
     total = total + _t3;
     i = i + 1;
     goto L1;
     printf("%d\n", total);
     printf("%d\n", 222);
     return 0;

































int a = 5 @ 3;
print(a);














int a = 5
int b = ;
print(a + );
if (a > 2 { print(a); }








int a = 5;
int a = 6;
b = a + 1;







print(c);
int z = a / 0;
