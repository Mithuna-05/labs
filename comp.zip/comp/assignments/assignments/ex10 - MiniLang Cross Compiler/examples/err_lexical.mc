int a = 5 @ 3;
print(a);




     B.9 Syntax-error example
