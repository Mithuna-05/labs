// Factorial of 6 using a while loop
int n = 6;
int fact = 1;
int i = 1;
while (i <= n) {
    fact = fact * i;
    i = i + 1;
}
print(fact);




     B.3 Fibonacci example
