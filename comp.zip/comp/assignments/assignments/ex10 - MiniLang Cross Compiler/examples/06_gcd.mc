// Euclid's GCD of 48 and 18
int a = 48;
int b = 18;
while (b != 0) {
    int t = b;
    b = a % b;
    a = t;
}
print(a);




     B.7 Optimizer demonstration
