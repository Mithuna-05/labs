// Print primes up to 30 (nested loops, if/else, %, &&)
int n = 2;
while (n <= 30) {
    int d = 2;
    int isPrime = 1;
    while (d * d <= n && isPrime == 1) {
        if (n % d == 0) { isPrime = 0; } else { d = d + 1; }
    }
    if (isPrime) print(n);
    n = n + 1;
}




     B.5 Scope example
