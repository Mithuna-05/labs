#!/usr/bin/env bash
# Compiles every example, then builds + runs the generated program for every
# target that has a toolchain on this machine and compares with the reference
# interpreter output. Usage: tests/run_tests.sh    (from the project root)
cd "$(dirname "$0")/.." || exit 1
make -s || exit 1
pass=0; fail=0; skip=0
have() { command -v "$1" >/dev/null 2>&1; }
check() { # name expected actual
  if [ "$2" == "$3" ]; then pass=$((pass+1)); echo "    PASS $1"; else fail=$((fail+1)); echo "     FAIL   $1"; fi
}
for src in examples/0*.mc; do
  n=$(basename "$src" .mc); out=build/test_$n; rm -rf "$out"
  echo "== $n"
  ./build/minicc "$src" "$out" || { echo "    compile failed"; fail=$((fail+1)); continue; }
  exp=$(cat "$out/run_output.txt")
  if have gcc; then
     gcc -fwrapv -o "$out/c.bin" "$out/out.c" && check "C              " "$exp" "$("$out/c.bin")"
     if [ "$(uname -m)" == "x86_64" ]; then
       gcc -o "$out/x86.bin" "$out/out_x86_64.s" && check "x86-64         " "$exp" "$("$out/x86.bin")"
     else skip=$((skip+1)); echo "   SKIP x86-64 (host is not x86-64)"; fi
  fi
  if have aarch64-linux-gnu-gcc && have qemu-aarch64; then
     aarch64-linux-gnu-gcc -o "$out/arm.bin" "$out/out_aarch64.s" && \
       check "ARM64 (qemu)   " "$exp" "$(qemu-aarch64 -L /usr/aarch64-linux-gnu "$out/arm.bin")"
  else skip=$((skip+1)); echo "    SKIP ARM64 (install gcc-aarch64-linux-gnu qemu-user)"; fi
  if have riscv64-linux-gnu-gcc && have qemu-riscv64; then
     riscv64-linux-gnu-gcc -o "$out/rv.bin" "$out/out_riscv64.s" && \
       check "RISC-V (qemu) " "$exp" "$(qemu-riscv64 -L /usr/riscv64-linux-gnu "$out/rv.bin")"
  else skip=$((skip+1)); echo "    SKIP RISC-V (install gcc-riscv64-linux-gnu qemu-user)"; fi
done







echo; echo "passed=$pass failed=$fail skipped=$skip"
[ $fail -eq 0 ]
