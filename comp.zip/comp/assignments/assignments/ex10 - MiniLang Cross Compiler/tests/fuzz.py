#!/usr/bin/env python3
"""
Differential fuzz test. MiniLang is a subset of C, so every random program can
also be compiled by gcc as ground truth. For each program we compare:
    gcc(reference) vs reference interpreter vs generated C vs generated x86-64
    (and ARM64 / RISC-V under QEMU for every 5th program when available).
usage: python3 tests/fuzz.py [count] [seed]
"""
import os, random, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CC = os.path.join(ROOT, "build", "minicc")
N = int(sys.argv[1]) if len(sys.argv) > 1 else 100
rnd = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
have = shutil.which
X86 = os.uname().machine == "x86_64"
def expr(vs, d=0):
    r = rnd.random()
    if d >= 3 or r < 0.25:
        return str(rnd.randint(0, 20)) if (not vs or rnd.random() < 0.35) else rnd.choice(vs)
    if r < 0.33: return f"(-{expr(vs, d+1)})"
    if r < 0.40: return f"(!{expr(vs, d+1)})"
    op = rnd.choice(["+", "-", "*", "<", ">", "<=", ">=", "==", "!=", "&&", "||", "/", "%"])
    if op in "/%": return f"({expr(vs, d+1)} {op} {rnd.randint(1, 7)})"
    return f"({expr(vs, d+1)} {op} {expr(vs, d+1)})"
cnt = 0
def block(vs, depth, n):
    global cnt
    out, vs = [], list(vs)
    for _ in range(n):
        r = rnd.random()
        if r < 0.25 or not vs:
            cnt += 1; name = f"v{cnt}"
            out.append(f"int {name} = {expr(vs)};"); vs.append(name)
        elif r < 0.50: out.append(f"{rnd.choice(vs)} = {expr(vs)};")
        elif r < 0.65: out.append(f"print({expr(vs)});")
        elif r < 0.80 and depth < 3:
            c = f"if ({expr(vs)}) {{\n{block(vs, depth+1, 3)}\n}}"
            if rnd.random() < 0.5: c += f" else {{\n{block(vs, depth+1, 3)}\n}}"
            out.append(c)
        elif depth < 2:
            cnt += 1; c = f"w{cnt}"
            out.append(f"int {c} = 0;\nwhile ({c} < {rnd.randint(1,5)}) {{\n{block(vs, depth+1, 3)}\n{c} = {c} + 1;\n}}")
        else: out.append(f"print({expr(vs)});")
    return "\n".join(out)
def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=20, **kw)
bad = 0
tmp = tempfile.mkdtemp()
for k in range(N):
    global_cnt = 0; cnt = 0
    src = block([], 0, 8) + "\n"
    d = os.path.join(tmp, f"p{k}"); os.makedirs(d)
    open(f"{d}/p.mc", "w").write(src)
    open(f"{d}/ref.c", "w").write('#include <stdio.h>\n#define print(x) printf("%d\\n",(x))\nint main(void){\n'
        + src + "return 0;}\n")
    sh(["gcc", "-fwrapv", "-w", "-o", f"{d}/ref", f"{d}/ref.c"])
    truth = sh([f"{d}/ref"]).stdout
    r = sh([CC, f"{d}/p.mc", f"{d}/o"])







    fails = []
    if r.returncode != 0: fails.append("minicc failed: " + open(f"{d}/o/errors.txt").read()[:200])
    else:
        if open(f"{d}/o/run_output.txt").read() != truth: fails.append("interpreter")
        sh(["gcc", "-fwrapv", "-o", f"{d}/c", f"{d}/o/out.c"])
        if sh([f"{d}/c"]).stdout != truth: fails.append("C target")
        if X86:
            sh(["gcc", "-o", f"{d}/x", f"{d}/o/out_x86_64.s"])
            if sh([f"{d}/x"]).stdout != truth: fails.append("x86-64 target")
        if k % 5 == 0:
            if have("aarch64-linux-gnu-gcc") and have("qemu-aarch64"):
                sh(["aarch64-linux-gnu-gcc", "-o", f"{d}/a", f"{d}/o/out_aarch64.s"])
                if sh(["qemu-aarch64", "-L", "/usr/aarch64-linux-gnu", f"{d}/a"]).stdout != truth: fails.append("ARM64 target")
            if have("riscv64-linux-gnu-gcc") and have("qemu-riscv64"):
                sh(["riscv64-linux-gnu-gcc", "-o", f"{d}/r", f"{d}/o/out_riscv64.s"])
                if sh(["qemu-riscv64", "-L", "/usr/riscv64-linux-gnu", f"{d}/r"]).stdout != truth: fails.append("RISC-V target")
    if fails:
        bad += 1; print(f"FAIL program {k}: {fails}\n kept in {d}")
    else:
        shutil.rmtree(d)
print(f"{N - bad}/{N} random programs agree with gcc" + ("" if not bad else f" ({bad} FAILED)"))
sys.exit(1 if bad else 0)
