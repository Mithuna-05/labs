#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct Node {
    char value[10];
    struct Node *left, *middle, *right;
} Node;

char input[200];
int pos, error;

Node *create(char *value, Node *left,
              Node *middle, Node *right)
{
    Node *n = malloc(sizeof(Node));
    strcpy(n->value, value);
    n->left = left;
    n->middle = middle;
    n->right = right;
    return n;
}

void skipSpaces()
{
    while (isspace((unsigned char)input[pos]))
        pos++;
}


Node *parseS();

Node *parseL()
{
    Node *left = parseS();
    if (left == NULL)
        return NULL;

    skipSpaces();

    if (input[pos] == ',') {
        pos++;
        Node *comma = create(",", NULL, NULL, NULL);
        Node *right = parseS();

        if (right == NULL)
            return NULL;

        return create("L", left,
                      comma, right);
    }

    return create("L", left, NULL, NULL);
}

Node *parseS()
{
    skipSpaces();

    if (input[pos] == 'a') {
        pos++;
        return create("S", create("a", NULL, NULL, NULL),
                      NULL, NULL);
    }

    if (input[pos] == '(') {
        pos++;

        Node *lparen = create("(", NULL, NULL, NULL);
        Node *list = parseL();

        skipSpaces();

        if (list == NULL || input[pos] != ')') {
            error = 1;
            return NULL;
        }

        pos++;

        Node *rparen = create(")", NULL, NULL, NULL);

        return create("S", lparen, list, rparen);
    }

     error = 1;
     return NULL;
 }

 void printTree(Node *n, int level)
 {
     if (n == NULL)
         return;

     for (int i = 0; i < level; i++)
         printf(" ");

     printf("%s\n", n->value);

    printTree(n->left, level + 1);
    printTree(n->middle, level + 1);
    printTree(n->right, level + 1);
}

void showTable()
{
    char terminals[] = {'(', ')', ',', 'a', '$'};
    char table[5][5] = {
        {'<', '=', '<', '<', ' '},
        {' ', '>', '>', ' ', '>'},
        {'<', '>', '>', '<', '>'},
        {' ', '>', '>', ' ', '>'},
        {'<', ' ', ' ', '<', '='}
    };

    printf("\nOperator Precedence Table:\n\n");
    printf("    (   )   ,   a   $\n");

    for (int i = 0; i < 5; i++) {
        printf("%c   ", terminals[i]);

        for (int j = 0; j < 5; j++) {
            if (table[i][j] == ' ')
                 printf("-  ");
            else
                 printf("%c  ", table[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    printf("Grammar:\n");
    printf("S -> (L) | a\n");
    printf("L -> L,S | S\n");

    printf("\nTerminals: ( ) , a\n");
    printf("Non-terminals: S L\n");
    printf("Start symbol: S\n");

    showTable();

    char *tests[] = {
        "(a,a)",
        "(a,(a,a))",
        "(a,((a,a),(a,a)))"
    };

    for (int i = 0; i < 3; i++) {
        strcpy(input, tests[i]);
        pos = 0;
        error = 0;

        printf("\nInput: %s\n", input);

        Node *root = parseS();
        skipSpaces();

        if (!error && input[pos] == '\0') {
            printf("String accepted.\n");
            printf("Parse Tree:\n");
            printTree(root, 0);
        } else {
            printf("String rejected.\n");
        }
    }

    return 0;
}
