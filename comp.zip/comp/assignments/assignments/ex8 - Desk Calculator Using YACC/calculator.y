%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);
int yyerror(const char *s);
%}

%token NUM
%left '+' '-'
%left '*' '/'
%left UMINUS

%%
input:
      /* empty */
    | input line
    ;

line:
      '\n'
    | expr '\n' { printf("Result = %d\n", $1); }
    ;

expr:
      NUM                  { $$ = $1; }
    | expr '+' expr        { $$ = $1 + $3; }
    | expr '-' expr        { $$ = $1 - $3; }
    | expr '*' expr        { $$ = $1 * $3; }
    | expr '/' expr        { if ($3 == 0) { yyerror("Division by zero"); YYABORT; } $$ = $1 / $3; }
    | '-' expr %prec UMINUS { $$ = -$2; }
    | '(' expr ')'         { $$ = $2; }
    ;
%%

int main(void)
{
    printf("Desk Calculator using YACC\n");
    printf("Enter expressions (Ctrl+D to exit):\n");
    return yyparse();
}

int yyerror(const char *s)
{
    fprintf(stderr, "Error: %s\n", s);
    return 0;
}
