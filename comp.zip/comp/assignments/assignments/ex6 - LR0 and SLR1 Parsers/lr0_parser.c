#include <stdio.h>
#include <string.h>

#define MAX 100

int stack[MAX], top = -1;

void push(int state) {
    if (top < MAX - 1)
        stack[++top] = state;
}

int main(void) {
    int action[6][3] = {
        {4, 0, 0},
        {0, 3, 100},
        {0, -2, -2},
        {4, 0, 0},
        {0, -3, -3},
        {0, -1, -1}
    };

    int go[6][2] = {
        {1, 2},
        {-1, -1},
        {-1, -1},
        {-1, 5},
        {-1, -1},
        {-1, -1}
    };

    int len[] = {0, 3, 1, 1};
    char input[MAX];
    int ip = 0;

    printf("Enter input (use i for id and end with $): ");
    scanf("%99s", input);

    if (input[strlen(input) - 1] != '$') {
        printf("Input must end with $\n");
        return 0;
    }

    for (int i = 0; input[i]; i++) {
        if (input[i] != 'i' &&
            input[i] != '+' && input[i] != '$') {
            printf("Invalid symbol\n");
            return 0;
        }
    }

    push(0);
    printf("\nStack\tInput\tAction\n");


    while (1) {
        for (int i = 0; i <= top; i++)
            printf("%d ", stack[i]);

        printf("\t%s\t", input + ip);

        char c = input[ip];
        int col = c == 'i' ? 0 : c == '+' ? 1 : 2;
        int a = action[stack[top]][col];

        if (a == 0) {
            printf("Reject\nString rejected.\n");
            break;
        }

        if (a == 100) {
            printf("Accept\nString accepted.\n");
            break;
        }

        if (a > 0) {
            printf("Shift %d\n", a);
            push(a);
            ip++;
        } else {
            int r = -a;
            char lhs = r == 3 ? 'T' : 'E';

            printf("Reduce by rule %d\n", r);
            top -= len[r];

            int nt = lhs == 'E' ? 0 : 1;
            int next = go[stack[top]][nt];

            if (next < 0) {
                printf("Invalid GOTO\n");
                break;
            }

            push(next);
        }
    }

    return 0;
}
