#include <stdio.h>
#include <string.h>

#define MAX 100
#define MAX_STATES 100
#define MAX_ITEMS 100
#define MAX_PROD 8

typedef struct {
    int p, dot;
} Item;

typedef struct {
    Item item[MAX_ITEMS];
    int n;
} State;

/* Productions:

   0: Q -> E
   1: E -> E+T
   2: E -> T
   3: T -> TF
   4: T -> F
   5: F -> F*
   6: F -> a
   7: F -> b
*/
char lhs[MAX_PROD] = {'Q','E','E','T','T','F','F','F'};
char rhs[MAX_PROD][5] = {"E","E+T","T","TF","F","F*","a","b"};
int len[MAX_PROD] = {1,3,1,2,1,2,1,1};

State states[MAX_STATES];
int trans[MAX_STATES][128];
int nstates = 0;

int action[MAX_STATES][5];
int go[MAX_STATES][3];

char terminals[] = "+*ab$";
char nonterminals[] = "ETF";

int isNT(char c) {
    return c == 'Q' || c == 'E' ||
           c == 'T' || c == 'F';
}

int ntIndex(char c) {
    if (c == 'E') return 0;
    if (c == 'T') return 1;
    if (c == 'F') return 2;
    return -1;
}

int termIndex(char c) {
    if (c == '+') return 0;
    if (c == '*') return 1;
    if (c == 'a') return 2;
    if (c == 'b') return 3;
    if (c == '$') return 4;
    return -1;
}

int addItem(State *s, int p, int dot) {
    for (int i = 0; i < s->n; i++)
        if (s->item[i].p == p &&
            s->item[i].dot == dot)
            return 0;

    if (s->n >= MAX_ITEMS)
        return 0;

    s->item[s->n].p = p;
    s->item[s->n].dot = dot;
    s->n++;

     return 1;
 }

 void closure(State *s) {
     int changed;

     do {
            changed = 0;

            for (int i = 0; i < s->n; i++) {
                Item it = s->item[i];

                if (it.dot >= len[it.p])
                    continue;

                char c = rhs[it.p][it.dot];

                if (isNT(c)) {
                    for (int p = 0; p < MAX_PROD; p++)
                        if (lhs[p] == c)
                            changed |= addItem(s, p, 0);
                }
         }
     } while (changed);
 }

State gotoState(State s, char c) {
    State r = {0};

    for (int i = 0; i < s.n; i++) {
        Item it = s.item[i];

           if (it.dot < len[it.p] &&
               rhs[it.p][it.dot] == c)
               addItem(&r, it.p, it.dot + 1);
    }

    closure(&r);
    return r;
}

int sameState(State a, State b) {
    if (a.n != b.n)
        return 0;

    for (int i = 0; i < a.n; i++) {
        int found = 0;

           for (int j = 0; j < b.n; j++)
               if (a.item[i].p == b.item[j].p &&
                   a.item[i].dot == b.item[j].dot)
                   found = 1;

           if (!found)
               return 0;
    }


    return 1;
}

int findState(State s) {
    for (int i = 0; i < nstates; i++)
        if (sameState(states[i], s))
            return i;

    return -1;
}

/* FOLLOW sets for the given grammar */
int inFollow(char A, char c) {
    if (A == 'E')
        return c == '+' || c == '$';

    if (A == 'T')
        return c == '+' || c == '$' ||
               c == 'a' || c == 'b';

    if (A == 'F')
        return c == '*' || c == '+' ||
               c == '$' || c == 'a' || c == 'b';

    return 0;
}

int setAction(int state, int col, int value) {
    if (action[state][col] != 0 &&
        action[state][col] != value) {
        printf("SLR conflict in state %d, symbol %c\n",
               state, terminals[col]);
        return 0;
    }

    action[state][col] = value;
    return 1;
}

int main(void) {
    memset(trans, -1, sizeof(trans));
    memset(action, 0, sizeof(action));
    memset(go, -1, sizeof(go));

    /* Construct LR(0) item sets */
    addItem(&states[0], 0, 0);
    closure(&states[0]);
    nstates = 1;

    for (int i = 0; i < nstates; i++) {
        for (int c = 0; c < 128; c++) {
            State next = gotoState(states[i], (char)c);

            if (next.n == 0)
                continue;


        int j = findState(next);

        if (j == -1) {
            if (nstates >= MAX_STATES) {
                printf("Too many states\n");
                return 1;
            }

            j = nstates;
            states[nstates++] = next;
        }

        trans[i][c] = j;
    }
}

/* Construct ACTION and GOTO tables */
for (int i = 0; i < nstates; i++) {
    for (int k = 0; k < states[i].n; k++) {
        Item it = states[i].item[k];
        int p = it.p;

        if (it.dot < len[p]) {
            char c = rhs[p][it.dot];
            int j = trans[i][(int)c];

            if (j < 0)
                continue;

            if (isNT(c)) {
                 int n = ntIndex(c);
                 if (n >= 0)
                     go[i][n] = j;
            } else {
                 int t = termIndex(c);
                 if (t >= 0 &&
                     !setAction(i, t, j + 1))
                     return 1;
            }
        } else {
            if (p == 0) {
                 if (!setAction(i, 4, 999))
                     return 1;
            } else {
                 for (int t = 0; t < 5; t++) {
                     if (inFollow(lhs[p], terminals[t])) {
                         if (!setAction(i, t, -p))
                             return 1;
                     }
                 }
            }
        }
    }
}

printf("SLR(1) Parser\n");
printf("Grammar:\n");
printf("E -> E+T | T\n");
printf("T -> TF | F\n");
printf("F -> F* | a | b\n");

printf("\nFOLLOW sets:\n");
printf("FOLLOW(E) = {+, $}\n");
printf("FOLLOW(T) = {+, $, a, b}\n");
printf("FOLLOW(F) = {*, +, $, a, b}\n");

printf("\nNumber of LR(0) states: %d\n", nstates);

char input[MAX];

printf("\nEnter input string ending with $: ");
if (scanf("%99s", input) != 1)
    return 0;

int inputLen = strlen(input);

if (inputLen == 0 || input[inputLen - 1] != '$') {
    printf("Input must end with $\n");
    return 0;
}

int stack[MAX], top = 0, ip = 0;
stack[0] = 0;

printf("\nStack\tInput\tAction\n");

while (1) {
    int state = stack[top];
    int t = termIndex(input[ip]);

    for (int i = 0; i <= top; i++)
        printf("%d ", stack[i]);

    printf("\t%s\t", input + ip);

    if (t < 0) {
        printf("Invalid symbol\n");
        break;
    }

    int a = action[state][t];

    if (a == 999) {
        printf("Accept\nString accepted.\n");
        break;
    }

    if (a == 0) {
        printf("Error\nString rejected.\n");
        break;
    }


        if (a > 0) {
            printf("Shift %d\n", a - 1);

            if (top >= MAX - 1) {
                printf("Stack overflow\n");
                break;
            }

            stack[++top] = a - 1;
            ip++;
        } else {
            int p = -a;

            printf("Reduce by %c -> %s\n", lhs[p], rhs[p]);

            if (top < len[p]) {
                printf("Invalid reduction\n");
                break;
            }

            top -= len[p];

            int n = ntIndex(lhs[p]);
            int next = (n >= 0) ? go[stack[top]][n] : -1;

            if (next < 0) {
                printf("Invalid GOTO\n");
                break;
            }

            if (top >= MAX - 1) {
                printf("Stack overflow\n");
                break;
            }

            stack[++top] = next;
        }
    }

    return 0;
}
