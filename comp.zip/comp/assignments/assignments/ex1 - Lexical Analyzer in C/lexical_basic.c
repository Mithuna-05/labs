#include <stdio.h>
#include <ctype.h>
#include <string.h>

int isKeyword(char str[])
{
    char keywords[][10] = {
        "int", "float", "char", "if", "else",
        "while", "for", "return", "void", "main"
    };

   int n = sizeof(keywords) / sizeof(keywords[0]);

   for (int i = 0; i < n; i++)
   {
       if (strcmp(str, keywords[i]) == 0)
           return 1;
   }
   return 0;

}

int main()
{
    char input[100];
    int i = 0;

    printf("Enter a statement:\n");
    fgets(input, sizeof(input), stdin);

    while (input[i] != '\0')
    {
        if (isspace(input[i]))
        {
            i++;
            continue;
        }

        if (isalpha(input[i]) || input[i] == '_')
        {
            char token[50];
            int j = 0;

            while (isalnum(input[i]) || input[i] == '_')
                token[j++] = input[i++];

            token[j] = '\0';

            if (isKeyword(token))
                 printf("%s --> Keyword\n", token);
            else
                 printf("%s --> Identifier\n", token);
        }
        else if (isdigit(input[i]))
        {
            char token[50];
            int j = 0;

            while (isdigit(input[i]))
                token[j++] = input[i++];

            token[j] = '\0';
            printf("%s --> Number\n", token);
        }
        else if (strchr("+-*/=%", input[i]))
        {
             printf("%c --> Operator\n", input[i]);
             i++;
        }
        else if (strchr("(){}[],;<>", input[i]))
        {
             printf("%c --> Special Symbol\n", input[i]);
             i++;
        }
        else
        {

            printf("%c --> Unknown Token\n", input[i]);
            i++;
        }
    }

    return 0;
}
