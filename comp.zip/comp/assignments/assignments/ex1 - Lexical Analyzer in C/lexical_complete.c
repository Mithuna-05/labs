#include <stdio.h>
#include <string.h>
#include <ctype.h>

char keywords[][20] = {
    "int", "float", "char", "double", "if", "else",
    "while", "for", "return", "void", "break",
    "continue", "switch", "case", "default"
};

int isKeyword(char str[])
{
    int n = sizeof(keywords) / sizeof(keywords[0]);

    for (int i = 0; i < n; i++)
    {
        if (strcmp(str, keywords[i]) == 0)
            return 1;
    }
    return 0;
}

int main()
{
    char input[500];

    printf("Enter a C statement:\n");

fgets(input, sizeof(input), stdin);

int i = 0;

while (input[i] != '\0')
{
    if (isspace(input[i]))
    {
        i++;
        continue;
    }

    if (isalpha(input[i]) || input[i] == '_')
    {
        char token[50];
        int j = 0;

        while (isalnum(input[i]) || input[i] == '_')
            token[j++] = input[i++];

        token[j] = '\0';

        if (isKeyword(token))
             printf("%-15s : Keyword\n", token);
        else
             printf("%-15s : Identifier\n", token);
    }
    else if (isdigit(input[i]))
    {
        char token[50];
        int j = 0, isFloat = 0;

        while (isdigit(input[i]) || input[i] == '.')
        {
            if (input[i] == '.')
                isFloat = 1;

             token[j++] = input[i++];
        }

        token[j] = '\0';

        if (isFloat)
             printf("%-15s : Floating Constant\n", token);
        else
             printf("%-15s : Integer Constant\n", token);
    }
    else if (input[i] == '"')
    {
        char token[100];
        int j = 0;

        token[j++] = input[i++];

        while (input[i] != '"' && input[i] != '\0')
            token[j++] = input[i++];


     if (input[i] == '"')
         token[j++] = input[i++];

     token[j] = '\0';
     printf("%-15s : String Literal\n", token);
 }
 else if (input[i] == '\'')
 {
     char token[20];
     int j = 0;

     token[j++] = input[i++];

     while (input[i] != '\'' && input[i] != '\0')
         token[j++] = input[i++];

    if (input[i] == '\'')
        token[j++] = input[i++];

    token[j] = '\0';
    printf("%-15s : Character Constant\n", token);
}
else if (input[i] == '/' && input[i + 1] == '/')
{
    printf("// Comment Detected\n");
    break;
}
else if (input[i] == '/' && input[i + 1] == '*')
{
    printf("Multi-line Comment Detected\n");
    i += 2;

    while (!(input[i] == '*' && input[i + 1] == '/') &&
           input[i] != '\0')
        i++;

    if (input[i] != '\0')
        i += 2;
}
else if ((input[i] == '=' && input[i + 1] == '=') ||
         (input[i] == '!' && input[i + 1] == '=') ||
         (input[i] == '<' && input[i + 1] == '=') ||
         (input[i] == '>' && input[i + 1] == '='))
{
    printf("%c%c               : Relational Operator\n",
            input[i], input[i + 1]);
    i += 2;
}
else if ((input[i] == '&' && input[i + 1] == '&') ||
         (input[i] == '|' && input[i + 1] == '|'))
{
    printf("%c%c               : Logical Operator\n",
            input[i], input[i + 1]);
    i += 2;
}

        else if (strchr("+-*/%", input[i]))
        {
             printf("%c               : Arithmetic Operator\n",
                    input[i]);
             i++;
        }
        else if (input[i] == '=')
        {
             printf("=               : Assignment Operator\n");
             i++;
        }
        else if (strchr("(){}[],;", input[i]))
        {
             printf("%c               : Delimiter\n", input[i]);
             i++;
        }
        else
        {
             printf("%c               : Unknown Token\n", input[i]);
             i++;
        }
    }

    return 0;
}
