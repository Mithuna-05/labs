%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int yylex(void); void yyerror(const char *s);
static int nt=0,nl=0;
static char *tmp(void){char b[32];snprintf(b,sizeof b,"t%d",++nt);return strdup(b);}
static char *lab(void){char b[32];snprintf(b,sizeof b,"L%d",++nl);return strdup(b);}
%}
%union { char *str; }
%token <str> ID NUMBER RELOP
%token WHILE IF ELSE ASSIGN PLUS MINUS STAR SLASH LPAREN RPAREN LBRACE RBRACE SEMI INVALID
%type <str> expr condition
%left PLUS MINUS
%left STAR SLASH
%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE
%%
program : stmt_list ;
stmt_list : /* empty */ | stmt_list stmt ;
stmt : ID ASSIGN expr SEMI { printf("%s = %s\n",$1,$3); }
     | WHILE { $<str>$=lab(); printf("%s:\n",$<str>$); } LPAREN condition RPAREN { $<str>$=lab(); printf("ifFalse %s goto %s\n",$4,$<str>$); } block { printf("goto %s\n%s:\n",$<str>2,$<str>6); }
     | IF LPAREN condition RPAREN { printf("ifFalse %s goto L%d\n",$3,++nl); } block %prec LOWER_THAN_ELSE
     | block ;
block : LBRACE stmt_list RBRACE ;
condition : expr RELOP expr { $$=tmp(); printf("%s = %s %s %s\n",$$,$1,$2,$3); }
         ;
expr : expr PLUS expr { $$=tmp(); printf("%s = %s + %s\n",$$,$1,$3); }
     | expr MINUS expr { $$=tmp(); printf("%s = %s - %s\n",$$,$1,$3); }
     | expr STAR expr { $$=tmp(); printf("%s = %s * %s\n",$$,$1,$3); }
     | expr SLASH expr { $$=tmp(); printf("%s = %s / %s\n",$$,$1,$3); }
     | LPAREN expr RPAREN { $$=$2; }
     | ID { $$=$1; } | NUMBER { $$=$1; }
     | MINUS expr { $$=tmp(); printf("%s = 0 - %s\n",$$,$2); }
     ;
%%
void yyerror(const char *s){fprintf(stderr,"Syntax error: %s\n",s);}
int main(void){return yyparse();}
