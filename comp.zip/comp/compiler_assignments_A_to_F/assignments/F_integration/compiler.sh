
#!/bin/bash

set -e

# Find the assignments directory relative to this script.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ASSIGN_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

A_DIR="$ASSIGN_DIR/A_lexical"
B_DIR="$ASSIGN_DIR/B_syntax"
C_DIR="$ASSIGN_DIR/C_tac"
D_DIR="$ASSIGN_DIR/D_optimization"
E_DIR="$ASSIGN_DIR/E_target"

INPUT="${1:-$SCRIPT_DIR/sample_input.cmini}"

TAC="$SCRIPT_DIR/tac.txt"
OPT_TAC="$SCRIPT_DIR/opt_tac.txt"
TARGET="$SCRIPT_DIR/target_code.txt"

echo "=================================="
echo "     MINI COMPILER - PART F"
echo "=================================="

if [ ! -f "$INPUT" ]; then
    echo "Error: Input file not found: $INPUT"
    exit 1
fi

# Compile stages if their executables are missing.
if [ ! -x "$A_DIR/lexer" ]; then
    (cd "$A_DIR" && lex a.l && gcc lex.yy.c -o lexer -ll)
fi

if [ ! -x "$B_DIR/syntax" ]; then
    (cd "$B_DIR" && yacc -d -b b b.y && lex b.l && \
        gcc b.tab.c lex.yy.c -o syntax -ll)
fi

if [ ! -x "$C_DIR/tac" ]; then
    (cd "$C_DIR" && yacc -d -b c c.y && lex c.l && \
        gcc c.tab.c lex.yy.c -o tac -ll)
fi

# Part A: lexical analysis
echo ""
echo "[PART A] Lexical analysis"
"$A_DIR/lexer" < "$INPUT"

# Part B: syntax analysis
echo ""
echo "[PART B] Syntax analysis"
"$B_DIR/syntax" < "$INPUT"

# Part C: three-address code generation
echo ""
echo "[PART C] Generating TAC"
"$C_DIR/tac" < "$INPUT" > "$TAC"
cat "$TAC"

# Part D: optimization (prefer C if available)
echo ""
echo "[PART D] Optimizing TAC"

if [ -f "$D_DIR/d.c" ]; then
    gcc "$D_DIR/d.c" -o "$D_DIR/d"
    "$D_DIR/d" < "$TAC" > "$OPT_TAC"
elif [ -f "$D_DIR/d.py" ]; then
    python3 "$D_DIR/d.py" < "$TAC" > "$OPT_TAC"
else
    echo "Error: Part D source not found."
    exit 1
fi

cat "$OPT_TAC"

# Part E: target code generation (prefer C if available)
echo ""
echo "[PART E] Generating target code"

if [ -f "$E_DIR/e.c" ]; then
    gcc "$E_DIR/e.c" -o "$E_DIR/e"
    "$E_DIR/e" < "$OPT_TAC" > "$TARGET"
elif [ -f "$E_DIR/e.py" ]; then
    python3 "$E_DIR/e.py" < "$OPT_TAC" > "$TARGET"
else
    echo "Error: Part E source not found."
    exit 1
fi

cat "$TARGET"

echo ""
echo "=================================="
echo "       COMPILATION COMPLETE"
echo "=================================="
echo "TAC:         $TAC"
echo "Optimized:   $OPT_TAC"
echo "Target code: $TARGET"
