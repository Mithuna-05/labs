Compiler assignment organized into A–F. See each folder and F_integration/compilation_steps.txt.
Important: the framework is extensible, but not automatically universal for every imaginable grammar; grammar productions and lexer tokens must be specified for each language.
