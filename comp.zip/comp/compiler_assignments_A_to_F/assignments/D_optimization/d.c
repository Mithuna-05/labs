#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX 2000
#define LEN 512

char lines[MAX][LEN];
int n;

void trim(char *s) {
    char *p = s;
    while (isspace((unsigned char)*p)) p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
    int len = strlen(s);
    while (len && isspace((unsigned char)s[len - 1]))
        s[--len] = '\0';
}

int assignment(char *s, char *dst, char *rhs) {
    char temp[LEN];
    strcpy(temp, s);
    char *eq = strchr(temp, '=');
    if (!eq || (eq > temp && strchr("<>!", eq[-1])) ||
        eq[1] == '=') return 0;
    *eq = '\0';
    trim(temp);
    trim(eq + 1);
    if (!*temp || !isalpha((unsigned char)temp[0]) &&
        temp[0] != '_') return 0;
    strcpy(dst, temp);
    strcpy(rhs, eq + 1);
    return 1;
}

int number(const char *s) {
    if (!*s) return 0;
    char *end;
    strtod(s, &end);
    return *end == '\0';
}

int simple(const char *s) {
    if (number(s)) return 1;
    if (!isalpha((unsigned char)s[0]) && s[0] != '_')
        return 0;
    for (int i = 1; s[i]; i++)
        if (!isalnum((unsigned char)s[i]) && s[i] != '_')
            return 0;
    return 1;
}

int binary(char *rhs, char *l, char *op, char *r) {
    char temp[LEN];
    strcpy(temp, rhs);
    trim(temp);

    for (int i = 1; temp[i]; i++) {
        if (strchr("+-*/", temp[i])) {
            char save = temp[i];
            temp[i] = '\0';
            strcpy(l, temp);
            strcpy(r, temp + i + 1);
            trim(l);
            trim(r);
            temp[i] = save;
            if (simple(l) && simple(r)) {
                *op = save;
                return 1;
            }
        }
    }
    return 0;
}

int main(void) {
    char buf[LEN];

    while (fgets(buf, sizeof(buf), stdin) && n < MAX) {
        buf[strcspn(buf, "\r\n")] = '\0';
        trim(buf);
        if (!*buf || buf[0] == '#') continue;
        strcpy(lines[n++], buf);
    }

    int header = -1, back = -1;
    char target[64];

    for (int i = 0; i < n; i++) {
        if (sscanf(lines[i], "goto %63s", target) == 1) {
            for (int j = 0; j < i; j++) {
                char label[64];
                if (sscanf(lines[j], "%63[^:]:", label) == 1 &&
                    strcmp(label, target) == 0) {
                    header = j;
                    back = i;
                    break;
                }
            }
            if (header >= 0) break;
        }
    }

    int hoist[MAX] = {0};

    if (header >= 0) {
        int changed;
        do {
            changed = 0;

            for (int i = header + 1; i < back; i++) {
                if (hoist[i]) continue;

                char dst[128], rhs[LEN], l[LEN], r[LEN], op;
                if (!assignment(lines[i], dst, rhs) ||
                    !binary(rhs, l, &op, r))
                    continue;

                int safe = 1;
                char operands[2][LEN];
                strcpy(operands[0], l);
                strcpy(operands[1], r);

                for (int k = 0; k < 2; k++) {
                    if (number(operands[k])) continue;

                    for (int j = header + 1; j < back; j++) {
                        char d[128], rr[LEN];
                        if (!assignment(lines[j], d, rr) ||
                            strcmp(d, operands[k]) != 0)
                            continue;

                        if (!hoist[j]) safe = 0;
                    }
                }

                if (safe) {
                    hoist[i] = 1;
                    changed = 1;
                }
            }
        } while (changed);
    }

    puts("--- PART D: OPTIMIZED TAC (CODE MOTION) ---");

    if (header >= 0) {
        for (int i = header + 1; i < back; i++)
            if (hoist[i]) puts(lines[i]);

        for (int i = 0; i < n; i++) {
            if (i > header && i < back && hoist[i]) continue;
            puts(lines[i]);
        }
    } else {
        for (int i = 0; i < n; i++) puts(lines[i]);
    }

    return 0;
}