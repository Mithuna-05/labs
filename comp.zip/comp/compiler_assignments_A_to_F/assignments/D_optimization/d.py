#!/usr/bin/env python3
"""Loop-invariant code motion for simple three-address code."""
import re
import sys

LABEL = re.compile(r"^\s*(L\d+):\s*$")
GOTO = re.compile(r"^\s*goto\s+(L\d+)\s*$")
ASSIGN = re.compile(r"^\s*([A-Za-z_]\w*)\s*=\s*(.*?)\s*$")
BINARY = re.compile(
    r"^([A-Za-z_]\w*|\d+(?:\.\d+)?)\s*"
    r"([+\-*/%])\s*([A-Za-z_]\w*|\d+(?:\.\d+)?)$"
)
COMPARE = re.compile(r"^\s*(?:ifFalse|if)\s+(.+?)\s+goto\s+L\d+\s*$")


def variables(expression):
    return set(re.findall(r"\b[A-Za-z_]\w*\b", expression))


def optimize(source):
    lines = [line.rstrip() for line in source if line.strip()]

    # Find a backward jump and its loop header.
    labels = {}
    for i, line in enumerate(lines):
        match = LABEL.match(line)
        if match:
            labels[match.group(1)] = i

    header = None
    back = None

    for i, line in enumerate(lines):
        match = GOTO.match(line)
        if match and match.group(1) in labels:
            if labels[match.group(1)] < i:
                header = labels[match.group(1)]
                back = i
                break

    if header is None:
        print("No loop found; code unchanged.", file=sys.stderr)
        return lines

    body = lines[header + 1:back]

    # Variables used by loop conditions must not be treated as invariant.
    condition_vars = set()
    for line in body:
        match = COMPARE.match(line)
        if match:
            condition_vars.update(variables(match.group(1)))

    # Identify assignments and variables modified within the loop.
    assigned = set()
    for line in body:
        match = ASSIGN.match(line)
        if match:
            assigned.add(match.group(1))

    # Find eligible computations and hoist dependency chains in order.
    hoisted = []
    remaining = body[:]
    available = set()

    # Temporaries defined inside the loop may become available after hoisting.
    changed = True
    while changed:
        changed = False
        next_remaining = []

        for line in remaining:
            match = ASSIGN.match(line)
            if not match:
                next_remaining.append(line)
                continue

            destination, rhs = match.groups()
            expression = BINARY.match(rhs)

            # Only arithmetic computations are candidates.
            if not expression:
                next_remaining.append(line)
                continue

            left, operator, right = expression.groups()

            # Do not hoist comparisons or calculations involving loop-condition
            # variables, since these may change between iterations.
            if any(v in condition_vars for v in (left, right)
                   if not re.fullmatch(r"\d+(?:\.\d+)?", v)):
                next_remaining.append(line)
                continue

            operands = [
                v for v in (left, right)
                if not re.fullmatch(r"\d+(?:\.\d+)?", v)
            ]

            # An operand assigned in the loop is safe only if it is a
            # temporary whose computation has already been hoisted.
            safe = all(
                v not in assigned or v in available
                for v in operands
            )

            if safe:
                hoisted.append(line)
                available.add(destination)
                changed = True
            else:
                next_remaining.append(line)

        remaining = next_remaining

    if not hoisted:
        print("No loop-invariant calculations found.", file=sys.stderr)
        return lines

    # Keep the original loop header and control flow intact.
    return lines[:header] + hoisted + lines[header:header + 1] + remaining + lines[back:]


def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding="utf-8") as file:
            source = file.readlines()
    else:
        source = sys.stdin.readlines()

    print("--- PART D: OPTIMIZED TAC (CODE MOTION) ---")
    for line in optimize(source):
        print(line)


if __name__ == "__main__":
    main()
