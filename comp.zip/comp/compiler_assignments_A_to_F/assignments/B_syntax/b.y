%{
#include <stdio.h>
int yylex(void);
void yyerror(const char *s);
%}
%union { long ival; }
%token WHILE IF ELSE ID NUMBER RELOP ASSIGN PLUS MINUS STAR SLASH LPAREN RPAREN LBRACE RBRACE SEMI INVALID
%left PLUS MINUS
%left STAR SLASH
%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE
%%
program : stmt_list ;
stmt_list : /* empty */ | stmt_list stmt ;
stmt : ID ASSIGN expr SEMI
     | WHILE LPAREN condition RPAREN block
     | IF LPAREN condition RPAREN block %prec LOWER_THAN_ELSE
     | IF LPAREN condition RPAREN block ELSE block
     | block
     ;
block : LBRACE stmt_list RBRACE ;
condition : expr RELOP expr ;
expr : expr PLUS expr | expr MINUS expr | expr STAR expr | expr SLASH expr
     | LPAREN expr RPAREN | ID | NUMBER | MINUS expr
     ;
%%
void yyerror(const char *s) { fprintf(stderr, "Syntax error: %s\n", s); }
int main(void) { if (yyparse() == 0) { puts("Syntax is correct."); return 0; } return 1; }
