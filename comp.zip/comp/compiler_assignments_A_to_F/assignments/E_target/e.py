#!/usr/bin/env python3
"""Educational TAC-to-assembly-like target code generator."""
import re
import sys

ASSIGN = re.compile(r'^\s*([A-Za-z_]\w*)\s*=\s*(.*?)\s*$')
BINARY = re.compile(r'^(.+?)\s*([+\-*/%])\s*(.+)$')
COMPARE = re.compile(r'^(.+?)\s*(<=|>=|==|!=|<|>)\s*(.+)$')


def operand(value):
    value = value.strip()
    if re.fullmatch(r'\d+(?:\.\d+)?', value):
        return '#' + value
    return value


def generate(lines):
    out = []

    for raw in lines:
        s = raw.strip()
        if not s or s.startswith('--- PART'):
            continue

        # Labels
        if re.fullmatch(r'L\w+:', s):
            out.append(s)
            continue

        # Unconditional jump
        if s.startswith('goto '):
            out.append('JMP ' + s[5:].strip())
            continue

        # Conditional jump: ifFalse condition goto label
        if s.startswith('ifFalse '):
            match = re.match(
                r'^ifFalse\s+(.+?)\s+goto\s+(L\w+)\s*$', s
            )
            if not match:
                out.append('; Unsupported branch: ' + s)
                continue

            condition, label = match.groups()
            out.append('LOAD ' + operand(condition))
            out.append('JZ ' + label)
            continue

        match = ASSIGN.match(s)
        if not match:
            out.append('; Unsupported instruction: ' + s)
            continue

        dst, rhs = match.groups()

        # Relational expressions, e.g. t2 = m < t1
        cmp_match = COMPARE.match(rhs)
        if cmp_match:
            left, op, right = cmp_match.groups()
            out.append('LOAD ' + operand(left))
            out.append('CMP ' + operand(right))

            compare_instruction = {
                '<': 'SETLT',
                '>': 'SETGT',
                '<=': 'SETLE',
                '>=': 'SETGE',
                '==': 'SETEQ',
                '!=': 'SETNE'
            }[op]

            out.append(compare_instruction)
            out.append('STORE ' + dst)
            continue

        # Arithmetic expressions
        bin_match = BINARY.match(rhs)
        if bin_match:
            left, op, right = bin_match.groups()

            # Prevent unsupported relational operators from being
            # treated as arithmetic.
            if op not in ('+', '-', '*', '/', '%'):
                out.append('; Unsupported expression: ' + rhs)
                continue

            out.append('LOAD ' + operand(left))

            instruction = {
                '+': 'ADD',
                '-': 'SUB',
                '*': 'MUL',
                '/': 'DIV',
                '%': 'MOD'
            }[op]

            out.append(instruction + ' ' + operand(right))
            out.append('STORE ' + dst)
        else:
            # Simple assignment
            out.append('LOAD ' + operand(rhs))
            out.append('STORE ' + dst)

    return out


def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding='utf-8') as file:
            data = file.read()
    else:
        data = sys.stdin.read()

    print('--- PART E: TARGET ASSEMBLY CODE ---')
    print('\n'.join(generate(data.splitlines())))


if __name__ == '__main__':
    main()
