#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define LEN 512

void trim(char *s) {
    char *p = s;
    while (isspace((unsigned char)*p)) p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
    int n = strlen(s);
    while (n && isspace((unsigned char)s[n - 1]))
        s[--n] = '\0';
}

int number(const char *s) {
    if (!*s) return 0;
    char *end;
    strtod(s, &end);
    return *end == '\0';
}

void load(const char *s) {
    printf("LOAD ");
    if (number(s)) printf("#");
    printf("%s\n", s);
}

void operand(const char *s) {
    if (number(s)) printf("#");
    printf("%s", s);
}

int main(void) {
    char line[LEN];

    puts("--- PART E: TARGET ASSEMBLY CODE ---");

    while (fgets(line, sizeof(line), stdin)) {
        line[strcspn(line, "\r\n")] = '\0';
        trim(line);

        if (!*line || line[0] == '#') continue;
        if (strncmp(line, "--- PART", 8) == 0) continue;

        int len = strlen(line);

        if (line[0] == 'L' && line[len - 1] == ':') {
            puts(line);
            continue;
        }

        if (strncmp(line, "goto ", 5) == 0) {
            printf("\tJMP %s\n", line + 5);
            continue;
        }

        if (strncmp(line, "ifFalse ", 8) == 0) {
            char cond[128], label[64];
            if (sscanf(line, "ifFalse %127s goto %63s",
                       cond, label) == 2) {
                load(cond);
                printf("\tJZ %s\n", label);
            }
            continue;
        }

        char *eq = strchr(line, '=');
        if (!eq) {
            printf("; Unsupported instruction: %s\n", line);
            continue;
        }

        char dst[128], rhs[LEN];
        int dlen = eq - line;
        if (dlen <= 0 || dlen >= (int)sizeof(dst)) continue;

        strncpy(dst, line, dlen);
        dst[dlen] = '\0';
        trim(dst);
        strcpy(rhs, eq + 1);
        trim(rhs);

        const char *rel[] = {"<=", ">=", "==", "!=", "<", ">"};
        const char *ins[] = {"SETLE", "SETGE", "SETEQ",
                             "SETNE", "SETLT", "SETGT"};
        int done = 0;

        for (int i = 0; i < 6; i++) {
            char *p = strstr(rhs, rel[i]);
            if (!p) continue;

            char l[128], r[128];
            int k = p - rhs;
            if (k <= 0 || k >= (int)sizeof(l)) continue;

            strncpy(l, rhs, k);
            l[k] = '\0';
            strcpy(r, p + strlen(rel[i]));
            trim(l);
            trim(r);

            load(l);
            printf("\tCMP ");
            operand(r);
            printf("\n\t%s\n\tSTORE %s\n", ins[i], dst);
            done = 1;
            break;
        }
        if (done) continue;

        char *p = NULL;
        char op = 0;
        for (int i = 1; rhs[i]; i++) {
            if (strchr("+-*/%", rhs[i])) {
                p = rhs + i;
                op = rhs[i];
                break;
            }
        }

        if (p) {
            char l[128], r[128];
            int k = p - rhs;
            if (k <= 0 || k >= (int)sizeof(l)) continue;

            strncpy(l, rhs, k);
            l[k] = '\0';
            strcpy(r, p + 1);
            trim(l);
            trim(r);

            load(l);
            printf("\t%s ", op == '+' ? "ADD" :
                   op == '-' ? "SUB" :
                   op == '*' ? "MUL" :
                   op == '/' ? "DIV" : "MOD");
            operand(r);
            printf("\n\tSTORE %s\n", dst);
        } else {
            load(rhs);
            printf("\tSTORE %s\n", dst);
        }
    }

    return 0;
}