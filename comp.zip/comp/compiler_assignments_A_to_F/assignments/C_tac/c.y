%code requires {
    typedef struct {
        char *start;
        char *exit;
    } LoopInfo;
}


%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);

static int temp_no = 0;
static int label_no = 0;

static char *newtemp(void) {
    char b[32];
    snprintf(b, sizeof(b), "t%d", ++temp_no);
    return strdup(b);
}

static char *newlabel(void) {
    char b[32];
    snprintf(b, sizeof(b), "L%d", ++label_no);
    return strdup(b);
}
%}

%union {
    char *str;
    LoopInfo *loop;
}

%token <str> ID NUMBER RELOP
%token WHILE IF ELSE ASSIGN PLUS MINUS STAR SLASH
%token LPAREN RPAREN LBRACE RBRACE SEMI INVALID

%type <str> expr condition
%type <loop> while_start while_head

%left PLUS MINUS
%left STAR SLASH

%%

program
    : stmt_list
    ;

stmt_list
    : /* empty */
    | stmt_list stmt
    ;

stmt
    : ID ASSIGN expr SEMI
      {
          printf("%s = %s\n", $1, $3);
      }
    | while_head block
      {
          printf("goto %s\n", $1->start);
          printf("%s:\n", $1->exit);
      }
    | block
    ;

while_start
    : WHILE
      {
          $$ = malloc(sizeof(LoopInfo));
          $$->start = newlabel();
          $$->exit = NULL;
          printf("%s:\n", $$->start);
      }
    ;

while_head
    : while_start LPAREN condition RPAREN
      {
          $1->exit = newlabel();
          printf("ifFalse %s goto %s\n", $3, $1->exit);
          $$ = $1;
      }
    ;

block
    : LBRACE stmt_list RBRACE
    ;

condition
    : expr RELOP expr
      {
          $$ = newtemp();
          printf("%s = %s %s %s\n", $$, $1, $2, $3);
      }
    ;

expr
    : expr PLUS expr
      {
          $$ = newtemp();
          printf("%s = %s + %s\n", $$, $1, $3);
      }
    | expr MINUS expr
      {
          $$ = newtemp();
          printf("%s = %s - %s\n", $$, $1, $3);
      }
    | expr STAR expr
      {
          $$ = newtemp();
          printf("%s = %s * %s\n", $$, $1, $3);
      }
    | expr SLASH expr
      {
          $$ = newtemp();
          printf("%s = %s / %s\n", $$, $1, $3);
      }
    | LPAREN expr RPAREN
      {
          $$ = $2;
      }
    | ID
      {
          $$ = $1;
      }
    | NUMBER
      {
          $$ = $1;
      }
    | MINUS expr
      {
          $$ = newtemp();
          printf("%s = 0 - %s\n", $$, $2);
      }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "Syntax error: %s\n", s);
}

int main(void) {
    puts("# Three-address code");
    return yyparse();
}
