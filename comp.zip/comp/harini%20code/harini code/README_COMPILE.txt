HARINI CODE — COMPILATION AND EXECUTION GUIDE
=============================================

Contents
--------
part_a.l   Part A: lexical analyzer (Lex)
part_b.l   Part B: scanner used by the syntax analyzer
part_b.y   Part B: syntax analyzer (Yacc)
part_c.l   Part C: scanner used for three-address-code generation
part_c.y   Part C: three-address-code generator (Yacc)
part_d.c   Part D: TAC optimization / code motion
part_e.c   Part E: target assembly-like code generation
part_f.c   Part F: integrated pipeline runner
input.txt  Sample source program

1. Open Ubuntu/WSL and move into the extracted folder
-----------------------------------------------------
cd "/mnt/d/compiler lab/harini code"

If you extracted the ZIP somewhere else, use that actual folder path instead.

2. Install required tools (Ubuntu/WSL)
--------------------------------------
sudo apt update
sudo apt install build-essential flex bison

The commands below use yacc and lex names. On Ubuntu, Bison provides yacc and Flex provides lex.

3. Run the complete integrated pipeline
---------------------------------------
gcc part_f.c -o part_f
./part_f input.txt

Part F builds and runs Parts A–E. It writes the generated three-address code to
tac.txt and the optimized code to opt_tac.txt. It then translates the optimized
TAC into assembly-like output.

4. Run each part separately
---------------------------
Part A — Lexical analysis:
    lex part_a.l
    gcc lex.yy.c -o part_a
    ./part_a < input.txt

Part B — Syntax analysis:
    yacc -d part_b.y
    lex part_b.l
    gcc y.tab.c lex.yy.c -o part_b
    ./part_b < input.txt

Part C — Three-address code:
    yacc -d part_c.y
    lex part_c.l
    gcc y.tab.c lex.yy.c -o part_c
    ./part_c < input.txt > tac.txt
    cat tac.txt

Part D — TAC optimization:
    gcc part_d.c -o part_d
    ./part_d < tac.txt > opt_tac.txt
    cat opt_tac.txt

Part E — Target assembly-like code:
    gcc part_e.c -o part_e
    ./part_e < opt_tac.txt

5. Use your own test input
--------------------------
Edit input.txt using a text editor, or create another file such as test.txt.
Then run:
    ./part_f test.txt

Make sure the input follows the grammar supported by Part B/C. This is a small
educational compiler pipeline, not a complete C compiler.

Troubleshooting
---------------
• If `lex` or `yacc` is not found, install Flex and Bison:
      sudo apt install flex bison
• If `gcc` is not found:
      sudo apt install build-essential
• If the parser reports a syntax error, check the input against the grammar.
• Run commands from the directory containing the source files.
• The assembly output is illustrative assembly-like text; it is not assembled
  into a native executable by an assembler.

Important note
--------------
The files have been separated from the supplied PDF and organized by part.
Please compile and test the integrated pipeline after extraction. The supplied
Part C grammar uses mid-rule actions for loop labels; depending on the Yacc/Bison
version, it may need debugging if warnings or errors occur.
