for $b in doc("Library.xml")/Library/Book
where xs:integer($b/Published) > 2020
order by $b/Title ascending
return
    <BookSummary ID="{data($b/@ID)}">
        {data($b/Title)}
    </BookSummary>