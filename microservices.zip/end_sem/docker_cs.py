ULTIMATE DOCKER LAB CHEAT SHEET

Windows CMD / PowerShell • Docker CLI • Dockerfile • Flask • Node.js • Networking • Compose • MySQL/PostgreSQL • Volumes • Scaling • Troubleshooting

Use this as a practical template collection. Create the named files in the same folder, then run commands from that folder. YAML indentation matters: use spaces, not tabs.

0. First checks and Windows basics

docker --version
docker compose version
docker ps
docker info

If docker ps works (even with an empty table), the Docker daemon is reachable. If it says it cannot connect to the daemon, open Docker Desktop and wait for the engine to start.

CMD folder navigation: cd path\to\folder • PowerShell works with the same Docker commands. To create a folder: mkdir flask-app then cd flask-app.

1. Docker CLI essentials

docker images                         # list images
docker ps                            # running containers
docker ps -a                         # all containers
docker pull nginx                    # download an image
docker run hello-world               # quick Docker test
docker run -d --name web1 -p 8080:80 nginx
docker logs web1                     # show logs
docker logs -f web1                  # follow logs
docker exec -it web1 sh              # open shell (if image has sh)
docker inspect web1                  # detailed container info
docker stop web1
docker start web1
docker rm -f web1                    # force-remove container
docker rmi nginx                     # remove image (only if unused)
docker system df                     # Docker disk usage
docker system prune                  # remove unused resources; review prompt carefully

docker run syntax: docker run [options] IMAGE [command]. Container name is set with --name NAME; it is not placed by itself before the image.

2. Simplest Flask app using Docker

Folder: flask-app/ with app.py, requirements.txt, Dockerfile.

app.py

from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "Hello from Flask Docker!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

requirements.txt

Flask

Dockerfile

FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
EXPOSE 5000
CMD ["python", "app.py"]

Build, run, test, stop

docker build -t flask-app .
docker run -d --name flask-container -p 5000:5000 flask-app
docker ps
docker logs flask-container
curl http://localhost:5000
docker rm -f flask-container

Open http://localhost:5000 in a browser. EXPOSE documents the container port; -p HOST_PORT:CONTAINER_PORT publishes it to the host. The app must listen on 0.0.0.0 inside the container.

3. Flask app variations: copy the relevant route into app.py

A. Multiple routes

@app.route("/about")
def about():
    return "About page"

@app.route("/contact")
def contact():
    return "Contact page"

B. URL parameter

@app.route("/hello/<name>")
def hello(name):
    return f"Hello, {name}!"

@app.route("/square/<int:n>")
def square(n):
    return f"Square = {n*n}"

Test: curl http://localhost:5000/hello/Mithuna and curl http://localhost:5000/square/5

C. JSON API

from flask import jsonify

@app.route("/student")
def student():
    return jsonify(name="Mithuna", department="CSE")

D. POST JSON API

from flask import request, jsonify

@app.route("/student", methods=["POST"])
def add_student():
    data = request.get_json()
    return jsonify(message="received", name=data["name"])

curl -X POST http://localhost:5000/student -H "Content-Type: application/json" -d "{\"name\":\"Mithuna\"}"

E. Simple in-memory CRUD API

from flask import request, jsonify

items = {}

@app.route("/items", methods=["GET"])
def list_items():
    return jsonify(items)

@app.route("/items/<int:item_id>", methods=["POST"])
def create_item(item_id):
    items[item_id] = request.get_json()["name"]
    return jsonify(items), 201

@app.route("/items/<int:item_id>", methods=["PUT"])
def update_item(item_id):
    if item_id not in items:
        return jsonify(error="Not found"), 404
    items[item_id] = request.get_json()["name"]
    return jsonify(items)

@app.route("/items/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    if item_id not in items:
        return jsonify(error="Not found"), 404
    del items[item_id]
    return jsonify(message="deleted")

This sample stores data in memory only; it resets when the app restarts. Use a database or file volume for persistence.

4. Environment variables and file volumes

A. Read environment variable

import os

@app.route("/config")
def config():
    return f"App: {os.getenv('APP_NAME', 'Flask App')}"

docker run -d --name flask-container -p 5000:5000 -e APP_NAME=Inventory flask-app

B. Persistent file example

import os
DATA_DIR = os.getenv("DATA_DIR", "/data")
os.makedirs(DATA_DIR, exist_ok=True)

@app.route("/add/<item>")
def add(item):
    with open(os.path.join(DATA_DIR, "items.txt"), "a") as f:
        f.write(item + "\\n")
    return "Saved"

@app.route("/items")
def items():
    path = os.path.join(DATA_DIR, "items.txt")
    if not os.path.exists(path):
        return "No items"
    return open(path).read()

docker run -d --name flask-container -p 5000:5000 -e DATA_DIR=/data -v "%cd%\data:/data" flask-app

Run from Windows CMD. The host folder data is mounted into /data in the container. Make sure the application code includes the needed imports: os and Flask.

5. Custom Docker network and two containers

Use this when asked to create a custom/user-defined network and demonstrate service discovery.

docker network create mynetwork
docker run -dit --name server1 --network mynetwork nginx
docker run -dit --name client1 --network mynetwork ubuntu bash
docker exec client1 bash -c "apt-get update && apt-get install -y curl"
docker exec client1 curl http://server1
docker network inspect mynetwork
docker ps

Expected curl response: Nginx welcome-page HTML. Container names resolve automatically on a user-defined bridge network.

Default bridge alternative

docker run -dit --name server1 nginx
docker run -dit --name client1 ubuntu bash
docker exec client1 bash -c "apt-get update && apt-get install -y curl"
docker inspect -f "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}" server1
docker exec client1 curl http://SERVER_IP

Replace SERVER_IP with the actual address printed. The default bridge does not provide the same automatic container-name DNS behavior as a user-defined bridge network.

Connect existing containers to a custom network

docker network create mynetwork
docker network connect mynetwork server1
docker network connect mynetwork client1
docker exec client1 curl http://server1

Network commands

docker network ls
docker network inspect mynetwork
docker network connect mynetwork client1
docker network disconnect mynetwork client1
docker network rm mynetwork

Network isolation is not encryption. Use TLS if traffic must be encrypted.

6. Node.js Dockerfile and HTTP server

Files: server.js, package.json, Dockerfile.

server.js

const http = require('http');

const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Hello from Node.js Docker App!\\n');
});

const port = process.env.PORT || 3000;
server.listen(port, '0.0.0.0', () => {
  console.log(`Server running on port ${port}`);
});

package.json

{
  "name": "node-app",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {"start": "node server.js"}
}

Dockerfile

FROM node:20
WORKDIR /app
COPY package.json .
COPY server.js .
EXPOSE 3000
CMD ["npm", "start"]

docker build -t node-app .
docker run -d --name node-container -p 3000:3000 node-app
curl http://localhost:3000
docker ps
docker logs node-container
docker rm -f node-container

7. Docker Compose: simplest Flask app

Add docker-compose.yml beside app.py and Dockerfile.

services:
  web:
    build: .
    ports:
      - "5000:5000"

docker compose up --build -d
docker compose ps
docker compose logs
docker compose logs -f web
docker compose exec web sh
docker compose down

Compose automatically creates a network for services. Use docker compose down to stop and remove Compose containers/network. Named volumes are not removed by default; docker compose down -v removes them too.

8. Flask + MySQL using Compose

Files: app.py, requirements.txt, Dockerfile, docker-compose.yml. Flask uses the service hostname db, not localhost.

requirements.txt

Flask
mysql-connector-python

app.py

from flask import Flask
import mysql.connector
import os

app = Flask(__name__)

@app.route("/")
def home():
    conn = mysql.connector.connect(
        host=os.getenv("DB_HOST", "db"),
        user=os.getenv("DB_USER", "appuser"),
        password=os.getenv("DB_PASSWORD", "apppass"),
        database=os.getenv("DB_NAME", "appdb")
    )
    cur = conn.cursor()
    cur.execute("SELECT VERSION()")
    version = cur.fetchone()[0]
    cur.close()
    conn.close()
    return f"Connected to MySQL: {version}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

docker-compose.yml

services:
  web:
    build: .
    ports:
      - "5000:5000"
    environment:
      DB_HOST: db
      DB_USER: appuser
      DB_PASSWORD: apppass
      DB_NAME: appdb
    depends_on:
      db:
        condition: service_healthy

  db:
    image: mysql:8.4
    environment:
      MYSQL_ROOT_PASSWORD: rootpass
      MYSQL_DATABASE: appdb
      MYSQL_USER: appuser
      MYSQL_PASSWORD: apppass
    healthcheck:
      test: ["CMD-SHELL", "mysqladmin ping -h localhost -uroot -p$$MYSQL_ROOT_PASSWORD"]
      interval: 5s
      timeout: 5s
      retries: 10

Use the same Python Dockerfile from Section 2. Run docker compose up --build -d, then open http://localhost:5000. Credentials are for a lab only, not production.

9. Flask + PostgreSQL using Compose

Change requirements.txt and app.py connector, and use a PostgreSQL database service.

requirements.txt

Flask
psycopg2-binary

Database connection snippet

import psycopg2
conn = psycopg2.connect(
    host="db",
    user="appuser",
    password="apppass",
    dbname="appdb"
)
cur = conn.cursor()
cur.execute("SELECT version()")
version = cur.fetchone()[0]

PostgreSQL service in docker-compose.yml

  db:
    image: postgres:16
    environment:
      POSTGRES_DB: appdb
      POSTGRES_USER: appuser
      POSTGRES_PASSWORD: apppass
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U appuser -d appdb"]
      interval: 5s
      timeout: 5s
      retries: 10

Keep the web service from Section 8 and set its DB_HOST=db, DB_USER=appuser, DB_PASSWORD=apppass, DB_NAME=appdb. Add depends_on with condition: service_healthy. In app.py, place the connection code inside the route and close cursor/connection after use.

10. Compose with database persistence

For MySQL, add this under the db service:

    volumes:
      - mysqldata:/var/lib/mysql

volumes:
  mysqldata:

For PostgreSQL, use /var/lib/postgresql/data instead of /var/lib/mysql and name the volume pgdata. Put the top-level volumes key aligned with services.

services:
  db:
    image: postgres:16
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:

Named volumes preserve database files when containers are removed. docker compose down -v deletes the named volume and its data.

11. Scaling services

Compose can create several instances of a service. Do not publish the same fixed host port for each replica.

services:
  web:
    build: .
    ports:
      - "5000"

docker compose up --build -d --scale web=3
docker compose ps
docker compose logs
docker compose down

The short port syntax lets Docker allocate host ports for replicas. It does not automatically create one load-balanced endpoint. For a shared endpoint, add a reverse proxy/load balancer. For Node.js, use the same pattern with its internal port, e.g. ports: ["3000"].

12. Common variations: what to change

Question wording

Change / solution

Simple Flask app in Docker

app.py + requirements.txt + Dockerfile; docker build and docker run.

Multiple Flask routes

Add @app.route functions in app.py; Dockerfile unchanged.

Dynamic URL input

Use route converters like /square/<int:n>.

REST/JSON API

Use jsonify; accept methods via methods=[...] and request.get_json().

CRUD application

Implement GET/POST/PUT/DELETE; in-memory data resets on restart.

Environment variables

Read os.getenv(...) and pass -e NAME=value or Compose environment.

Persistent files

Mount a host folder or named volume with -v / volumes:.

Custom network

docker network create; attach both containers with --network; test by hostname.

Existing containers

docker network connect NETWORK CONTAINER.

Flask + MySQL

mysql-connector-python; image mysql; MYSQL_* variables; hostname db.

Flask + PostgreSQL

psycopg2-binary; image postgres; POSTGRES_* variables; hostname db.

Node.js web server

server.js + package.json + Node Dockerfile; expose/publish its port.

Three replicas

docker compose up --scale web=3; avoid fixed host port conflicts.

Inspect network/container

docker network inspect NAME; docker inspect CONTAINER; docker ps.

13. Troubleshooting quick fixes

docker cannot connect to daemon: Start Docker Desktop and wait until the engine is ready; run docker ps.

port is already allocated: Choose another host port, e.g. -p 5001:5000, or stop the process/container using it.

container name already in use: docker rm -f NAME, or choose a different name.

curl not found in Ubuntu: docker exec client1 bash -c "apt-get update && apt-get install -y curl".

hostname does not resolve: Use a user-defined network/Compose network and ensure both services share it.

database connection refused: Check docker compose ps/logs, DB hostname, credentials, and health status.

image pull TLS error: Restart Docker Desktop; check trusted network/proxy/VPN; try another trusted network. Do not disable TLS verification.

Flask works inside container but not host: Listen on 0.0.0.0 and publish the port with -p HOST:CONTAINER.

changed code but old output remains: Rebuild: docker build -t flask-app .; recreate the container. For Compose: docker compose up --build -d.

dpkg/apt fails in client: Inspect the error and retry apt-get update; package installation requires network access.

14. Exam-ready workflows

A. Dockerfile question

# Create app.py, requirements.txt, Dockerfile
docker build -t myapp .
docker run -d --name mycontainer -p 5000:5000 myapp
docker ps
curl http://localhost:5000
docker logs mycontainer
docker rm -f mycontainer

B. Custom network question

docker network create mynetwork
docker run -dit --name server1 --network mynetwork nginx
docker run -dit --name client1 --network mynetwork ubuntu bash
docker exec client1 bash -c "apt-get update && apt-get install -y curl"
docker exec client1 curl http://server1
docker network inspect mynetwork

C. Compose web + database question

# Create app.py, requirements.txt, Dockerfile, docker-compose.yml
docker compose up --build -d
docker compose ps
docker compose logs
curl http://localhost:5000
docker compose down

D. Node app and replicas

# Create server.js, package.json, Dockerfile, docker-compose.yml
docker build -t node-app .
docker compose up --build -d --scale web=3
docker compose ps
docker compose down

15. Final concepts to memorize

Docker image = template; container = running instance.

Dockerfile builds one image; Docker Compose defines and runs multiple services.

EXPOSE documents the container port; -p publishes a port to the host.

Inside a container, 0.0.0.0 means listen on all container interfaces.

In Compose, connect to another service using its service name (e.g. db), not localhost.

A user-defined bridge network provides container-name DNS; default bridge does not by default.

Volumes persist data beyond a container lifecycle; container writable-layer data is ephemeral.

depends_on controls startup order; a health check plus service_healthy can wait for readiness.

Scaling creates more instances; fixed host-port mappings can conflict, and scaling alone is not load balancing.

After editing app code, rebuild the image and recreate/restart the relevant container/service.

Security note: the sample database credentials are intentionally simple for a lab. Do not use them in real deployments; avoid committing secrets and use appropriate secret management and TLS when needed.