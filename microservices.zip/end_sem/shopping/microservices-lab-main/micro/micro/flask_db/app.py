import os
import psycopg
from flask import Flask, jsonify

app = Flask(__name__)
DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql://appuser:apppassword@localhost:5432/appdb",
)

@app.get("/")
def index():
    try:
        with psycopg.connect(DATABASE_URL, connect_timeout=3) as connection:
            database = connection.execute("SELECT current_database()").fetchone()[0]
        return jsonify(message="Flask is connected to PostgreSQL", database=database)
    except psycopg.Error:
        app.logger.exception("Could not connect to the database")
        return jsonify(error="Database connection failed"), 503

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)