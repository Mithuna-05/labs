# Micro Lab Projects

This workspace contains four independent Flask/container examples. Run commands
from the project root (`micro lab`) in PowerShell. Install Docker Desktop for
the Docker Compose examples. The Kubernetes examples also need a configured
cluster and `kubectl`.

| Folder | What it demonstrates | How to start |
|---|---|---|
| `flask_db` | Flask connected to PostgreSQL using Docker Compose | `docker compose -f .\flask_db\docker-compose.yml up --build` |
| `hori_scaling` | Flask replicas behind Nginx load balancing | `docker compose -f .\hori_scaling\docker-compose.yml up --build --scale app=3` |
| `k8s` | Kubernetes database, Flask, frontend, and HPA starter manifest | Build/load image, then `kubectl apply -f .\k8s\k8s-manifest.yml` |
| `kubernets` | Kubernetes Flask/Nginx/PostgreSQL example with persistent storage and HPA | Build/load image, then `kubectl apply -k .\kubernets` |

These are separate examples; start one at a time if they use the same local
ports or Kubernetes resource names.

## 1. `flask_db` — Flask and PostgreSQL with Docker Compose

This Compose file builds the Flask app, starts PostgreSQL, waits for the
database health check, and publishes Flask on port 5000.

```powershell
docker compose -f .\flask_db\docker-compose.yml up --build
```

Open `http://localhost:5000/`. The endpoint returns the connected database
name. In another terminal, inspect or stop the services:

```powershell
docker compose -f .\flask_db\docker-compose.yml ps
docker compose -f .\flask_db\docker-compose.yml logs -f
docker compose -f .\flask_db\docker-compose.yml down
```

The PostgreSQL data is kept in the `postgres_data` named volume when you stop
the stack. To also remove that data, use
`docker compose -f .\flask_db\docker-compose.yml down -v`.

## 2. `hori_scaling` — Nginx load balancing and Flask replicas

Build and start three Flask containers behind Nginx:

```powershell
docker compose -f .\hori_scaling\docker-compose.yml up --build --scale app=3
```

Open `http://localhost:8080/`. The response shows which backend container
handled the request; refresh to observe requests distributed between replicas.
Change `3` to the desired replica count. Inspect or stop the stack with:

```powershell
docker compose -f .\hori_scaling\docker-compose.yml ps
docker compose -f .\hori_scaling\docker-compose.yml logs -f
docker compose -f .\hori_scaling\docker-compose.yml down
```

`hori_scaling\docker-compose.yml` builds the backend from its `Dockerfile` and
mounts `hori_scaling\nginx.conf` into the load balancer container.

## 3. `k8s` — Kubernetes starter manifest

This folder contains a single manifest with PostgreSQL, Flask, Nginx, Services,
and an HPA. The backend image must be available to the Kubernetes cluster as
`flask-backend:v1`. Build it from this folder:

```powershell
docker build -t flask-backend:v1 .\k8s
```

For Minikube, load the image into its cluster, then apply the manifest:

```powershell
minikube image load flask-backend:v1
kubectl apply -f .\k8s\k8s-manifest.yml
kubectl get pods,services,hpa
```

For another cluster, push the image to a container registry, update the
backend image in `k8s\k8s-manifest.yml`, and apply the manifest. Check the
cluster's NodePort address on port `30080`, or forward the frontend Service:

```powershell
kubectl port-forward service/frontend-svc 8080:80
```

Then open `http://localhost:8080/`. The current manifest creates an Nginx
frontend but does not configure Nginx to proxy to Flask; that frontend shows
the default Nginx page. For a routed frontend and database persistence, use
the `kubernets` example below. This starter uses `emptyDir` for PostgreSQL, so
database files are lost if its pod is replaced. HPA requires Metrics Server.

Remove this example's resources with:

```powershell
kubectl delete -f .\k8s\k8s-manifest.yml
```

## 4. `kubernets` — Kubernetes with routed frontend and persistent database

This folder has a Flask backend image (`backend\Dockerfile`), Nginx routing
config (`frontend\nginx.conf`), Kubernetes resources (`kubernetes.yaml`), and
`kustomization.yaml` to generate the frontend ConfigMap from that Nginx config.
The backend Deployment is scaled by an HPA; PostgreSQL uses a persistent volume.

Before deploying, change the sample `POSTGRES_PASSWORD` in
`kubernets\kubernetes.yaml`. The cluster needs Metrics Server and a default
StorageClass able to provision a 5Gi volume. Build the Flask image from the
project root:

```powershell
docker build -t flask-backend:1.0.0 .\kubernets\backend
```

For Minikube, load the image, then apply all resources using Kustomize:

```powershell
minikube image load flask-backend:1.0.0
kubectl apply -k .\kubernets
kubectl get pods,services,hpa
kubectl rollout status statefulset/postgres
kubectl rollout status deployment/backend
kubectl rollout status deployment/frontend
```

For a remote cluster, push the backend image to a registry and change its
`image` in `kubernets\kubernetes.yaml` before applying. To access the app on a
local cluster, forward the frontend Service:

```powershell
kubectl port-forward service/frontend 8080:80
```

Keep that command running and open `http://localhost:8080/`. The root endpoint
reports the database name. `LoadBalancer` Services require a cloud load
balancer when accessing the app without port forwarding.

To see logs or remove the resources:

```powershell
kubectl logs statefulset/postgres
kubectl logs deployment/backend
kubectl logs deployment/frontend
kubectl delete -k .\kubernets
```

Deleting the Kubernetes resources may leave the PostgreSQL persistent volume
claim and its data behind. Review the claim before deleting it if you intend
to permanently remove the database.

## 5. `xml` — XQuery for books published after 2020

The XML source is `xml\library_records.xml`. This XQuery returns each matching
book's original `id` attribute and title. Publication year 2020 is excluded.

```xquery
<books>{
  for $book in doc("xml/library_records.xml")/library/book
  where xs:integer($book/publication) > 2020
  return
    <book id="{string($book/@id)}">
      <title>{string($book/title)}</title>
    </book>
}</books>
```
