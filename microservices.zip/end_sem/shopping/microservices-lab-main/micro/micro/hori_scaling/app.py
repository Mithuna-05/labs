from flask import Flask
import socket
import os

app = Flask(__name__)

@app.route("/")
def home():
    container_id = socket.gethostname()
    return f"Hello from backend container ID: {container_id}\n"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)