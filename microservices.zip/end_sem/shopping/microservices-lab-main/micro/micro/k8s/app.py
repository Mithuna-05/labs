import os
import psycopg
from flask import Flask, jsonify

app = Flask(__name__)
DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql://appuser:apppassword@db-svc:5432/appdb",
)

@app.get("/")
def index():
    try:
        with psycopg.connect(DATABASE_URL, connect_timeout=3) as connection:
            db_name = connection.execute("SELECT current_database()").fetchone()[0]
        return jsonify(status="success", message="Flask connected to database successfully!", database=db_name)
    except Exception as e:
        app.logger.exception("Database connection failed")
        return jsonify(status="error", message="Database connection failed", details=str(e)), 503

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)