# Flask, Nginx, and PostgreSQL on Kubernetes

This example runs a Flask API behind an Nginx frontend. Kubernetes Services
load-balance traffic to the pods; an HPA scales the Flask backend from 2 to 10
pods when average CPU usage exceeds 70%. PostgreSQL uses a persistent volume.

## Before deploying

- Have a Kubernetes cluster with a default StorageClass that can provision a
  5Gi volume.
- Install or enable Metrics Server so the HPA can read CPU usage.
- Change `POSTGRES_PASSWORD` in `kubernetes.yaml` before deploying. Kubernetes
  Secrets are not automatically encrypted at rest; use your cluster's secret
  management for production.

## Build and deploy

From the project root in PowerShell:

```powershell
# Build the Flask backend image from backend/Dockerfile
docker build -t flask-backend:1.0.0 .\kubernets\backend

# Optional: check that the manifests and generated Nginx ConfigMap render
kubectl kustomize .\kubernets

# Apply kubernetes.yaml and generate the frontend ConfigMap from
# frontend/nginx.conf (kustomization.yaml handles both)
kubectl apply -k .\kubernets

# Check rollout status
kubectl rollout status statefulset/postgres
kubectl rollout status deployment/backend
kubectl rollout status deployment/frontend
```

For Minikube, load the built image into the cluster before applying the
manifests:

```powershell
minikube image load flask-backend:1.0.0
```

For a remote cluster, push the backend image to a registry and change the
`image` field in `kubernetes.yaml` to that registry image before applying.
The backend Dockerfile builds the Flask app; `frontend/nginx.conf` is installed
as a ConfigMap by `kustomization.yaml` and routes requests to the backend
Service. `kubernetes.yaml` creates the database, backend, frontend, Services,
and HPA. Do not apply `kubernetes.yaml` alone unless you create the frontend
ConfigMap separately.

## Check and access the app

```powershell
# List pods, Services, and autoscaler
kubectl get pods,services,hpa

# View logs if a component is not starting
kubectl logs statefulset/postgres
kubectl logs deployment/backend
kubectl logs deployment/frontend

# Forward the frontend Service to localhost
kubectl port-forward service/frontend 8080:80
```

Keep port forwarding running, then open `http://localhost:8080/` in your
browser. The root endpoint reports the PostgreSQL database name. `LoadBalancer`
Services need a cloud load balancer; port forwarding works for local clusters.

## Customize and clean up

Edit `backend/app.py` for API changes or `frontend/nginx.conf` for routing
changes. After backend changes, rebuild the image and, for Minikube, load it
again. Reapply the configuration:

```powershell
docker build -t flask-backend:1.0.0 .\kubernets\backend
kubectl apply -k .\kubernets
```

For Minikube after rebuilding:

```powershell
minikube image load flask-backend:1.0.0
kubectl rollout restart deployment/backend
```

To adjust autoscaling, edit `minReplicas`, `maxReplicas`, or
`averageUtilization` in `kubernetes.yaml` and run `kubectl apply -k .\kubernets`.
To remove the deployed resources, run:

```powershell
kubectl delete -k .\kubernets
```

Note: deleting the StatefulSet does not necessarily remove its persistent
volume claim or database data. Review and delete the claim separately only if
you intend to permanently remove that data.
