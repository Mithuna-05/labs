import os

import psycopg
from flask import Flask, jsonify

app = Flask(__name__)
DATABASE_URL = os.environ.get("DATABASE_URL")


def connect_to_database():
    if DATABASE_URL:
        return psycopg.connect(DATABASE_URL, connect_timeout=3)
    return psycopg.connect(connect_timeout=3)


@app.get("/")
def index():
    try:
        with connect_to_database() as connection:
            database = connection.execute("SELECT current_database()").fetchone()[0]
        return jsonify(message="Flask is connected to PostgreSQL", database=database)
    except psycopg.Error:
        app.logger.exception("Could not connect to the database")
        return jsonify(error="Database connection failed"), 503


@app.get("/health/live")
def liveness():
    return jsonify(status="alive")


@app.get("/health/ready")
def readiness():
    try:
        with connect_to_database() as connection:
            connection.execute("SELECT 1")
        return jsonify(status="ready")
    except psycopg.Error:
        app.logger.exception("Database readiness check failed")
        return jsonify(status="not ready"), 503


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
