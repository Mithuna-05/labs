Docker Custom Network — Complete Experiment
1. Create the network
docker network create mynetwork


Creates a custom network for container communication. If it already exists, continue to the next step.
2. Pull the required images
docker pull nginx


docker pull ubuntu


Downloads the Nginx and Ubuntu images. If the TLS error occurs again, fix the Docker Hub connection before proceeding.
3. Run the Nginx server container
docker run -dit --name server1 --network mynetwork nginx


Starts the Nginx server connected to mynetwork.
4. Run the Ubuntu client container
docker run -dit --name client1 --network mynetwork ubuntu bash


Starts the Ubuntu client on the same network.
5. Install curl in the client
docker exec client1 bash -c "apt-get update && apt-get install -y curl"


Installs curl to send an HTTP request to the server.
6. Test inter-container communication
docker exec client1 curl http://server1


Expected output: HTML for the Nginx welcome page, including:
<h1>Welcome to nginx!</h1>


This proves that the client can reach the server using its container name.
7. Verify the network
docker network inspect mynetwork


Displays the containers connected to the network.
8. Check running containers
docker ps


Shows the running server1 and client1 containers.
9. Cleanup (optional)
docker rm -f client1 server1


docker network rm mynetwork


Removes the containers and the custom network.

###############################################
2. Combination A — Run two containers (no custom network)
Use this when the question simply asks you to run two containers. Docker automatically connects them to its default bridge network.

Windows CMD / PowerShell
docker run -dit --name server1 nginx
docker run -dit --name client1 ubuntu bash
docker exec client1 bash -c "apt-get update && apt-get install -y curl"


To test communication, first find the server's IP address:
docker inspect -f "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}" server1


Then replace SERVER_IP with the actual IP address:
docker exec client1 curl http://SERVER_IP


Expected result: HTML from the Nginx server.

Remember: the default bridge does not provide automatic container-name DNS resolution. That's why this example uses the server's IP address.
3. Combination B — Create your own network and run two containers
Use this when the question explicitly mentions a custom network, user-defined network, network isolation, or service discovery.
docker network create mynetwork
docker run -dit --name server1 --network mynetwork nginx
docker run -dit --name client1 --network mynetwork ubuntu bash
docker exec client1 bash -c "apt-get update && apt-get install -y curl"
docker exec client1 curl http://server1
docker network inspect mynetwork


Expected result: Nginx HTML appears, and network inspection shows both containers connected to mynetwork.

Here, you can use server1 as a hostname because Docker provides automatic DNS resolution on user-defined bridge networks.
4. Combination C — Two existing containers, then connect them
Use this when the question says to create containers first and connect them to a network afterward.
docker network create mynetwork
docker network connect mynetwork server1
docker network connect mynetwork client1
docker exec client1 curl http://server1


This assumes server1 and client1 already exist and are running, and that curl is installed in client1.
5. Combination D — Inspect and verify networking
These commands are useful as additional steps in almost any networking question.
docker network ls
docker network inspect mynetwork
docker ps
docker inspect server1
docker inspect client1


Command	Purpose
docker network ls	Lists all Docker networks
docker network inspect mynetwork	Shows network configuration and connected containers
docker ps	Lists running containers
docker inspect server1	Shows server configuration, including network details
docker inspect client1	Shows client configuration, including network details

6. Combination E — Disconnect or remove a network
If the question asks you to disconnect containers or delete a network:
docker network disconnect mynetwork client1
docker network disconnect mynetwork server1
docker network rm mynetwork


The containers must be disconnected before the network can be removed if they are its remaining connected containers.

To remove containers too:
docker rm -f client1 server1
docker network rm mynetwork


Use cleanup only when required, or before restarting the experiment from scratch.
7. Combination F — Create two separate networks
Sometimes a question may ask you to demonstrate network isolation.
docker network create network1
docker network create network2
docker run -dit --name server1 --network network1 nginx
docker run -dit --name client1 --network network2 ubuntu bash


The containers are on separate networks, so they cannot communicate directly through those networks. To allow communication, connect both to a shared network:
docker network connect network1 client1


Now client1 can reach server1 using its hostname:
docker exec client1 bash -c "apt-get update && apt-get install -y curl"
docker exec client1 curl http://server1