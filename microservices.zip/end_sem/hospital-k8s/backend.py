
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import time
import threading
import json

state = {"ready": True, "live": True}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?")[0]

        if path == "/ready":
            self.send_response(200 if state["ready"] else 503)
            self.end_headers()
            self.wfile.write(b"Ready" if state["ready"] else b"Not Ready")
            return

        if path == "/live":
            self.send_response(200 if state["live"] else 500)
            self.end_headers()
            self.wfile.write(b"Live" if state["live"] else b"Failed")
            return

        if path == "/toggle-ready":
            state["ready"] = not state["ready"]
            self.send_response(200)
            self.end_headers()
            self.wfile.write(str(state["ready"]).encode())
            return

        if path == "/toggle-live":
            state["live"] = not state["live"]
            self.send_response(200)
            self.end_headers()
            self.wfile.write(str(state["live"]).encode())
            return

        if path == "/work":
            end = time.time() + 2
            while time.time() < end:
                sum(i * i for i in range(1000))
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Work completed")
            return

        self.send_response(200)
        self.end_headers()
        self.wfile.write(json.dumps({
            "service": "hospital-patient-backend",
            "status": "running",
            "pod": os.environ.get("HOSTNAME", "unknown")
        }).encode())

    def log_message(self, *args):
        pass

HTTPServer(("0.0.0.0", 5000), Handler).serve_forever()
