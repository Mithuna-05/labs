
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.request import urlopen
import os

BACKEND = os.getenv(
    "BACKEND_URL",
    "http://backend-service:5000"
)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            with urlopen(BACKEND + "/", timeout=5) as response:
                data = response.read()
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Hospital Front-end -> Backend: ")
            self.wfile.write(data)
        except Exception as e:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(str(e).encode())

    def log_message(self, *args):
        pass

HTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
