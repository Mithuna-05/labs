XML + BaseX Cheat Sheet (25 Marks)
1. XML creation
Rules: One root element, matching tags, correct nesting, case-sensitive names, quoted attributes, XML declaration at the top.
<?xml version="1.0" encoding="UTF-8"?>
<students>
  <student id="101">
    <name>Arun</name>
    <department>CSE</department>
    <marks>85</marks>
  </student>
  <student id="102">
    <name>Priya</name>
    <department>IT</department>
    <marks>92</marks>
  </student>
</students>


- Root: <students>
- Record: <student>
- Attribute: id="101"
- Element: <name>Arun</name>
- Escape special characters: &amp;, &lt;, &gt;
2. DTD — Document Type Definition
Defines permitted XML elements and their structure.
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE students [
  <!ELEMENT students (student+)>
  <!ELEMENT student (name, department, marks)>
  <!ATTLIST student id CDATA #REQUIRED>
  <!ELEMENT name (#PCDATA)>
  <!ELEMENT department (#PCDATA)>
  <!ELEMENT marks (#PCDATA)>
]>
<students>
  <student id="101">
    <name>Arun</name>
    <department>CSE</department>
    <marks>85</marks>
  </student>
</students>


DTD symbol	Meaning
+	One or more
*	Zero or more
?	Zero or one
#PCDATA	Text content
#REQUIRED	Attribute is mandatory
EMPTY	Element has no content
3. XSD — XML Schema Definition
Defines XML structure and data types. Save separately as students.xsd.
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
  <xs:element name="students">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="student" maxOccurs="unbounded">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="name" type="xs:string"/>
              <xs:element name="department" type="xs:string"/>
              <xs:element name="marks" type="xs:integer"/>
            </xs:sequence>
            <xs:attribute name="id" type="xs:integer" use="required"/>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>


XSD type	Used for
xs:string	Text
xs:integer	Whole numbers
xs:decimal	Decimal numbers
xs:boolean	True/false
minOccurs="0"	Optional element
maxOccurs="unbounded"	Any number of occurrences
use="required"	Mandatory attribute
4. BaseX execution
1. Open BaseX GUI.
2. Select Database → New.
3. Enter database name: students.
4. Select students.xml, then click OK.
5. Type XQuery in the editor and click the green Run button.
5. XQuery cheat sheet
Assume XML records use <student>, <name>, <department>, and <marks>.
Select
Task	Query
All students	//student
All names	//student/name
First student	(//student)[1]
Last student	(//student)[last()]
CSE students	//student[department="CSE"]
Filter
Standard template:
for $s in //student
where condition
return $s


Task	Condition
Marks above 80	$s/marks > 80
Marks below 50	$s/marks < 50
Marks equal to 85	$s/marks = 85
CSE and marks above 80	$s/department = "CSE" and $s/marks > 80
Example:
for $s in //student
where xs:integer($s/marks) > 80
return $s


Sort
for $s in //student
order by xs:integer($s/marks) descending
return $s


Use ascending for low-to-high; descending for high-to-low.
Aggregate functions
Task	Query
Count	count(//student)
Maximum marks	max(//student/marks ! xs:integer(.))
Minimum marks	min(//student/marks ! xs:integer(.))
Total marks	sum(//student/marks ! xs:integer(.))
Average marks	avg(//student/marks ! xs:integer(.))
Unique departments	distinct-values(//student/department)
String processing
Task	Query
Name contains ar	//student[contains(name, "ar")]
Names uppercase	upper-case(//student/name)
Names lowercase	lower-case(//student/name)
Name starts with A	//student[starts-with(name, "A")]
Custom output
for $s in //student
return <result>
  <name>{data($s/name)}</name>
  <marks>{data($s/marks)}</marks>
</result>


Insert, delete, update
(: Insert :)
insert node <student><name>Kavi</name><department>ECE</department><marks>88</marks></student>
into /students


(: Delete :)
delete node //student[name = "Arun"]


(: Update :)
replace value of node //student[name = "Arun"]/marks
with "95"


These update the BaseX database, so use them only when asked to modify records.
6. Remember
- XML: Stores structured data.
- DTD: Defines allowed elements, order, and attributes.
- XSD: Defines structure and data types.
- XQuery: Retrieves, filters, sorts, and transforms XML data.
- BaseX: Stores XML in a database and executes XQuery.