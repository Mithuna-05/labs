1. Standard Kubernetes YAML template
For most basic deployment questions, start with this template. You can adapt it to Nginx, Flask, Node.js, or another containerised application.
Template A — Deployment
Save the file as deployment.yaml.

apiVersion: apps/v1
kind: Deployment

metadata:
  name: my-deployment

spec:
  replicas: 3

  selector:
    matchLabels:
      app: my-app

  template:
    metadata:
      labels:
        app: my-app

    spec:
      containers:
        - name: my-container
          image: nginx:alpine
          ports:
            - containerPort: 80



2. What can be changed in this template?
Field	What you change it to	Example
apiVersion	API version appropriate for the resource	Deployment: apps/v1
kind	Type of resource	Deployment, Pod, Service
metadata.name	Your resource name	web-deployment
replicas	Number of Pod copies	2, 4, 6
selector.matchLabels.app	Label used to identify managed Pods	app: web
template.metadata.labels.app	Must match the selector above	app: web
containers.name	Container name	web-container
containers.image	Image to run	nginx:alpine, httpd:alpine
containerPort	Port used by the application	80, 5000, 8080
The three fields you must never confuse
- metadata.name — names the Deployment.
- replicas — determines the desired number of Pods.
- image — determines which container image runs.
The label relationship is also critical:
selector:
  matchLabels:
    app: my-app


must match:
template:
  metadata:
    labels:
      app: my-app


If you change app: my-app to app: web in one place, change it in the other place too.
3. Standard YAML templates for different questions
In the exam, the wording of the question determines which kind you should use.

A. Pod
Use when asked to create or run a single Pod.



apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  containers:
    - name: my-container
      image: nginx:1.27-alpine
      ports:
        - containerPort: 80



Save as pod.yaml.


B. Deployment
Use when asked for multiple replicas, scaling, or managed Pods.


Use the Deployment template in Section 1. This is the most useful general-purpose template for your practical.

C. Service
Use when asked to expose an application or provide network access.



apiVersion: v1
kind: Service
metadata:
  name: my-service
spec:
  type: NodePort
  selector:
    app: my-app
  ports:
    - port: 80
      targetPort: 80
      nodePort: 30080



Save as service.yaml.
Important: This Service routes to Pods labelled app: my-app. Your Deployment must use the same label. For the standalone Pod template above, add labels: {app: my-app} under its metadata if you want this Service to select it.

4. How to combine Deployment and Service in one file
If the question asks you to deploy and expose a web application, you can place both resources in one YAML file. Put --- between them.

apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-deployment
spec:
  replicas: 2
  selector:
    matchLabels:
      app: web
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
        - name: web
          image: nginx:1.27-alpine
          ports:
            - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: web-service
spec:
  type: NodePort
  selector:
    app: web
  ports:
    - port: 80
      targetPort: 80
      nodePort: 30080



Save it as web-stack.yaml.
What you can change:
- web-deployment and web-service: resource names.
- replicas: 2: desired Pod count.
- image: the container image.
- containerPort and targetPort: application port.
- nodePort: 30080: external node port within the usual NodePort range.
Do not change the app: web selector independently of the Deployment's Pod labels.

5. Complete command template for the practical
These commands are for Windows CMD, using your Docker Desktop + Minikube setup.
A. Start and check the cluster
docker --version
kubectl version --client
minikube status


If Minikube is stopped:
minikube start --driver=docker


Check the node:
kubectl get nodes


B. Create the YAML file
mkdir D:\Microservices\Lab\kubernetes_practice
cd /d D:\Microservices\Lab\kubernetes_practice
notepad web-stack.yaml


Paste the combined Deployment and Service YAML from Section 4, then save and close Notepad.
Verify the file:
dir


C. Validate and deploy
kubectl apply --dry-run=client -f web-stack.yaml
kubectl apply -f web-stack.yaml


The first command checks whether the manifest is accepted by the client's validation. The second creates or updates the resources in the cluster.
D. Verify successful deployment
kubectl get all
kubectl get deployments
kubectl get pods
kubectl get services


Expected: the Deployment eventually shows 2/2 ready replicas, and the Service shows port 80 mapped to NodePort 30080.
For more detail:
kubectl describe deployment web-deployment
kubectl describe service web-service
kubectl get pods -o wide


E. Access the website
Run:
minikube service web-service --url


Open the URL printed by the command. If Minikube requires a tunnel, keep that CMD window open while testing.
F. Scale the application
kubectl scale deployment web-deployment --replicas=4
kubectl get pods
kubectl get deployments


Scale back:
kubectl scale deployment web-deployment --replicas=2


G. Debug problems
Replace POD_NAME with an actual Pod name from kubectl get pods.
kubectl describe pod POD_NAME
kubectl logs POD_NAME
kubectl get events
kubectl get pods -w


H. Delete resources
kubectl delete -f web-stack.yaml
kubectl get pods
kubectl get deployments
kubectl get services


This removes the resources declared in that file, not the entire Minikube cluster.

6. All related Kubernetes commands — quick reference
Save this section for revision before the exam.
Task	Command
Check client	kubectl version --client
Check cluster	kubectl cluster-info
List nodes	kubectl get nodes
List Pods	kubectl get pods
List all namespaces	kubectl get namespaces
List Deployments	kubectl get deployments
List Services	kubectl get services
List common resources	kubectl get all
Create/update from YAML	kubectl apply -f file.yaml
Validate YAML	kubectl apply --dry-run=client -f file.yaml
Describe resource	kubectl describe deployment NAME
View logs	kubectl logs POD_NAME
Scale Deployment	kubectl scale deployment NAME --replicas=5
Restart Deployment	kubectl rollout restart deployment/NAME
Check rollout	kubectl rollout status deployment/NAME
Undo latest rollout	kubectl rollout undo deployment/NAME
Delete YAML resources	kubectl delete -f file.yaml
Delete a Pod	kubectl delete pod POD_NAME
Show resources in YAML	kubectl get deployment NAME -o yaml
Watch Pods	kubectl get pods -w
7. How to adapt the template to another application
Suppose the exam says, "Deploy a web application with three replicas."
You would change:
metadata:
  name: web-deployment
spec:
  replicas: 3


Then select the correct image and port for the application:
containers:
  - name: web
    image: nginx:1.27-alpine
    ports:
      - containerPort: 80


If the question instead asks for a Flask application, use the Flask Docker image that you built and made available to the Kubernetes cluster, and use the port your Flask app listens on (often 5000). The Service's targetPort must match that application port.