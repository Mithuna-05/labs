DOCKER PRACTICAL MOCK QUESTION
==============================

Scenario:
Develop a monolithic Inventory Management System using Flask.
The application must:
1. Display a home page.
2. Add an item with its name and quantity.
3. Display all stored items.
4. Store records in an SQLite database.
5. Be containerized and exposed on port 5000.

Files supplied:
- app.py          Flask application and SQLite database logic
- requirements.txt Python dependency list
- Dockerfile      Instructions to build the application image
- compose.yaml    Runs the application and maps a local folder for database persistence
- .dockerignore   Excludes unnecessary files from the image build

IMPORTANT OFFLINE NOTE:
Docker needs the python:3.12-slim image and Flask package to be available locally,
or it must be able to download them. In an offline lab, check availability before
the exam. The files can be correct even if an unavailable image/package prevents a build.

OPTION A — TEST WITH DOCKER CLI + DOCKERFILE
--------------------------------------------
Open a terminal in this folder.

1. Build the image:
   docker build -t inventory-app:1.0 .

2. Run the container:
   docker run -d --name inventory-cli -p 5000:5000 -e DATA_DIR=/data -v "%cd%\\data:/data" inventory-app:1.0

   This command is for Windows Command Prompt. If the data folder does not exist,
   create it first with: mkdir data

   For PowerShell, the volume argument can be:
   -v "${PWD}/data:/data"

3. Check the container:
   docker ps
   docker logs inventory-cli

4. Test without a browser (if curl is available):
   curl http://localhost:5000/
   curl http://localhost:5000/add/Pen/5
   curl http://localhost:5000/add/Notebook/10
   curl http://localhost:5000/items

5. Stop and remove the container:
   docker stop inventory-cli
   docker rm inventory-cli

OPTION B — TEST WITH DOCKER COMPOSE
-----------------------------------
Run from the folder containing compose.yaml:

1. Build and start:
   docker compose up -d --build

2. Check status:
   docker compose ps

3. Check logs:
   docker compose logs

4. Test:
   curl http://localhost:5000/
   curl http://localhost:5000/add/Pen/5
   curl http://localhost:5000/add/Notebook/10
   curl http://localhost:5000/items

5. Stop services:
   docker compose down

The ./data:/data mount keeps the SQLite database in the project's data folder,
so records can persist when the container is recreated.

HOW TO ADAPT FOR AN EXAM
------------------------
- Change the app title and routes to match the scenario.
- Change table/column names and SQL statements if the fields change.
- Keep app.py, requirements.txt, and Dockerfile for a Flask app.
- Use compose.yaml if asked to configure/run services together.
- SQLite is built into Python; it does not need to be added to requirements.txt.
