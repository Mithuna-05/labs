from flask import Flask
import os
import sqlite3

app = Flask(__name__)

# Use /data in Docker so a mounted volume can preserve the database.
DATA_DIR = os.getenv("DATA_DIR", "data")
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "inventory.db")


def get_connection():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with get_connection() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                quantity INTEGER NOT NULL
            )
        """)


@app.route("/")
def home():
    return "Inventory Management System is running!"


@app.route("/add/<name>/<int:quantity>")
def add_item(name, quantity):
    with get_connection() as con:
        con.execute(
            "INSERT INTO items (name, quantity) VALUES (?, ?)",
            (name, quantity)
        )
    return f"Added item: {name}, quantity: {quantity}"


@app.route("/items")
def list_items():
    with get_connection() as con:
        rows = con.execute(
            "SELECT id, name, quantity FROM items ORDER BY id"
        ).fetchall()

    if not rows:
        return "No items found."

    return "\n".join(
        f"ID: {row['id']}, Name: {row['name']}, Quantity: {row['quantity']}"
        for row in rows
    )


@app.route("/health")
def health():
    return "OK"


init_db()

if __name__ == "__main__":
    # 0.0.0.0 is required so the app is reachable outside the container.
    app.run(host="0.0.0.0", port=5000)


'''
Check Docker Desktop is running:
docker --version
docker ps

Build the image:
docker build -t inventory-app:1.0 .

Run the application:
docker run -d --name inventory-cli -p 5000:5000 -e DATA_DIR=/data -v "%cd%\data:/data" inventory-app:1.0

Test it without opening a browser:
curl http://localhost:5000/
curl http://localhost:5000/add/Pen/5
curl http://localhost:5000/add/Notebook/10
curl http://localhost:5000/items
'''