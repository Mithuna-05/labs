# DOCKER PRACTICAL EXAM — MASTER FLASK APPLICATION CHEAT SHEET

## 1. UNDERSTAND THE FILE STRUCTURE

For a basic Flask application, create these files:

```text
myapp/
├── app.py
├── requirements.txt
└── Dockerfile
```

- `app.py` — contains the application logic and routes.
- `requirements.txt` — lists the Python libraries required.
- `Dockerfile` — contains instructions to build the Docker image.

**Exam workflow:**

1. Read the scenario.
2. Identify the application name, data fields, and operations.
3. Create `app.py`.
4. Create `requirements.txt`.
5. Create the Dockerfile.
6. Build and run the Docker container.

---

## 2. MASTER TEMPLATE — app.py

Use this template when the question requires a simple Flask application with a home page, adding records, and displaying records.

```python
from flask import Flask

app = Flask(__name__)

# MODIFY THESE TWO VALUES
APP_NAME = "Student Management System"
ITEM_NAME = "student"

# Temporary in-memory storage
records = []

@app.route("/")
def home():
    return f"{APP_NAME} is running!"

@app.route("/add/<name>")
def add_record(name):
    records.append(name)
    return f"{ITEM_NAME.title()} {name} added successfully!"

@app.route("/list")
def list_records():
    if not records:
        return "No records available"
    return ", ".join(records)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### What should I change?

Only change the application name and item name if the scenario requires basic add/list functionality.

| Scenario | APP_NAME | ITEM_NAME |
|---|---|---|
| Student Management | `"Student Management System"` | `"student"` |
| Logistics Management | `"Logistics Management System"` | `"shipment"` |
| Library Management | `"Library Management System"` | `"book"` |
| Employee Management | `"Employee Management System"` | `"employee"` |
| Inventory Management | `"Inventory Management System"` | `"product"` |

For example, if the question asks for a Library Management System, change the first two values to the Library Management values.

The rest of the template can remain unchanged if the required operations are still adding and listing simple records.

### How do I test it without a browser?

Start the application:

```bash
python app.py
```

Open another terminal while the server is running:

```bash
curl http://localhost:5000/
curl http://localhost:5000/add/Database
curl http://localhost:5000/list
```

These commands work locally without an internet connection, provided Python and Flask are available.

**Important limitation:** This template stores records in memory. The data disappears when the application restarts. Use the database template below if persistent storage is required.

---

## 3. WHEN THE QUESTION REQUIRES DIFFERENT DATA FIELDS

Suppose the question says:

"Create a Logistics Management System to add shipments with shipment ID and destination, and display all shipments."

Now a shipment has two fields rather than just a name.

Replace the `records` list and the `add_record()` and `list_records()` functions with:

```python
records = []

@app.route("/add/<shipment_id>/<destination>")
def add_shipment(shipment_id, destination):
    records.append({
        "shipment_id": shipment_id,
        "destination": destination
    })
    return f"Shipment {shipment_id} added successfully!"

@app.route("/list")
def list_shipments():
    if not records:
        return "No shipments available"
    return str(records)
```

Test using:

```bash
curl http://localhost:5000/add/S101/Chennai
curl http://localhost:5000/list
```

### How to adapt fields for other scenarios

- Student: student ID, name, department.
- Employee: employee ID, name, designation.
- Library: book ID, title, author.
- Logistics: shipment ID, destination, status.
- Inventory: product ID, product name, quantity.

Add a separate field in the dictionary for each required value. Update the route parameters and function accordingly.

If a scenario requires editing, deleting, authentication, or other specific functionality, you must implement those operations too. Do not assume that the basic add/list template satisfies every possible requirement.

---

## 4. WHEN THE QUESTION REQUIRES A DATABASE

If the question explicitly requires persistent storage, use a database instead of an ordinary Python list.

For a simple offline practical, SQLite is a convenient choice because it is included in Python. You do not need to install a separate database server.

### Database version — app.py

This example stores generic records containing a name and details.

```python
from flask import Flask
import sqlite3

app = Flask(__name__)
DB = "app.db"

def init_db():
    con = sqlite3.connect(DB)
    con.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            details TEXT
        )
    """)
    con.commit()
    con.close()

@app.route("/")
def home():
    return "Management System is running!"

@app.route("/add/<name>/<details>")
def add_record(name, details):
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT INTO records (name, details) VALUES (?, ?)",
        (name, details)
    )
    con.commit()
    con.close()
    return "Record added successfully!"

@app.route("/list")
def list_records():
    con = sqlite3.connect(DB)
    rows = con.execute(
        "SELECT id, name, details FROM records"
    ).fetchall()
    con.close()

    if not rows:
        return "No records available"

    return "\n".join(str(row) for row in rows)

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### What changes when using a database?

1. Import the database library.
2. Create a database initialization function.
3. Create the table with the necessary fields.
4. Insert records using `INSERT`.
5. Retrieve records using `SELECT`.
6. Commit changes and close the database connection.

SQLite is part of Python's standard library, so you do not add it to `requirements.txt`.

If the question explicitly specifies MySQL or PostgreSQL, use the requested database and its appropriate connector instead. The SQLite template is not a substitute for a specifically required database.

---

## 5. MASTER TEMPLATE — requirements.txt

For a basic Flask application:

```text
Flask
```

That is sufficient for both the in-memory example and the SQLite example.

If additional external libraries are required, list them separately, for example:

```text
Flask
requests
```

Only include libraries actually used by your application.

**Offline exam warning:** `requirements.txt` lists dependencies; it does not install them. An offline Docker build requires the dependencies to be available locally, such as in a prepared image or package cache.

---

## 6. COMMANDS TO REMEMBER

Create a project directory:

```bat
mkdir myapp
cd myapp
notepad app.py
notepad requirements.txt
```

Test the application if Flask is available:

```bash
python app.py
```

Build the Docker image after creating the Dockerfile:

```bash
docker build -t myapp:1.0 .
```

Run the container:

```bash
docker run -d --name mycontainer -p 5000:5000 myapp:1.0
```

Verify:

```bash
docker ps
docker logs mycontainer
```

Stop and remove it:

```bash
docker stop mycontainer
docker rm mycontainer
```

For a database application, the database file must also be retained if the data needs to persist across container replacement. Consider a Docker volume or bind mount if the question requires persistence.

---

## 7. QUICK DECISION GUIDE FOR THE EXAM

**If the question says...**

- "Create a basic Flask application" — use the master `app.py` template.
- "Add and display records" — use the add/list routes.
- "Include ID, name, destination, quantity, or other fields" — modify the data structure and route parameters.
- "Store records permanently" — use a database.
- "Use SQLite" — use Python's built-in `sqlite3`.
- "Use MySQL/PostgreSQL" — use the specified database and connector.
- "Containerize the application" — create the Dockerfile and build an image.
- "Run multiple services using Compose" — create `compose.yaml`.
- "Deploy using Kubernetes" — write the appropriate Kubernetes YAML manifests.

## FINAL RULE

Do not memorize five separate applications.

Memorize one basic Flask template, understand how to change its names and fields, and know when a database or additional operation is required.

Then use the same project structure and Docker workflow for whichever scenario the examiner gives you.

##two fields+database

from flask import Flask
import sqlite3

app = Flask(__name__)
DB = "app.db"

# Create database and table
def init_db():
    con = sqlite3.connect(DB)
    con.execute("""
        CREATE TABLE IF NOT EXISTS shipments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shipment_id TEXT,
            destination TEXT
        )
    """)
    con.commit()
    con.close()

# Home page
@app.route("/")
def home():
    return "Logistics Management System Running!"

# Add a shipment
@app.route("/add/<shipment_id>/<destination>")
def add_shipment(shipment_id, destination):
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT INTO shipments (shipment_id, destination) VALUES (?, ?)",
        (shipment_id, destination)
    )
    con.commit()
    con.close()
    return "Shipment added successfully!"

# View all shipments
@app.route("/list")
def list_shipments():
    con = sqlite3.connect(DB)
    rows = con.execute(
        "SELECT shipment_id, destination FROM shipments"
    ).fetchall()
    con.close()

    return str(rows)

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
