# DOCKER PRACTICAL EXAM — FINAL MASTER CHEAT SHEET

## 1. FIRST: IDENTIFY THE QUESTION TYPE

| Problem statement says... | Use this |
|---|---|
| Create a basic Flask application | Template A |
| Store multiple fields, such as ID and name | Template B |
| Store records in SQLite | Template C |
| Read a CSV dataset | Template D |
| Use PostgreSQL or MySQL as a separate service | Template E |
| Create a Docker image | Dockerfile + Docker CLI |
| Run an application and database together | Docker Compose + Dockerfile |
| Run Nginx using a command | Docker CLI |

**Important:** These are alternatives, not files to combine blindly. Multiple fields do not automatically require a database. Use a database when the question asks for one.

---

# 2. CREATE THE PROJECT FOLDER

Open Windows Command Prompt:

```bat
mkdir myapp
cd myapp
notepad app.py
```

Create the required files in this folder:

```text
myapp/
├── app.py
├── requirements.txt
├── Dockerfile
└── compose.yaml       (only if needed)
```

If using a dataset, also include the dataset file, such as `data.csv`.

---

# 3. TEMPLATE A — BASIC FLASK APPLICATION

Use when the question requires a home page, adding records, and listing records, without a database.

### app.py

```python
from flask import Flask

app = Flask(__name__)

APP_NAME = "Student Management System"
ITEM_NAME = "student"
records = []

@app.route("/")
def home():
    return f"{APP_NAME} is running!"

@app.route("/add/<name>")
def add(name):
    records.append(name)
    return f"{ITEM_NAME.title()} added successfully!"

@app.route("/list")
def show():
    return str(records)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### What to change

| Scenario | APP_NAME | ITEM_NAME |
|---|---|---|
| Student Management | Student Management System | student |
| Logistics Management | Logistics Management System | shipment |
| Library Management | Library Management System | book |
| Employee Management | Employee Management System | employee |

Change the two values in the code. If the question requests only basic add/list operations, the rest can stay the same.

This uses temporary memory. The records disappear when the application restarts.

---

# 4. TEMPLATE B — MULTIPLE DATA FIELDS

Use when the question asks for fields such as student ID and name, shipment ID and destination, or product ID and quantity.

Start with Template A. Replace the `records` list and the `add()` and `show()` functions with the following code.

```python
records = []

@app.route("/add/<record_id>/<name>")
def add(record_id, name):
    records.append({
        "id": record_id,
        "name": name
    })
    return "Record added successfully!"

@app.route("/list")
def show():
    return str(records)
```

### How to modify it

For shipment ID and destination:

- Change `record_id` to `shipment_id`.
- Change `name` to `destination`.
- Change the dictionary keys to `"shipment_id"` and `"destination"`.

For three fields, add a third route parameter and dictionary entry.

Example:

```python
@app.route("/add/<student_id>/<name>/<department>")
def add(student_id, name, department):
    records.append({
        "student_id": student_id,
        "name": name,
        "department": department
    })
    return "Student added successfully!"
```

**Remember:** These functions replace the corresponding functions in Template A. Do not paste duplicate route definitions into the same application.

---

# 5. TEMPLATE C — FLASK + SQLITE DATABASE

Use this when the question requires database storage, but does not specifically require MySQL or PostgreSQL.

SQLite is included with Python, so no separate database server is needed.

### Complete app.py

```python
from flask import Flask
import sqlite3

app = Flask(__name__)
DB = "app.db"

def init_db():
    con = sqlite3.connect(DB)
    con.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            details TEXT
        )
    """)
    con.commit()
    con.close()

@app.route("/")
def home():
    return "Management System Running!"

@app.route("/add/<name>/<details>")
def add(name, details):
    con = sqlite3.connect(DB)
    con.execute(
        "INSERT INTO records (name, details) VALUES (?, ?)",
        (name, details)
    )
    con.commit()
    con.close()
    return "Record added successfully!"

@app.route("/list")
def show():
    con = sqlite3.connect(DB)
    rows = con.execute(
        "SELECT id, name, details FROM records"
    ).fetchall()
    con.close()
    return str(rows)

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### What to change

1. Rename the table `records` to the appropriate table name.
2. Change `name` and `details` to the required fields.
3. Update `CREATE TABLE`, `INSERT`, and `SELECT` consistently.
4. Add more columns and parameters if the scenario has more fields.

For example, a shipments table might have `shipment_id`, `destination`, and `status`.

### SQLite persistence

The database is stored in `app.db`. When Docker containers are replaced, their writable filesystem may be lost. If persistence is required, store the database at a mounted path, such as `/data/app.db`, and configure a volume.

---

# 6. TEMPLATE D — USING A CSV DATASET

Use this when the question asks you to read or display records from a provided CSV file.

### app.py

```python
from flask import Flask
import csv

app = Flask(__name__)

@app.route("/")
def home():
    return "Dataset Application Running!"

@app.route("/data")
def show_data():
    with open("data.csv", newline="") as f:
        rows = list(csv.DictReader(f))
    return str(rows)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
```

### What to change

- Replace `data.csv` with the actual dataset filename.
- Use the appropriate column names when filtering or processing the data.
- Include the CSV file in the project folder.

The built-in `csv` module requires no installation.

If the question asks you to import CSV records into a database, add an import step to the database template and insert the CSV rows into the table. Do not use the basic in-memory template for that task.

---

# 7. requirements.txt — WHAT TO WRITE

Choose the version that matches your application.

**Templates A, B, C and D:**

```text
Flask
```

**Flask + PostgreSQL:**

```text
Flask
psycopg[binary]
```

**Flask + MySQL:**

```text
Flask
mysql-connector-python
```

**Flask + Pandas for dataset processing:**

```text
Flask
pandas
```

Only include external packages that your code actually imports. SQLite and the built-in CSV module do not need to be listed.

Offline warning: these entries declare dependencies; they do not make packages available without internet. The lab must have the necessary packages in a local cache or prebuilt image.

---

# 8. MASTER DOCKERFILE — FLASK

Create a file named exactly `Dockerfile` in the project folder.

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

### What each line does

| Instruction | Meaning |
|---|---|
| `FROM` | Selects the base image |
| `WORKDIR` | Sets the working directory |
| `COPY` | Copies files into the image |
| `RUN` | Installs dependencies during the build |
| `EXPOSE` | Documents the application's port |
| `CMD` | Starts the application when the container runs |

This Dockerfile works for Templates A–E as long as the application uses Python and Flask on port 5000. It can also be used with a CSV dataset because `COPY . .` copies the project files.

For a PostgreSQL/MySQL application, you normally keep this Dockerfile unchanged. The database runs in its own container.

If the question asks for a static HTML page served by Nginx, use an Nginx-based Dockerfile instead.

---

# 9. DOCKER CLI — BUILD, RUN, VERIFY

Execute these commands in the folder containing the Dockerfile.

### Build an image

```bash
docker build -t myapp:1.0 .
```

### Run a container

```bash
docker run -d --name mycontainer -p 5000:5000 myapp:1.0
```

### Check status and logs

```bash
docker images
docker ps
docker ps -a
docker logs mycontainer
```

### Stop and remove

```bash
docker stop mycontainer
docker rm mycontainer
```

### Test without a browser

If `curl` is available, run this in another terminal while the container is running:

```bash
curl http://localhost:5000/
curl http://localhost:5000/list
```

Remember: `-p HOST_PORT:CONTAINER_PORT`. The host port can be changed if required, but the container port must match the application's listening port.

---

# 10. TEMPLATE E — FLASK + EXTERNAL DATABASE

Use this when the question specifies PostgreSQL or MySQL running as a separate service.

Your folder becomes:

```text
myapp/
├── app.py
├── requirements.txt
├── Dockerfile
└── compose.yaml
```

The Flask code must connect to the database service using its service name, not `localhost`.

### PostgreSQL connection settings

Use environment variables in `app.py`:

```python
import os
import psycopg

def connect_db():
    return psycopg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        dbname=os.getenv("DB_NAME", "students"),
        user=os.getenv("DB_USER", "admin"),
        password=os.getenv("DB_PASSWORD", "exam123")
    )
```

Use this connection function in your add/list routes instead of `sqlite3.connect()`.

Your table creation and SQL statements must use PostgreSQL-compatible syntax and the `%s` parameter placeholders supported by psycopg.

### PostgreSQL compose.yaml

```yaml
services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      DB_HOST: db
      DB_NAME: students
      DB_USER: admin
      DB_PASSWORD: exam123
    depends_on:
      - db

  db:
    image: postgres:16
    environment:
      POSTGRES_DB: students
      POSTGRES_USER: admin
      POSTGRES_PASSWORD: exam123
```

### MySQL variation

For MySQL, change:

- `app.py`: use `mysql.connector.connect()` and MySQL-compatible SQL.
- `requirements.txt`: use `mysql-connector-python`.
- `compose.yaml`: use `image: mysql:8.4` and its corresponding environment variables.

The Dockerfile usually stays the same.

**Important:** `depends_on` sets startup order; it does not guarantee database readiness. For a robust application, implement retry logic or a health check. Use proper secrets rather than plain-text passwords in real deployments.