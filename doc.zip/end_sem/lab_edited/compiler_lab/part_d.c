
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

#define MAX 500
#define LEN 100

typedef struct {
    char op[20], arg1[LEN], arg2[LEN], res[LEN];
    int removed;
} Quad;

typedef struct {
    char name[LEN];
    int value;
} Constant;

static Quad q[MAX];
static int n = 0;

static Constant constants[MAX];
static int nc = 0;

int is_num(const char *s) {
    if (!s || !*s) return 0;

    if (*s == '-' || *s == '+') s++;
    if (!*s) return 0;

    while (*s) {
        if (!isdigit((unsigned char)*s++))
            return 0;
    }

    return 1;
}

int is_temp(const char *s) {
    return s && s[0] == 't' &&
           isdigit((unsigned char)s[1]);
}

int is_arithmetic(const char *op) {
    return !strcmp(op, "+") ||
           !strcmp(op, "-") ||
           !strcmp(op, "*") ||
           !strcmp(op, "/") ||
           !strcmp(op, "%");
}

int is_comparison(const char *op) {
    return !strcmp(op, "<") ||
           !strcmp(op, ">") ||
           !strcmp(op, "<=") ||
           !strcmp(op, ">=") ||
           !strcmp(op, "==") ||
           !strcmp(op, "!=");
}

void cp(char *dst, const char *src) {
    snprintf(dst, LEN, "%s", src ? src : "");
}

void parse_line(char *line) {
    char a[LEN] = "";
    char b[LEN] = "";
    char c[LEN] = "";
    char d[LEN] = "";
    char e[LEN] = "";

    while (isspace((unsigned char)*line))
        line++;

    if (!*line || n >= MAX || !strncmp(line, "---", 3))
        return;

    int cnt = sscanf(line, "%99s %99s %99s %99s %99s",
                     a, b, c, d, e);

    if (cnt <= 0)
        return;

    Quad x = {0};

    size_t len = strlen(a);

    if (len > 1 && a[len - 1] == ':') {
        a[len - 1] = '\0';
        cp(x.op, "label");
        cp(x.res, a);
    }
    else if (!strcmp(a, "goto") && cnt >= 2) {
        cp(x.op, "goto");
        cp(x.res, b);
    }
    else if (!strcmp(a, "ifFalse") &&
             cnt >= 4 && !strcmp(c, "goto")) {
        cp(x.op, "ifFalse");
        cp(x.arg1, b);
        cp(x.res, d);
    }
    else if (!strcmp(a, "PRINT") || !strcmp(a, "print")) {
        cp(x.op, "PRINT");
        if (cnt >= 2)
            cp(x.arg1, b);
    }
    else if (!strcmp(a, "return")) {
        cp(x.op, "return");
        if (cnt >= 2)
            cp(x.arg1, b);
    }
    else if (cnt == 3 && !strcmp(b, "=")) {
        cp(x.op, "=");
        cp(x.res, a);
        cp(x.arg1, c);
    }
    else if (cnt == 4 && !strcmp(b, "=")) {
        cp(x.op, c);
        cp(x.res, a);
        cp(x.arg1, d);
    }
    else if (cnt == 5 && !strcmp(b, "=")) {
        cp(x.op, d);
        cp(x.res, a);
        cp(x.arg1, c);
        cp(x.arg2, e);
    }
    else {
        return;
    }

    q[n++] = x;
}

void set_constant(const char *name, int value) {
    if (nc >= MAX)
        return;

    for (int i = nc - 1; i >= 0; i--) {
        if (!strcmp(constants[i].name, name)) {
            constants[i].value = value;
            return;
        }
    }

    cp(constants[nc].name, name);
    constants[nc].value = value;
    nc++;
}

void invalidate_constant(const char *name) {
    for (int i = 0; i < nc; i++) {
        if (!strcmp(constants[i].name, name)) {
            constants[i] = constants[--nc];
            return;
        }
    }
}

int get_constant(const char *name, int *value) {
    if (is_num(name)) {
        *value = atoi(name);
        return 1;
    }

    for (int i = nc - 1; i >= 0; i--) {
        if (!strcmp(constants[i].name, name)) {
            *value = constants[i].value;
            return 1;
        }
    }

    return 0;
}

/* FIX: Make a safe copy before overwriting x->arg1.
   This handles calls such as make_assignment(x, x->arg1). */
void make_assignment(Quad *x, const char *value) {
    char temp[LEN];

    snprintf(temp, sizeof(temp), "%s", value ? value : "");

    cp(x->op, "=");
    cp(x->arg1, temp);
    x->arg2[0] = '\0';
}

/* Constant folding and arithmetic simplification. */
void constant_folding(void) {
    nc = 0;

    for (int i = 0; i < n; i++) {
        Quad *x = &q[i];

        if (x->removed)
            continue;

        if (!strcmp(x->op, "label") ||
            !strcmp(x->op, "goto") ||
            !strcmp(x->op, "ifFalse")) {
            nc = 0;
            continue;
        }

        if (!strcmp(x->op, "PRINT") ||
            !strcmp(x->op, "return"))
            continue;

        if (is_arithmetic(x->op)) {
            int a, b;
            int ca = get_constant(x->arg1, &a);
            int cb = get_constant(x->arg2, &b);

            if (ca && cb) {
                long long r = 0;
                int valid = 1;

                if (!strcmp(x->op, "+"))
                    r = (long long)a + b;
                else if (!strcmp(x->op, "-"))
                    r = (long long)a - b;
                else if (!strcmp(x->op, "*"))
                    r = (long long)a * b;
                else if (!strcmp(x->op, "/")) {
                    if (b == 0 ||
                        (a == INT_MIN && b == -1))
                        valid = 0;
                    else
                        r = a / b;
                }
                else {
                    if (b == 0 ||
                        (a == INT_MIN && b == -1))
                        valid = 0;
                    else
                        r = a % b;
                }

                if (valid && r >= INT_MIN && r <= INT_MAX) {
                    char value[LEN];
                    snprintf(value, sizeof(value), "%d", (int)r);
                    make_assignment(x, value);
                }
            }

            /* x + 0 and x - 0 */
            if (is_arithmetic(x->op) &&
                (!strcmp(x->op, "+") ||
                 !strcmp(x->op, "-")) &&
                is_num(x->arg2) &&
                atoi(x->arg2) == 0) {
                make_assignment(x, x->arg1);
            }
            /* x * 0 */
            else if (is_arithmetic(x->op) &&
                     !strcmp(x->op, "*") &&
                     is_num(x->arg2) &&
                     atoi(x->arg2) == 0) {
                make_assignment(x, "0");
            }
            /* x * 1 and x / 1 */
            else if (is_arithmetic(x->op) &&
                     (!strcmp(x->op, "*") ||
                      !strcmp(x->op, "/")) &&
                     is_num(x->arg2) &&
                     atoi(x->arg2) == 1) {
                make_assignment(x, x->arg1);
            }
            /* 0 * x */
            else if (is_arithmetic(x->op) &&
                     !strcmp(x->op, "*") &&
                     is_num(x->arg1) &&
                     atoi(x->arg1) == 0) {
                make_assignment(x, "0");
            }
            /* 0 + x */
            else if (is_arithmetic(x->op) &&
                     !strcmp(x->op, "+") &&
                     is_num(x->arg1) &&
                     atoi(x->arg1) == 0) {
                make_assignment(x, x->arg2);
            }
        }

        if (!strcmp(x->op, "=")) {
            int value;

            if (is_num(x->arg1)) {
                set_constant(x->res, atoi(x->arg1));
            }
            else if (get_constant(x->arg1, &value) &&
                     is_temp(x->res)) {
                set_constant(x->res, value);
            }
            else {
                invalidate_constant(x->res);
            }
        }
        else if (is_arithmetic(x->op) ||
                 is_comparison(x->op)) {
            invalidate_constant(x->res);
        }
    }
}

/* Find the last definition of a temporary before instruction i. */
int find_definition(const char *name, int before) {
    for (int j = before - 1; j >= 0; j--) {
        if (!q[j].removed && !strcmp(q[j].res, name))
            return j;
    }

    return -1;
}

/* Substitute temporary definitions while keeping named variables. */
void propagate_temporaries(void) {
    for (int i = 0; i < n; i++) {
        Quad *x = &q[i];

        if (x->removed)
            continue;

        if (!strcmp(x->op, "label") ||
            !strcmp(x->op, "goto") ||
            !strcmp(x->op, "ifFalse")) {
            continue;
        }

        if (!strcmp(x->op, "=") && is_temp(x->arg1)) {
            int def = find_definition(x->arg1, i);

            if (def >= 0) {
                Quad *d = &q[def];

                if (!strcmp(d->op, "=")) {
                    char value[LEN];
                    cp(value, d->arg1);
                    cp(x->arg1, value);
                    d->removed = 1;
                }
                else if (is_arithmetic(d->op) ||
                         is_comparison(d->op)) {
                    char op[20], arg1[LEN], arg2[LEN];

                    cp(op, d->op);
                    cp(arg1, d->arg1);
                    cp(arg2, d->arg2);

                    cp(x->op, op);
                    cp(x->arg1, arg1);
                    cp(x->arg2, arg2);

                    d->removed = 1;
                }
            }
        }

        if (is_arithmetic(x->op)) {
            if (!strcmp(x->arg1, x->arg2) &&
                (!strcmp(x->op, "-") ||
                 !strcmp(x->op, "%"))) {
                make_assignment(x, "0");
            }
        }
    }
}

/* Reuse an earlier result for duplicate calculations. */
void common_subexpression_elimination(void) {
    for (int i = 0; i < n; i++) {
        Quad *x = &q[i];

        if (x->removed || !is_arithmetic(x->op))
            continue;

        for (int j = i - 1; j >= 0; j--) {
            Quad *d = &q[j];

            if (d->removed)
                continue;

            if (!strcmp(d->op, "label") ||
                !strcmp(d->op, "goto") ||
                !strcmp(d->op, "ifFalse"))
                break;

            int same = 0;

            if (is_arithmetic(d->op) &&
                !strcmp(d->op, x->op) &&
                !strcmp(d->arg1, x->arg1) &&
                !strcmp(d->arg2, x->arg2)) {
                same = 1;
            }

            if (!same)
                continue;

            int safe = 1;

            for (int k = j + 1; k < i; k++) {
                if (!q[k].removed &&
                    (!strcmp(q[k].res, d->arg1) ||
                     !strcmp(q[k].res, d->arg2))) {
                    safe = 0;
                    break;
                }
            }

            if (safe) {
                char result[LEN];
                cp(result, d->res);

                cp(x->arg1, result);
                cp(x->op, "=");
                x->arg2[0] = '\0';
                break;
            }
        }
    }

    /* Reuse an earlier named variable holding the same constant. */
    for (int i = 0; i < n; i++) {
        Quad *x = &q[i];

        if (x->removed || strcmp(x->op, "=") ||
            !is_temp(x->res) || !is_num(x->arg1))
            continue;

        for (int j = i - 1; j >= 0; j--) {
            Quad *d = &q[j];

            if (d->removed || strcmp(d->op, "=") ||
                is_temp(d->res) || !is_num(d->arg1))
                continue;

            if (!strcmp(d->arg1, x->arg1)) {
                cp(x->arg1, d->res);
                break;
            }
        }
    }
}

/* Remove unused temporary computations. */
void dead_code_elimination(void) {
    int changed;

    do {
        changed = 0;

        for (int i = 0; i < n; i++) {
            if (q[i].removed || !is_temp(q[i].res))
                continue;

            int used = 0;

            for (int j = 0; j < n; j++) {
                if (q[j].removed || i == j)
                    continue;

                if (!strcmp(q[j].arg1, q[i].res) ||
                    !strcmp(q[j].arg2, q[i].res)) {
                    used = 1;
                    break;
                }
            }

            if (!used) {
                q[i].removed = 1;
                changed = 1;
            }
        }
    } while (changed);
}

void print_instruction(const Quad *x) {
    if (!strcmp(x->op, "label"))
        printf("%s:\n", x->res);
    else if (!strcmp(x->op, "goto"))
        printf("goto %s\n", x->res);
    else if (!strcmp(x->op, "ifFalse"))
        printf("ifFalse %s goto %s\n", x->arg1, x->res);
    else if (!strcmp(x->op, "PRINT"))
        printf("PRINT %s\n", x->arg1);
    else if (!strcmp(x->op, "return"))
        printf("return %s\n", x->arg1);
    else if (!strcmp(x->op, "="))
        printf("%s = %s\n", x->res, x->arg1);
    else if (is_arithmetic(x->op) || is_comparison(x->op))
        printf("%s = %s %s %s\n",
               x->res, x->arg1, x->op, x->arg2);
}

int main(void) {
    char line[512];

    while (fgets(line, sizeof(line), stdin)) {
        line[strcspn(line, "\r\n")] = '\0';
        parse_line(line);
    }

    constant_folding();
    propagate_temporaries();
    constant_folding();
    common_subexpression_elimination();
    propagate_temporaries();
    dead_code_elimination();

    printf("--- PART D: OPTIMIZED TAC "
           "(CONSTANT FOLDING, CSE & DCE) ---\n");

    for (int i = 0; i < n; i++) {
        if (!q[i].removed)
            print_instruction(&q[i]);
    }

    return 0;
}
