import hashlib
import json
import os

def md5(text):
    return hashlib.md5(text.encode()).hexdigest()

while True:
    print("\n1. Generate MD5")
    print("2. Verify Integrity")
    print("3. Avalanche Effect")
    print("4. File Checksum")
    print("5. Compare MD5, SHA-1 and SHA-256")
    print("6. File Integrity Monitoring")
    print("7. Exit")

    ch = input("Enter choice: ")

    if ch == '1':
        msg = input("Enter message: ")
        print("MD5:", md5(msg))

    elif ch == '2':
        msg = input("Enter message: ")
        old = input("Enter previous digest: ")
        if md5(msg) == old:
            print("Matches")
        else:
            print("Does Not Match")

    elif ch == '3':
        a = input("Enter first message: ")
        b = input("Enter second message: ")
        print("First MD5:", md5(a))
        print("Second MD5:", md5(b))

    elif ch == '4':
        path = input("Enter file path: ")
        try:
            with open(path, 'rb') as f:
                print("MD5 checksum:", hashlib.md5(f.read()).hexdigest())
        except FileNotFoundError:
            print("File not found")

    elif ch == '5':
        msg = input("Enter message: ")
        print("MD5:", hashlib.md5(msg.encode()).hexdigest())
        print("SHA-1:", hashlib.sha1(msg.encode()).hexdigest())
        print("SHA-256:", hashlib.sha256(msg.encode()).hexdigest())

    elif ch == '6':
        record = "checksums.json"
        files = input("Enter file paths separated by commas: ").split(",")

        if os.path.exists(record):
            with open(record, 'r') as f:
                old = json.load(f)
        else:
            old = {}

        new = {}

        for path in files:
            path = path.strip()
            if not os.path.isfile(path):
                print(path, "- Missing File")
                continue

            with open(path, 'rb') as f:
                checksum = hashlib.md5(f.read()).hexdigest()

            if path not in old:
                print(path, "- New File")
            elif old[path] == checksum:
                print(path, "- Not Modified")
            else:
                print(path, "- Modified")

            new[path] = checksum

        for path in old:
            if path not in files and not os.path.isfile(path):
                print(path, "- Missing File")

        with open(record, 'w') as f:
            json.dump(new, f)

    elif ch == '7':
        break

    else:
        print("Invalid choice")