#pip install pycryptodome
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

def generate_keys():
    key = RSA.generate(2048)
    open("private.pem", "wb").write(key.export_key())
    open("public.pem", "wb").write(key.publickey().export_key())
    print("Keys generated and saved")
    print(key.export_key().decode())
    print(key.publickey().export_key().decode())

def sign_message():
    msg = input("Enter message: ")
    key = RSA.import_key(open("private.pem", "rb").read())
    h = SHA256.new(msg.encode())
    sig = pkcs1_15.new(key).sign(h)
    print("Message:", msg)
    print("Digest:", h.hexdigest())
    print("Signature:", sig.hex())

def verify_signature():
    msg = input("Enter message: ")
    sig = bytes.fromhex(input("Enter signature: "))
    key = RSA.import_key(open("public.pem", "rb").read())
    try:
        pkcs1_15.new(key).verify(SHA256.new(msg.encode()), sig)
        print("Signature is Valid")
    except (ValueError, TypeError):
        print("Signature is Invalid")

def tampering():
    msg = input("Enter original message: ")
    key = RSA.import_key(open("private.pem", "rb").read())
    sig = pkcs1_15.new(key).sign(SHA256.new(msg.encode()))
    received = input("Enter received message: ")
    print("Original message:", msg)
    print("Received message:", received)
    key = RSA.import_key(open("public.pem", "rb").read())
    try:
        pkcs1_15.new(key).verify(SHA256.new(received.encode()), sig)
        print("Signature is Valid")
    except (ValueError, TypeError):
        print("Verification failed: Message has been altered")

def email_demo():
    msg = input("Alice's message to Bob: ")
    key = RSA.import_key(open("private.pem", "rb").read())
    sig = pkcs1_15.new(key).sign(SHA256.new(msg.encode()))
    print("Alice signs and sends the message")
    print("Original message:", msg)
    received = input("Bob, enter the received message: ")
    print("Bob receives:", received)
    key = RSA.import_key(open("public.pem", "rb").read())
    try:
        pkcs1_15.new(key).verify(SHA256.new(received.encode()), sig)
        print("Bob: Signature is Valid")
    except (ValueError, TypeError):
        print("Bob: Signature is Invalid. Message may have been altered.")

while True:
    print("\n1. Generate RSA Keys")
    print("2. Sign Message")
    print("3. Verify Signature")
    print("4. Demonstrate Tampering")
    print("5. Exit")
    print("6. Secure Email Communication")

    ch = input("Enter choice: ")

    if ch == '1':
        generate_keys()
    elif ch == '2':
        sign_message()
    elif ch == '3':
        verify_signature()
    elif ch == '4':
        tampering()
    elif ch == '5':
        break
    elif ch == '6':
        email_demo()
    else:
        print("Invalid choice")