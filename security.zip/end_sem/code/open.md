1. Check if Node.js and npm are installed
node -v
npm -v


If both display version numbers, skip to Step 3.
2. If they are missing, install them
sudo apt update
sudo apt install -y nodejs npm


Check again:
node -v
npm -v


If Node.js is too old for OpenCode, use a newer compatible version. If sudo is unavailable, you'll need a user-level installation.
3. Install OpenCode
npm install -g opencode-ai


Verify:
opencode --version


4. Create your lab folder
mkdir -p ~/labwork
cd ~/labwork


5. Launch OpenCode
opencode .


6. Connect to an AI provider
Inside OpenCode, enter:
/connect


Choose a provider and follow the instructions.
Important: OpenCode itself does not guarantee account-free AI access. Complete this step before the lab, because authentication may require a browser or API key.
7. Paste your lab question
Try these shortcuts in order:
Action	Shortcut
Paste into Ubuntu terminal	Ctrl + Shift + V
Alternative paste	Shift + Insert
Paste inside OpenCode	Ctrl + V
Copy selected terminal text	Ctrl + Shift + C
Alternative copy	Ctrl + C*
Select all in many terminal applications	Ctrl + Shift + A*
*Shortcuts depend on the terminal. In particular, Ctrl + C usually interrupts a running command rather than copying text. Right-click → Copy/Paste may also work.
8. Ask OpenCode to create files
Paste a prompt like this into OpenCode:
Solve the following lab question. Create the complete, working solution directly in the current directory and save it in the appropriate source file. Do not merely display the code in the chat.
Requirements:
1. Include all necessary code and imports.
2. Follow the question exactly.
3. Ensure the solution works on Ubuntu.
4. Tell me the commands to compile and execute it.
5. Do not overwrite unrelated files.
Lab question:
[PASTE YOUR QUESTION HERE]




Review and approve file changes if OpenCode asks for permission.
9. Check the generated files
Exit OpenCode if necessary, then run:
ls -l


Display your code:
cat main.c


Replace main.c with the actual filename if needed.
10. Compile and run your program
Use the commands for your programming language.
C
gcc main.c -o main
./main




C++
g++ main.cpp -o main
./main




Python
python3 main.py




Java
javac Main.java
java Main




11. If you need to copy the generated code manually
cat main.c


Select the displayed text using your terminal's mouse selection and copy shortcut. Or edit the file directly:
nano main.c


Save in Nano with Ctrl + O, press Enter, and exit with Ctrl + X.