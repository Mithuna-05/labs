from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

plaintext = input("Enter plaintext: ")
key = input("Enter 16-byte key: ").encode()[:16].ljust(16, b'X')

while True:
    print("\n1. ECB")
    print("2. CBC")
    print("3. CFB")
    print("4. OFB")
    print("5. CTR")
    print("6. Exit")

    ch = input("Enter choice: ")

    if ch == '1':
        cipher = AES.new(key, AES.MODE_ECB)
        encrypted = cipher.encrypt(pad(plaintext.encode(), 16))
        print("Ciphertext:", encrypted.hex())

        cipher = AES.new(key, AES.MODE_ECB)
        decrypted = unpad(cipher.decrypt(encrypted), 16).decode()
        print("Decrypted:", decrypted)

    elif ch == '2':
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        encrypted = cipher.encrypt(pad(plaintext.encode(), 16))
        print("IV:", iv.hex())
        print("Ciphertext:", encrypted.hex())

        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted = unpad(cipher.decrypt(encrypted), 16).decode()
        print("Decrypted:", decrypted)

    elif ch == '3':
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CFB, iv=iv)
        encrypted = cipher.encrypt(plaintext.encode())
        print("IV:", iv.hex())
        print("Ciphertext:", encrypted.hex())

        cipher = AES.new(key, AES.MODE_CFB, iv=iv)
        decrypted = cipher.decrypt(encrypted).decode()
        print("Decrypted:", decrypted)

    elif ch == '4':
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_OFB, iv=iv)
        encrypted = cipher.encrypt(plaintext.encode())
        print("IV:", iv.hex())
        print("Ciphertext:", encrypted.hex())

        cipher = AES.new(key, AES.MODE_OFB, iv=iv)
        decrypted = cipher.decrypt(encrypted).decode()
        print("Decrypted:", decrypted)

    elif ch == '5':
        nonce = get_random_bytes(8)
        cipher = AES.new(key, AES.MODE_CTR, nonce=nonce)
        encrypted = cipher.encrypt(plaintext.encode())
        print("Nonce:", nonce.hex())
        print("Ciphertext:", encrypted.hex())

        cipher = AES.new(key, AES.MODE_CTR, nonce=nonce)
        decrypted = cipher.decrypt(encrypted).decode()
        print("Decrypted:", decrypted)

    elif ch == '6':
        break

    else:
        print("Invalid choice")