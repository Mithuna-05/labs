import hashlib

def sha1(msg):
    return hashlib.sha1(msg.encode()).hexdigest()

while True:
    print("\n1. Generate Hash")
    print("2. Avalanche Effect")
    print("3. Compare Messages")
    print("4. Preprocessing")
    print("5. Exit")

    ch = input("Enter choice: ")

    if ch == '1':
        msg = input("Enter message: ")
        print("Message:", msg)
        print("SHA-1:", sha1(msg))

    elif ch == '2':
        msg = input("Enter message: ")
        pos = int(input("Enter position to change (0-based): "))
        if 0 <= pos < len(msg):
            c = input("Enter new character: ")
            if len(c) == 1:
                new = msg[:pos] + c + msg[pos+1:]
                print("Original hash:", sha1(msg))
                print("Modified message:", new)
                print("Modified hash:", sha1(new))
            else:
                print("Enter one character only")
        else:
            print("Invalid position")

    elif ch == '3':
        a = input("Enter first message: ")
        b = input("Enter second message: ")
        print("First hash:", sha1(a))
        print("Second hash:", sha1(b))
        print("Messages are identical" if sha1(a) == sha1(b) else "Messages are different")

    elif ch == '4':
        msg = input("Enter sentence: ")
        bits = ''.join(format(x, '08b') for x in msg.encode())
        n = len(bits)
        padded = bits + '1'
        padded += '0' * ((448 - len(padded) % 512) % 512)
        padded += format(n, '064b')
        print("Original binary:", bits)
        print("Padded message:", padded)
        print("512-bit blocks:", len(padded) // 512)
        print("SHA-1:", sha1(msg))

    elif ch == '5':
        break

    else:
        print("Invalid choice")