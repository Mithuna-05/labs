p = int(input("Enter prime number: "))
g = int(input("Enter primitive root: "))

a = int(input("Enter Alice's private key: "))
b = int(input("Enter Bob's private key: "))

A = pow(g, a, p)
B = pow(g, b, p)

print("Prime number:", p)
print("Primitive root:", g)
print("Alice's private key:", a)
print("Bob's private key:", b)

print("Alice's public key:", A)
print("Bob's public key:", B)

print("Alice receives Bob's public key:", B)
print("Bob receives Alice's public key:", A)

key1 = pow(B, a, p)
key2 = pow(A, b, p)

print("Shared secret key of Alice:", key1)
print("Shared secret key of Bob:", key2)

if key1 == key2:
    print("Both shared secret keys are equal")
else:
    print("Shared secret keys are not equal")